Partner portraits go here.

Portrait (photo in src/data/team.ts): 4:5, at least 1000x1250, JPG or WebP, with the face in the upper third.
The same image is also shown as a 5:4 card and a 4:3 crop on phones, positioned to keep the face in view.
Avatar (avatar in team.ts): a square head-and-shoulders crop, at least 256x256, for the small round avatars.
Without one, the avatar uses the portrait.

Shantanu: shantanu.jpg (portrait) and shantanu-avatar.jpg (avatar), both cropped from his beach photo.
Vedant: vedant.jpg (portrait) and vedant-avatar.jpg (avatar), both cropped from his scooter photo.
Vedant's timeline photos: vedant-night.jpg and vedant-holi.jpg (the crowd behind him was removed from the Holi photo).

Career timeline photos also live here (e.g. shantanu-2026-01.jpg), referenced from `photos` on a career entry
in src/data/team.ts.

Remove all metadata from phone photos before adding them: iPhone HEIC files usually carry GPS coordinates.
Every image in this folder is metadata-free.
