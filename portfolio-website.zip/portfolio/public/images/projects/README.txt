Project screenshots go here.

Recommended: 1600x1000 JPG or WebP, under 300 KB each.
Name them after the project slug, e.g. apparel-60.jpg, then set cover.image in src/data/projects.ts.
