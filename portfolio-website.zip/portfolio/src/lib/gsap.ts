"use client";

/**
 * One place to load GSAP and its plugins (client only).
 * GSAP is free for commercial use, including all plugins: https://gsap.com/standard-license
 */
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";

gsap.registerPlugin(ScrollTrigger, useGSAP);

/** Media query used to gate every GSAP effect. */
export const MOTION_OK = "(prefers-reduced-motion: no-preference)";

export { gsap, ScrollTrigger, useGSAP };
