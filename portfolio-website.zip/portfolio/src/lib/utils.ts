/** Join class names, skipping falsy values. */
export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

/** "https://www.apparel60.co.in/" -> "apparel60.co.in" */
export function displayUrl(url: string) {
  return url.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "");
}

/** Click-to-chat link. Accepts numbers with spaces, dashes or a leading "+". */
export function whatsappUrl(number: string, message?: string) {
  const url = `https://wa.me/${number.replace(/\D/g, "")}`;
  return message ? `${url}?text=${encodeURIComponent(message)}` : url;
}

/** Tap-to-call link: "+91 91048 39400" -> "tel:+919104839400" */
export function telHref(phone: string) {
  return `tel:${phone.replace(/[^\d+]/g, "")}`;
}

/** Keep only links that have been filled in. */
export function withHref<T extends { href: string }>(links: readonly T[]) {
  return links.filter((link) => link.href.trim() !== "");
}
