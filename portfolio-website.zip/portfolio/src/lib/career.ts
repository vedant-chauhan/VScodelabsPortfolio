import type { CareerEntry, CareerKind } from "@/types/content";

export const careerKinds: Record<CareerKind, { label: string; color: string; point: boolean }> = {
  education: { label: "Education", color: "var(--kind-education)", point: false },
  work: { label: "Work", color: "var(--kind-work)", point: false },
  freelance: { label: "Freelance", color: "var(--kind-freelance)", point: false },
  founder: { label: "Founder", color: "var(--kind-founder)", point: false },
  milestone: { label: "Milestone", color: "var(--kind-milestone)", point: true },
  certification: { label: "Certification", color: "var(--kind-certification)", point: true },
};

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** "2021-06" -> 2021.4167 (start of June), "2021" -> 2021 */
export function toYears(date: string) {
  const [year, month] = date.split("-").map(Number);
  return year + (month ? (month - 1) / 12 : 0);
}

/** "2021-06" -> "Jun 2021", "2021" -> "2021" */
export function formatDate(date: string) {
  const [year, month] = date.split("-");
  return month ? `${MONTHS[Number(month) - 1]} ${year}` : year;
}

/** True for entries shown as a single date (milestones, certifications, or anything marked `point`). */
export function isPoint(entry: CareerEntry) {
  return careerKinds[entry.kind].point || Boolean(entry.point);
}

export function formatPeriod(entry: CareerEntry) {
  if (isPoint(entry)) return formatDate(entry.start);
  return `${formatDate(entry.start)} – ${entry.end ? formatDate(entry.end) : "Present"}`;
}

/** Sample entries are development-only placeholders; the live site never shows them. */
export function visibleCareer(entries: CareerEntry[]) {
  return process.env.NODE_ENV === "production" ? entries.filter((entry) => !entry.sample) : entries;
}

/** Newest first; ongoing roles before finished ones that started at the same time. */
export function sortNewestFirst(entries: CareerEntry[]) {
  return [...entries].sort((a, b) => toYears(b.start) - toYears(a.start) || (a.end ? 1 : 0) - (b.end ? 1 : 0));
}

/** Current year and month, cached so pages stay statically prerendered (refreshes with the cache lifetime). */
export async function now() {
  "use cache";
  const date = new Date();
  return { year: date.getFullYear(), fraction: date.getFullYear() + date.getMonth() / 12 };
}
