import type { CSSProperties } from "react";

/** Inline style that staggers a reveal or entrance animation. */
export function delay(ms: number): CSSProperties {
  return { "--delay": `${ms}ms`, animationDelay: `${ms}ms` } as CSSProperties;
}

/**
 * Runs in <head> before the first paint:
 * 1. Applies the theme the visitor picked last time (light/dark), so there's no flash.
 * 2. Turns scroll animations on only when JavaScript works and the visitor allows motion.
 *    If no <Reveal> has started after 3 seconds, motion is switched off so content is never stuck hidden.
 */
export const bootScript = `(function(){var d=document.documentElement;try{var t=localStorage.getItem("theme");if(t==="light"||t==="dark")d.setAttribute("data-theme",t)}catch(e){}try{if(!window.matchMedia("(prefers-reduced-motion: reduce)").matches){d.setAttribute("data-motion","on");setTimeout(function(){if(!d.hasAttribute("data-reveal-ready"))d.removeAttribute("data-motion")},3000)}}catch(e){}})()`;
