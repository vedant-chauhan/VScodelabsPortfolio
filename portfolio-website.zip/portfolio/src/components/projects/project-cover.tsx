import Image from "next/image";
import type { CoverVariant, Project } from "@/types/content";
import { cn } from "@/lib/utils";

/**
 * Project visual. Shows `cover.image` when you add a screenshot,
 * otherwise a drawn "app window" in the project's colours.
 */
export function ProjectCover({
  project,
  className,
  priority,
  sizes = "(min-width: 1024px) 50vw, 100vw",
}: {
  project: Project;
  className?: string;
  priority?: boolean;
  sizes?: string;
}) {
  const { cover } = project;

  return (
    <div
      className={cn("relative aspect-[16/10] overflow-hidden rounded-2xl", className)}
      style={{ background: `linear-gradient(135deg, ${cover.from}, ${cover.to})` }}
    >
      {cover.image ? (
        <Image
          src={cover.image}
          alt={cover.imageAlt ?? `${project.name} screenshot`}
          fill
          sizes={sizes}
          priority={priority}
          className="object-cover transition-transform duration-700 ease-out-soft group-hover:scale-[1.04]"
        />
      ) : (
        <div
          aria-hidden="true"
          className="absolute inset-x-[7%] top-[9%] bottom-0 origin-bottom overflow-hidden rounded-t-xl bg-white/95 shadow-2xl shadow-black/20 transition-transform duration-700 ease-out-soft group-hover:scale-[1.04]"
        >
          <div className="flex items-center gap-1.5 border-b border-black/5 px-3 py-2.5">
            <span className="size-2 rounded-full bg-black/10" />
            <span className="size-2 rounded-full bg-black/10" />
            <span className="size-2 rounded-full bg-black/10" />
            <span className="ml-3 h-2 w-1/3 rounded-full bg-black/5" />
          </div>
          <div className="p-[5%]">
            <p className="mb-[4%] text-[clamp(10px,1.6vw,15px)] font-semibold tracking-tight text-neutral-900">
              {project.name}
            </p>
            <Mock variant={cover.variant} color={cover.from} />
          </div>
        </div>
      )}
    </div>
  );
}

function Mock({ variant, color }: { variant: CoverVariant; color: string }) {
  switch (variant) {
    case "store":
      return (
        <div className="grid grid-cols-4 gap-[3%]">
          {Array.from({ length: 8 }, (_, i) => (
            <div key={i} className="space-y-1.5">
              <div
                className="aspect-[3/4] rounded-md"
                style={{ background: i % 3 === 0 ? color : "rgba(0,0,0,0.06)", opacity: i % 3 === 0 ? 0.75 : 1 }}
              />
              <div className="h-1.5 w-3/4 rounded-full bg-black/10" />
              <div className="h-1.5 w-1/3 rounded-full bg-black/5" />
            </div>
          ))}
        </div>
      );
    case "calendar":
      return (
        <div className="grid grid-cols-5 gap-[2.5%]">
          {Array.from({ length: 5 }, (_, day) => (
            <div key={day} className="space-y-[6%]">
              <div className="h-1.5 w-1/2 rounded-full bg-black/15" />
              {Array.from({ length: 5 }, (_, slot) => {
                const booked = (day + slot) % 3 === 0 || (day === 2 && slot === 1);
                return (
                  <div
                    key={slot}
                    className="h-[clamp(10px,2.4vw,26px)] rounded-md"
                    style={{ background: booked ? color : "rgba(0,0,0,0.05)", opacity: booked ? 0.8 : 1 }}
                  />
                );
              })}
            </div>
          ))}
        </div>
      );
    case "dashboard":
      return (
        <div className="space-y-[4%]">
          <div className="grid grid-cols-3 gap-[3%]">
            {[0, 1, 2].map((i) => (
              <div key={i} className="rounded-md bg-black/[0.04] p-[8%]">
                <div className="h-1.5 w-1/2 rounded-full bg-black/10" />
                <div className="mt-2 h-3 w-2/3 rounded-full" style={{ background: color, opacity: 0.8 - i * 0.2 }} />
              </div>
            ))}
          </div>
          <div className="space-y-1.5">
            {Array.from({ length: 5 }, (_, i) => (
              <div key={i} className="flex items-center gap-2 rounded-md bg-black/[0.03] px-2 py-1.5">
                <div className="h-1.5 w-1/4 rounded-full bg-black/15" />
                <div className="h-1.5 flex-1 rounded-full bg-black/5" />
                <div
                  className="h-2.5 w-10 rounded-full"
                  style={{ background: i % 2 ? "rgba(0,0,0,0.08)" : color, opacity: 0.7 }}
                />
              </div>
            ))}
          </div>
        </div>
      );
    case "chat":
      return (
        <div className="flex flex-col gap-[clamp(4px,1.2vw,10px)]">
          {[
            { me: false, w: "62%" },
            { me: true, w: "48%" },
            { me: false, w: "74%" },
            { me: false, w: "40%" },
            { me: true, w: "55%" },
          ].map((bubble, i) => (
            <div
              key={i}
              className={cn(
                "h-[clamp(10px,2.2vw,22px)] rounded-2xl",
                bubble.me ? "self-end rounded-br-sm" : "self-start rounded-bl-sm bg-black/[0.06]",
              )}
              style={{ width: bubble.w, ...(bubble.me ? { background: color, opacity: 0.85 } : {}) }}
            />
          ))}
        </div>
      );
  }
}
