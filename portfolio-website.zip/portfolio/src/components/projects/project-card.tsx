import { ViewTransition } from "react";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import type { Project } from "@/types/content";
import { ProjectCover } from "./project-cover";

export function ProjectCard({ project }: { project: Project }) {
  return (
    <article className="group relative">
      {/* Same name as the case-study cover, so it morphs into it on navigation. */}
      <ViewTransition name={`project-${project.slug}`} share="morph" default="none">
        <ProjectCover
          project={project}
          className="transition-transform duration-500 group-hover:-translate-y-1"
          sizes="(min-width: 768px) 50vw, 100vw"
        />
      </ViewTransition>
      <div className="mt-5 flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.14em] text-muted">{project.category}</p>
          <h3 className="mt-2 text-xl font-semibold tracking-tight">
            <Link href={`/projects/${project.slug}`} className="after:absolute after:inset-0">
              {project.name}
            </Link>
          </h3>
          <p className="mt-1.5 text-muted text-pretty">{project.tagline}</p>
        </div>
        <span className="mt-1 grid size-10 shrink-0 place-items-center rounded-full border border-line transition-colors group-hover:border-ink group-hover:bg-ink group-hover:text-canvas">
          <ArrowUpRight className="size-4" aria-hidden="true" />
        </span>
      </div>
    </article>
  );
}
