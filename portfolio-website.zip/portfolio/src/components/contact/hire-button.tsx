import Link from "next/link";
import { BriefcaseBusiness } from "lucide-react";
import { getMember } from "@/data/team";
import { buttonClasses } from "@/components/ui/button";

/**
 * "Hire" button linking to the Hire page: /hire for the studio, or /hire/<slug> for one partner.
 * Works in both server and client components.
 */
export function HireButton({
  partner,
  children,
  variant = "primary",
  className,
  icon = true,
}: {
  /** Slug from team.ts. Leave out for a studio-wide "Hire us". */
  partner?: string;
  /** Button label. Defaults to "Hire us" or "Hire <first name>". */
  children?: React.ReactNode;
  variant?: "primary" | "secondary" | "inverse";
  className?: string;
  icon?: boolean;
}) {
  const member = partner ? getMember(partner) : undefined;
  const label = children ?? (member ? `Hire ${member.name.split(" ")[0]}` : "Hire us");

  return (
    <Link href={member ? `/hire/${member.slug}` : "/hire"} className={buttonClasses(variant, className)}>
      {icon && <BriefcaseBusiness className="size-4" aria-hidden="true" />}
      {label}
    </Link>
  );
}
