"use client";

import { useActionState, useId } from "react";
import { ArrowRight, Check } from "lucide-react";
import { sendContactMessage, type ContactField, type ContactState } from "@/app/contact/actions";
import { site } from "@/data/site";
import { services } from "@/data/services";
import { team } from "@/data/team";
import { buttonClasses } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const initialState: ContactState = { status: "idle", message: "" };

const inputClasses =
  "w-full rounded-xl border border-line bg-surface px-4 py-3 text-base outline-none transition-colors placeholder:text-muted/70 focus:border-accent aria-[invalid=true]:border-red-500";

/**
 * The enquiry form used on /contact and the Hire pages.
 * Every field id is unique per instance, so it's safe to render more than once.
 */
export function ContactForm({
  defaultPartner = "",
  partnerField = "select",
  messageLabel = "Tell us about your project",
}: {
  /** Partner slug to pre-select. */
  defaultPartner?: string;
  /** "select": visitors choose a partner in the form. "hidden": the page already chose (Hire pages). */
  partnerField?: "select" | "hidden";
  messageLabel?: string;
}) {
  const [state, formAction, pending] = useActionState(sendContactMessage, initialState);
  const uid = useId();
  const id = (field: string) => `${uid}-${field}`;

  const frame = "rounded-2xl border border-line bg-surface p-6 sm:p-10";

  if (state.status === "success") {
    return (
      <div role="status" className={frame}>
        <span className="grid size-12 place-items-center rounded-full bg-accent-soft text-accent">
          <Check className="size-6" aria-hidden="true" />
        </span>
        <h2 className="mt-6 text-2xl font-semibold tracking-tight">Message sent</h2>
        <p className="mt-2 text-muted">{state.message}</p>
      </div>
    );
  }

  const value = (field: ContactField) => state.values?.[field] ?? "";
  const error = (field: ContactField) => state.errors?.[field];
  const invalid = (field: ContactField) => ({
    "aria-invalid": Boolean(error(field)),
    "aria-describedby": error(field) ? id(`${field}-error`) : undefined,
  });

  return (
    <form action={formAction} noValidate className={cn("relative", frame)}>
      <div className="grid gap-6 sm:grid-cols-2">
        <Field id={id("name")} label="Your name" error={error("name")}>
          <input
            id={id("name")}
            name="name"
            autoComplete="name"
            required
            defaultValue={value("name")}
            {...invalid("name")}
            className={inputClasses}
          />
        </Field>
        <Field id={id("email")} label="Email" error={error("email")}>
          <input
            id={id("email")}
            name="email"
            type="email"
            autoComplete="email"
            required
            defaultValue={value("email")}
            {...invalid("email")}
            className={inputClasses}
          />
        </Field>
        <Field id={id("phone")} label="Phone" optional>
          <input
            id={id("phone")}
            name="phone"
            type="tel"
            autoComplete="tel"
            defaultValue={value("phone")}
            className={inputClasses}
          />
        </Field>
        <Field id={id("company")} label="Company" optional>
          <input
            id={id("company")}
            name="company"
            autoComplete="organization"
            defaultValue={value("company")}
            className={inputClasses}
          />
        </Field>
        {partnerField === "select" ? (
          <Field id={id("partner")} label="Who would you like to work with?" optional>
            <select
              id={id("partner")}
              name="partner"
              defaultValue={state.values ? value("partner") : defaultPartner}
              className={inputClasses}
            >
              <option value="">Either of us</option>
              {team.map((member) => (
                <option key={member.slug} value={member.slug}>
                  {member.name}
                </option>
              ))}
            </select>
          </Field>
        ) : (
          <input type="hidden" name="partner" value={defaultPartner} />
        )}
        <Field
          id={id("service")}
          label="What do you need?"
          optional
          className={partnerField === "hidden" ? "sm:col-span-2" : undefined}
        >
          <select id={id("service")} name="service" defaultValue={value("service")} className={inputClasses}>
            <option value="">Select a service</option>
            {services.map((service) => (
              <option key={service.id}>{service.title}</option>
            ))}
            <option>Something else</option>
          </select>
        </Field>
        <Field id={id("budget")} label="Budget" optional className="sm:col-span-2">
          <select id={id("budget")} name="budget" defaultValue={value("budget")} className={inputClasses}>
            <option value="">Select a range</option>
            {site.budgets.map((budget) => (
              <option key={budget}>{budget}</option>
            ))}
          </select>
        </Field>
        <Field id={id("message")} label={messageLabel} error={error("message")} className="sm:col-span-2">
          <textarea
            id={id("message")}
            name="message"
            rows={6}
            required
            placeholder="What are you building, who is it for, and when do you need it?"
            defaultValue={value("message")}
            {...invalid("message")}
            className={cn(inputClasses, "resize-y")}
          />
        </Field>

        {/* Honeypot for spam bots. Hidden from people and screen readers. */}
        <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
          <label htmlFor={id("website")}>Website</label>
          <input id={id("website")} name="website" tabIndex={-1} autoComplete="off" />
        </div>
      </div>

      <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <p aria-live="polite" className={cn("text-sm", state.status === "error" ? "text-red-600" : "text-muted")}>
          {state.status === "error" ? state.message : "We only use your details to reply to you."}
        </p>
        <button type="submit" disabled={pending} className={buttonClasses("primary", "shrink-0 px-6 py-3")}>
          {pending ? "Sending…" : "Send message"}
          {!pending && <ArrowRight className="size-4" aria-hidden="true" />}
        </button>
      </div>
    </form>
  );
}

function Field({
  id,
  label,
  optional,
  error,
  className,
  children,
}: {
  id: string;
  label: string;
  optional?: boolean;
  error?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-2 flex justify-between gap-3 text-sm font-medium">
        {label}
        {optional && <span className="font-normal text-muted">Optional</span>}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} className="mt-2 text-sm text-red-600">
          {error}
        </p>
      )}
    </div>
  );
}
