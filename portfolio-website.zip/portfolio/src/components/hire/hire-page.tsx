import Link from "next/link";
import { ArrowDown, ArrowRight, Check, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { site } from "@/data/site";
import { firstName, team } from "@/data/team";
import { featuredProjects, projectsByMember } from "@/data/projects";
import { engagementModels, nextSteps } from "@/data/hire";
import type { TeamMember } from "@/types/content";
import { Container, Section } from "@/components/ui/container";
import { Eyebrow, SectionHeading } from "@/components/ui/section-heading";
import { ButtonLink, buttonClasses } from "@/components/ui/button";
import { Avatar, Portrait } from "@/components/ui/avatar";
import { ContactForm } from "@/components/contact/contact-form";
import { ProjectCover } from "@/components/projects/project-cover";
import { Testimonials } from "@/components/sections/testimonials";
import { Faq } from "@/components/sections/faq";
import { Reveal } from "@/components/motion/reveal";
import { cn, telHref, whatsappUrl } from "@/lib/utils";
import { delay } from "@/lib/motion";

/**
 * The full Hire page. Without `member` it's the studio page (/hire);
 * with one it's addressed to that partner (/hire/<slug>).
 */
export function HirePage({ member }: { member?: TeamMember }) {
  const name = member ? firstName(member) : undefined;
  const names = team.map(firstName).join(" and ");
  const work = (member ? projectsByMember(member.slug) : featuredProjects).slice(0, 4);

  return (
    <>
      <HireHero member={member} names={names} />

      {/* The brief: who to hire, then the form */}
      <section id="brief" className="border-b border-line bg-surface">
        <Container className="py-20 sm:py-24">
          <Reveal className="max-w-2xl">
            <Eyebrow className="mb-4">Step 1</Eyebrow>
            <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Who would you like to hire?
            </h2>
          </Reveal>
          <PartnerPicker active={member?.slug} />

          <div className="mt-20 grid gap-12 lg:grid-cols-[1fr_1.6fr] lg:gap-16">
            <aside className="lg:sticky lg:top-24 lg:self-start">
              <Reveal>
                <Eyebrow className="mb-4">Step 2</Eyebrow>
                <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
                  {member ? `Tell ${name} about your project.` : "Tell us about your project."}
                </h2>
                <p className="mt-4 text-lg text-pretty text-muted">
                  A few sentences is enough. We&apos;ll come back with questions and next steps.
                </p>
              </Reveal>

              <ol className="relative mt-10 space-y-7 border-l border-line pl-8">
                {nextSteps.map((step, i) => (
                  <Reveal as="li" key={step.title} delay={i * 100} className="relative">
                    <span className="absolute top-0 -left-[45px] grid size-7 place-items-center rounded-full border border-line bg-canvas font-mono text-xs text-accent">
                      {i + 1}
                    </span>
                    <h3 className="font-semibold tracking-tight">{step.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-pretty text-muted">{step.description}</p>
                  </Reveal>
                ))}
              </ol>

              <Reveal className="mt-10 rounded-2xl border border-line bg-canvas p-6">
                <h3 className="font-semibold tracking-tight">Prefer to talk first?</h3>
                <DirectContact member={member} className="mt-4" />
              </Reveal>
            </aside>

            <Reveal delay={120}>
              <ContactForm
                key={member?.slug ?? "studio"}
                defaultPartner={member?.slug ?? ""}
                partnerField="hidden"
                messageLabel="What would you like us to build?"
              />
            </Reveal>
          </div>
        </Container>
      </section>

      <Section>
        <SectionHeading
          eyebrow="Ways to work together"
          title="Engagement."
          titleMuted="Pick what suits your project."
          description="Not sure which fits? Describe what you need in the brief and we'll suggest the right option."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {engagementModels.map((model, i) => (
            <Reveal
              key={model.title}
              delay={i * 110}
              className="spotlight flex flex-col rounded-2xl border border-line bg-surface p-7"
            >
              <span className="font-mono text-xs text-muted">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-3 text-xl font-semibold tracking-tight">{model.title}</h3>
              <p className="mt-2 text-sm text-pretty text-muted">
                <span className="font-medium text-ink">Best for:</span> {model.bestFor}
              </p>
              <ul className="mt-6 space-y-3 border-t border-line pt-6">
                {model.points.map((point) => (
                  <li key={point} className="flex gap-3 text-sm">
                    <Check className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                    {point}
                  </li>
                ))}
              </ul>
            </Reveal>
          ))}
        </div>
      </Section>

      {work.length > 0 && (
        <Section className="border-t border-line">
          <SectionHeading
            eyebrow={member ? `${name}'s work` : "Recent work"}
            title={member ? `${name}'s work.` : "Our work."}
            titleMuted={member ? `Projects ${name} has worked on.` : "What we've built for others."}
            action={
              <ButtonLink href="/projects" variant="secondary">
                All projects
              </ButtonLink>
            }
          />
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {work.map((project, i) => (
              <Reveal as="article" key={project.slug} delay={i * 90} className="group relative">
                <ProjectCover
                  project={project}
                  sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                  className="rounded-xl transition-transform duration-500 group-hover:-translate-y-1"
                />
                <p className="mt-4 font-mono text-xs uppercase tracking-[0.14em] text-muted">{project.category}</p>
                <h3 className="mt-1 font-semibold tracking-tight">
                  <Link href={`/projects/${project.slug}`} className="after:absolute after:inset-0">
                    {project.name}
                  </Link>
                </h3>
              </Reveal>
            ))}
          </div>
        </Section>
      )}

      <Testimonials />
      <Faq />

      <Container className="pb-24">
        <Reveal className="flex flex-col items-start justify-between gap-6 rounded-3xl border border-line bg-surface p-8 sm:flex-row sm:items-center sm:p-10">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Ready when you are.</h2>
            <p className="mt-1 text-muted">
              {member
                ? `${name} is ${site.availability.toLowerCase()}.`
                : `${names} are ${site.availability.toLowerCase()}.`}{" "}
              {site.responseTime}
            </p>
          </div>
          <a href="#brief" className={buttonClasses("primary")}>
            Write your brief <ArrowRight className="size-4" aria-hidden="true" />
          </a>
        </Reveal>
      </Container>
    </>
  );
}

function HireHero({ member, names }: { member?: TeamMember; names: string }) {
  const name = member ? firstName(member) : undefined;

  return (
    <header className="relative isolate overflow-hidden border-b border-line">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 right-[-10%] -z-10 size-[34rem] rounded-full bg-accent/15 blur-3xl motion-safe:animate-drift"
      />
      <Container className="grid items-center gap-12 pt-14 pb-20 sm:pt-20 lg:grid-cols-[1.1fr_1fr] lg:gap-16 lg:pb-24">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-line bg-surface/80 px-3 py-1 text-xs font-medium text-muted backdrop-blur motion-safe:animate-rise">
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full rounded-full bg-emerald-500 opacity-60 motion-safe:animate-ping" />
              <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
            </span>
            {site.availability}
          </p>

          <h1
            className="mt-6 text-4xl leading-[1.05] font-semibold tracking-tight text-balance motion-safe:animate-rise sm:text-6xl"
            style={delay(80)}
          >
            {member ? (
              <>
                Hire <span className="text-shimmer">{member.name}</span>
              </>
            ) : (
              <>
                Let&apos;s build your <span className="text-shimmer">next product.</span>
              </>
            )}
          </h1>

          <p
            className="mt-6 max-w-xl text-lg text-pretty text-muted motion-safe:animate-rise sm:text-xl"
            style={delay(160)}
          >
            {member
              ? `${member.headline} ${member.bio}`
              : `Hire ${site.name} for a full build, a single feature or ongoing support. You'll work directly with ${names}, from the first call to long after launch.`}
          </p>

          {member && (
            <ul className="mt-6 flex flex-wrap gap-2 motion-safe:animate-rise" style={delay(200)}>
              {member.location && (
                <li className="inline-flex items-center gap-1.5 rounded-full border border-line bg-surface px-3 py-1 text-sm">
                  <MapPin className="size-3.5 text-muted" aria-hidden="true" /> {member.location}
                </li>
              )}
              {member.experienceYears && (
                <li className="rounded-full border border-line bg-surface px-3 py-1 text-sm">
                  {member.experienceYears}+ years experience
                </li>
              )}
              {member.focus.map((item) => (
                <li key={item} className="rounded-full border border-line bg-surface px-3 py-1 text-sm">
                  {item}
                </li>
              ))}
            </ul>
          )}

          <div className="mt-9 flex flex-wrap gap-3 motion-safe:animate-rise" style={delay(260)}>
            <a href="#brief" className={buttonClasses("primary")}>
              Write your brief <ArrowDown className="size-4" aria-hidden="true" />
            </a>
            {member ? (
              <ButtonLink href={`/team/${member.slug}`} variant="secondary">
                View {name}&apos;s profile
              </ButtonLink>
            ) : (
              <ButtonLink href="/projects" variant="secondary">
                See our work
              </ButtonLink>
            )}
          </div>

          <DirectContact member={member} className="mt-10 motion-safe:animate-rise" style={delay(320)} />
        </div>

        {member ? (
          <div className="mx-auto w-full max-w-sm motion-safe:animate-rise lg:max-w-md" style={delay(200)}>
            <Portrait
              member={member}
              priority
              className="shadow-xl shadow-black/5"
              sizes="(min-width: 1024px) 28rem, 24rem"
            />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:gap-5">
            {team.map((person, i) => (
              <Link
                key={person.slug}
                href={`/hire/${person.slug}`}
                scroll={false}
                className={cn("group block motion-safe:animate-rise", i % 2 === 1 && "translate-y-10")}
                style={delay(200 + i * 120)}
              >
                <div className="overflow-hidden rounded-3xl shadow-xl shadow-black/5">
                  <Portrait
                    member={person}
                    priority
                    sizes="(min-width: 1024px) 22vw, 45vw"
                    className="transition-transform duration-700 ease-out-soft group-hover:scale-[1.03]"
                  />
                </div>
                <p className="mt-3 font-semibold tracking-tight group-hover:text-accent">{person.name}</p>
                <p className="text-sm text-muted">{person.role}</p>
              </Link>
            ))}
          </div>
        )}
      </Container>
    </header>
  );
}

/** Option cards linking between /hire and /hire/<slug>. The current page is highlighted. */
function PartnerPicker({ active }: { active?: string }) {
  const options = [
    {
      href: "/hire",
      key: "studio",
      title: "Both of us",
      description: `${team.map(firstName).join(" & ")} together, for complete builds from design to launch.`,
      people: team,
    },
    ...team.map((member) => ({
      href: `/hire/${member.slug}`,
      key: member.slug,
      title: member.name,
      description: member.headline,
      people: [member],
    })),
  ];

  return (
    <ul className="mt-10 grid gap-4 md:grid-cols-3">
      {options.map((option, i) => {
        const selected = (active ?? "studio") === option.key;
        return (
          <Reveal as="li" key={option.key} delay={i * 90}>
            <Link
              href={option.href}
              scroll={false}
              aria-current={selected ? "page" : undefined}
              className={cn(
                "spotlight relative flex h-full flex-col rounded-2xl border bg-canvas p-6 transition-colors",
                selected ? "border-accent ring-1 ring-accent" : "border-line hover:border-ink",
              )}
            >
              <span
                aria-hidden="true"
                className={cn(
                  "absolute top-5 right-5 grid size-6 place-items-center rounded-full border transition-colors",
                  selected ? "border-accent bg-accent text-accent-ink" : "border-line",
                )}
              >
                {selected && <Check className="size-3.5" />}
              </span>
              <span className="flex -space-x-2">
                {option.people.map((person) => (
                  <Avatar key={person.slug} member={person} size={44} className="ring-2 ring-canvas" />
                ))}
              </span>
              <span className="mt-4 block font-semibold tracking-tight">{option.title}</span>
              <span className="mt-1 block text-sm text-pretty text-muted">{option.description}</span>
            </Link>
          </Reveal>
        );
      })}
    </ul>
  );
}

function DirectContact({
  member,
  className,
  style,
}: {
  member?: TeamMember;
  className?: string;
  style?: React.CSSProperties;
}) {
  const email = member?.email || site.email;
  return (
    <ul className={cn("flex flex-wrap gap-x-6 gap-y-3 text-sm", className)} style={style}>
      <li>
        <a href={`mailto:${email}`} className="inline-flex items-center gap-2 font-medium hover:text-accent">
          <Mail className="size-4 text-muted" aria-hidden="true" /> {email}
        </a>
      </li>
      {site.whatsapp && (
        <li>
          <a
            href={whatsappUrl(site.whatsapp, site.whatsappMessage)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 font-medium hover:text-accent"
          >
            <MessageCircle className="size-4 text-muted" aria-hidden="true" /> WhatsApp
          </a>
        </li>
      )}
      {site.phones.map((phone) => (
        <li key={phone}>
          <a href={telHref(phone)} className="inline-flex items-center gap-2 font-medium hover:text-accent">
            <Phone className="size-4 text-muted" aria-hidden="true" /> {phone}
          </a>
        </li>
      ))}
    </ul>
  );
}
