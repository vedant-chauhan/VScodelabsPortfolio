import { techStack } from "@/data/company";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { Reveal } from "@/components/motion/reveal";

export function TechStack() {
  return (
    <Section id="stack" className="border-t border-line">
      <SectionHeading
        eyebrow="Tools"
        title="Our stack."
        titleMuted="We pick the tools for the project, not the other way round."
        description="Across our live projects we've worked with a broad set of tools. These are the ones we reach for most."
      />
      <dl className="divide-y divide-line border-y border-line">
        {techStack.map((group, i) => (
          <Reveal
            variant="fade"
            delay={i * 80}
            key={group.label}
            className="grid gap-3 py-5 sm:grid-cols-[200px_1fr] sm:items-center"
          >
            <dt className="font-mono text-xs uppercase tracking-[0.14em] text-muted">{group.label}</dt>
            <dd className="flex flex-wrap gap-2">
              {group.items.map((item) => (
                <span
                  key={item}
                  className="rounded-full border border-line bg-surface px-3 py-1 text-sm transition-colors hover:border-ink"
                >
                  {item}
                </span>
              ))}
            </dd>
          </Reveal>
        ))}
      </dl>
    </Section>
  );
}
