import { process } from "@/data/company";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { ProcessStack } from "./process-stack";

/** "How we work": the steps as an interactive, cycling deck of cards (Home and Services). */
export function Process() {
  return (
    <Section id="process" className="overflow-x-clip border-t border-line bg-surface">
      <ProcessStack
        steps={process}
        heading={
          <SectionHeading
            eyebrow="How we work"
            title="Process."
            titleMuted="A clear path from first call to long after launch."
            className="mb-8 sm:mb-10"
          />
        }
      />
    </Section>
  );
}
