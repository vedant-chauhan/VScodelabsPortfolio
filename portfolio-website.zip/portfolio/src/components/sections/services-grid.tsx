import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { services } from "@/data/services";
import { Icon } from "@/components/ui/icon";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { ButtonLink } from "@/components/ui/button";
import { Reveal } from "@/components/motion/reveal";
import { projects } from "@/data/projects";
import { ServicesWheel } from "./services-wheel";

/** Home-page services: the scroll "wheel" on desktop, a card grid elsewhere. */
export function ServicesGrid() {
  return (
    <Section id="services">
      <SectionHeading
        eyebrow="What we do"
        title="Services."
        titleMuted="From first idea to a product your team uses every day."
        description="We take on the whole build, or the part you need help with."
        action={
          <ButtonLink href="/services" variant="secondary">
            All services
          </ButtonLink>
        }
      />
      {/* Large screens with motion: the pinned services wheel. Everyone else: the card grid. */}
      <ServicesWheel
        items={services.map((service) => ({
          ...service,
          project: projects.find((project) => project.services.includes(service.id)),
        }))}
      />
      <div className="services-cards grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3 [&>*]:bg-surface">
        {services.map((service, i) => (
          <Reveal key={service.id} delay={(i % 3) * 90}>
            <Link
              href={`/services#${service.id}`}
              className="spotlight group flex h-full flex-col p-7 transition-colors hover:bg-surface-2 sm:p-8"
            >
              <span className="grid size-11 place-items-center rounded-xl bg-accent-soft text-accent transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110">
                <Icon name={service.icon} className="size-5" />
              </span>
              <h3 className="mt-6 text-lg font-semibold tracking-tight">{service.title}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-pretty text-muted">{service.summary}</p>
              <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-ink">
                Learn more
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
              </span>
            </Link>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
