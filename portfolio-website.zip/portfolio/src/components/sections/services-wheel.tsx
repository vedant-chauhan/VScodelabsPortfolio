"use client";

import { useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, Check } from "lucide-react";
import type { Project, Service } from "@/types/content";
import { Icon } from "@/components/ui/icon";
import { ProjectCover } from "@/components/projects/project-cover";
import { gsap, MOTION_OK, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { cn } from "@/lib/utils";

type Item = Service & { project?: Project };

/** Scroll distance per service, in viewport heights. */
const STEP_VH = 60;

/**
 * Desktop "services wheel": a tall scroll area with a sticky full-height frame.
 * Scrolling rolls the service names through the frame; the active one turns accent
 * and its details + a related project swap in beside it. Inspired by Sidejob's services list.
 *
 * Shown only on large screens with motion allowed and JavaScript running
 * (see `.services-wheel` in globals.css); everyone else gets the card grid.
 */
export function ServicesWheel({ items }: { items: Item[] }) {
  const root = useRef<HTMLDivElement>(null);
  const list = useRef<HTMLUListElement>(null);
  const bar = useRef<HTMLSpanElement>(null);
  const trigger = useRef<ScrollTrigger | null>(null);
  const [active, setActive] = useState(0);
  const n = items.length;

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(`${MOTION_OK} and (min-width: 1024px)`, () => {
        const tween = gsap.fromTo(
          list.current,
          { yPercent: -50 / n },
          { yPercent: -((n - 0.5) / n) * 100, ease: "none" },
        );
        trigger.current = ScrollTrigger.create({
          trigger: root.current,
          start: "top top+=64",
          end: "bottom bottom",
          scrub: 0.6,
          animation: tween,
          onUpdate: (self) => {
            setActive(Math.round(self.progress * (n - 1)));
            if (bar.current) bar.current.style.transform = `scaleX(${self.progress})`;
          },
        });
        return () => {
          trigger.current = null;
        };
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  /** Scroll to the point in the section where service `i` is centred. */
  const goTo = (i: number) => {
    const st = trigger.current;
    if (!st) return;
    window.scrollTo({ top: st.start + (st.end - st.start) * (i / (n - 1)), behavior: "smooth" });
  };

  const current = items[active];

  return (
    <div ref={root} className="services-wheel relative" style={{ height: `calc(100vh + ${(n - 1) * STEP_VH}vh)` }}>
      <div className="sticky top-16 flex h-[calc(100vh-4rem)] flex-col py-8">
        {/* Counter + progress */}
        <div className="flex items-center gap-4 font-mono text-xs text-muted">
          <span className="tabular-nums">
            <span className="text-ink">{String(active + 1).padStart(2, "0")}</span> / {String(n).padStart(2, "0")}
          </span>
          <span className="relative h-px flex-1 bg-line">
            <span ref={bar} className="absolute inset-0 origin-left scale-x-0 bg-accent" />
          </span>
          <span>Scroll</span>
        </div>

        <div className="grid min-h-0 flex-1 grid-cols-[1.45fr_1fr] items-center gap-14">
          {/* The rolling list of names */}
          <div className="relative h-full overflow-hidden [mask-image:linear-gradient(to_bottom,transparent,black_22%,black_78%,transparent)]">
            <ul
              ref={list}
              className="absolute inset-x-0 top-1/2 will-change-transform"
              style={{ transform: `translateY(-${50 / n}%)` }}
            >
              {items.map((item, i) => (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => goTo(i)}
                    aria-current={i === active ? "true" : undefined}
                    aria-label={item.title}
                    className={cn(
                      "flex h-[1.3em] w-full items-center text-left text-[clamp(2.5rem,4.3vw,4.5rem)] leading-none font-semibold tracking-tight whitespace-nowrap transition-[color,translate] duration-500 ease-out-soft",
                      i === active ? "translate-x-4 text-accent" : "text-ink/15 hover:text-ink/40",
                    )}
                  >
                    <span
                      aria-hidden="true"
                      className={cn(
                        "mr-4 inline-block h-[0.12em] rounded-full bg-accent transition-[width,opacity] duration-500 ease-out-soft",
                        i === active ? "w-[0.6em] opacity-100" : "w-0 opacity-0",
                      )}
                    />
                    {item.short}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Details for the active service */}
          <div key={current.id} className="motion-safe:animate-rise" style={{ animationDuration: "0.6s" }}>
            <div className="spotlight overflow-hidden rounded-3xl border border-line bg-surface">
              {current.project && (
                <div className="border-b border-line p-4">
                  <div className="rotate-[-1.5deg] transition-transform duration-700 ease-out-soft hover:rotate-0">
                    <ProjectCover project={current.project} sizes="420px" className="rounded-xl" />
                  </div>
                </div>
              )}
              <div className="p-7">
                <div className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-xl bg-accent-soft text-accent">
                    <Icon name={current.icon} className="size-5" />
                  </span>
                  <h3 className="text-xl font-semibold tracking-tight">{current.title}</h3>
                </div>
                <p className="mt-4 leading-relaxed text-pretty text-muted">{current.summary}</p>
                <ul className="mt-5 space-y-2 text-sm">
                  {current.deliverables.slice(0, 3).map((item) => (
                    <li key={item} className="flex gap-2.5">
                      <Check className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-5 text-sm">
                  {current.project ? (
                    <Link href={`/projects/${current.project.slug}`} className="link-fx text-muted hover:text-ink">
                      See it in <span className="font-medium text-ink">{current.project.name}</span>
                    </Link>
                  ) : (
                    <span />
                  )}
                  <Link
                    href={`/services#${current.id}`}
                    className="inline-flex items-center gap-1.5 font-medium hover:text-accent"
                  >
                    Learn more <ArrowRight className="size-4" aria-hidden="true" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
