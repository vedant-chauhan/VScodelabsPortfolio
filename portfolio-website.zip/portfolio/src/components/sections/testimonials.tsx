import Link from "next/link";
import { testimonials as allTestimonials } from "@/data/testimonials";
import { getProject } from "@/data/projects";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { DevNote } from "@/components/ui/dev-note";
import type { Testimonial } from "@/types/content";
import { Reveal } from "@/components/motion/reveal";

/** Client quotes. Hidden in production until at least one is added in src/data/testimonials.ts. */
export function Testimonials({ items = allTestimonials }: { items?: Testimonial[] }) {
  if (items.length === 0) {
    return process.env.NODE_ENV === "production" ? null : (
      <Section className="border-t border-line py-10 sm:py-12">
        <DevNote>
          Add client quotes in <code>src/data/testimonials.ts</code>. A testimonials section appears here once there is
          at least one. Real quotes with names are the strongest trust signal you can add.
        </DevNote>
      </Section>
    );
  }

  return (
    <Section id="testimonials" className="border-t border-line">
      <SectionHeading eyebrow="Client words" title="Kind words." titleMuted="What our clients say." />
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {items.map((item, i) => (
          <Reveal
            as="figure"
            delay={(i % 3) * 100}
            key={item.name + item.quote.slice(0, 12)}
            className="spotlight flex flex-col rounded-2xl border border-line bg-surface p-7"
          >
            <span aria-hidden="true" className="text-5xl leading-none font-semibold text-accent">
              “
            </span>
            <blockquote className="mt-2 flex-1 text-lg leading-relaxed text-pretty">{item.quote}</blockquote>
            <TestimonialAuthor item={item} />
          </Reveal>
        ))}
      </div>
    </Section>
  );
}

export function TestimonialAuthor({ item }: { item: Testimonial }) {
  const project = item.project ? getProject(item.project) : undefined;
  return (
    <figcaption className="mt-6 border-t border-line pt-5 text-sm">
      <p className="font-semibold">{item.name}</p>
      <p className="text-muted">
        {[item.title, item.company].filter(Boolean).join(", ")}
        {project && (
          <>
            {" · "}
            <Link href={`/projects/${project.slug}`} className="link-fx hover:text-ink">
              {project.name}
            </Link>
          </>
        )}
      </p>
    </figcaption>
  );
}
