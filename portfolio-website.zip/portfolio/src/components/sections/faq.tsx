import { Plus } from "lucide-react";
import { faqs } from "@/data/company";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { Reveal } from "@/components/motion/reveal";

export function Faq() {
  return (
    <Section id="faq" className="border-t border-line">
      <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr]">
        <SectionHeading eyebrow="FAQ" title="Questions." titleMuted="The ones we hear most often." className="mb-0 self-start sm:mb-0" />
        <div className="divide-y divide-line border-y border-line">
          {faqs.map((faq, i) => (
            <Reveal as="details" variant="fade" delay={i * 70} key={faq.question} className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 font-medium [&::-webkit-details-marker]:hidden">
                {faq.question}
                <Plus
                  className="size-5 shrink-0 text-muted transition-transform group-open:rotate-45"
                  aria-hidden="true"
                />
              </summary>
              <p className="mt-3 max-w-prose leading-relaxed text-pretty text-muted">{faq.answer}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </Section>
  );
}
