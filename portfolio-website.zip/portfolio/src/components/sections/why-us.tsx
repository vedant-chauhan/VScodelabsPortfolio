import { Check } from "lucide-react";
import { highlights, stats } from "@/data/company";
import { featuredProjects } from "@/data/projects";
import { services } from "@/data/services";
import { team } from "@/data/team";
import type { Stat } from "@/types/content";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { Avatar } from "@/components/ui/avatar";
import { Icon } from "@/components/ui/icon";
import { ProjectCover } from "@/components/projects/project-cover";
import { CountUp } from "@/components/motion/count-up";
import { Reveal } from "@/components/motion/reveal";
import { cn } from "@/lib/utils";

/** Tile sizes for the bento grid, in order: one large, two small, one wide. */
const LAYOUT = ["lg:col-span-2 lg:row-span-2", "lg:col-span-1", "lg:col-span-1", "lg:col-span-2"];

export function WhyUs() {
  return (
    <Section id="why-us" className="border-t border-line bg-surface">
      <SectionHeading
        eyebrow="Why clients work with us"
        title="Why us."
        titleMuted="A small team you can actually rely on."
        description="No account managers or hand-offs in between. The people you meet on the first call are the people who build, launch and look after your product."
      />

      <dl className="grid auto-rows-[minmax(12rem,auto)] gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, i) => (
          <Reveal
            key={stat.label}
            variant="scale"
            delay={i * 90}
            className={cn(
              "spotlight group relative flex flex-col overflow-hidden rounded-3xl border border-line bg-canvas p-6 sm:p-7",
              LAYOUT[i % LAYOUT.length],
            )}
          >
            <dt className="order-2 mt-1 text-sm text-pretty text-muted">{stat.label}</dt>
            <dd
              className={cn(
                "font-semibold tracking-tight tabular-nums",
                i === 0 ? "text-6xl sm:text-7xl" : "text-4xl sm:text-5xl",
              )}
            >
              {stat.prefix}
              <CountUp value={stat.value} />
              <span className="text-accent">{stat.suffix}</span>
            </dd>
            {stat.visual && (
              <div aria-hidden="true" className="order-3 mt-auto pt-6">
                <StatVisual visual={stat.visual} />
              </div>
            )}
          </Reveal>
        ))}
      </dl>

      <ul className="mt-12 grid gap-x-10 gap-y-8 sm:grid-cols-2 lg:grid-cols-4">
        {highlights.map((item, i) => (
          <Reveal as="li" delay={i * 90} key={item.title} className="flex gap-4">
            <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-full bg-accent-soft text-accent">
              <Check className="size-4" aria-hidden="true" />
            </span>
            <div>
              <p className="font-semibold tracking-tight">{item.title}</p>
              <p className="mt-1 text-sm leading-relaxed text-pretty text-muted">{item.description}</p>
            </div>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}

function StatVisual({ visual }: { visual: NonNullable<Stat["visual"]> }) {
  switch (visual) {
    case "projects":
      // A fanned stack of project covers that spreads out on hover.
      return (
        <div className="relative mx-auto h-44 w-full max-w-md sm:h-56">
          {featuredProjects.slice(0, 4).map((project, i) => (
            <div
              key={project.slug}
              className="fan-card absolute bottom-0 left-1/2 w-[58%]"
              style={
                {
                  "--r": `${(i - 1.5) * 7}deg`,
                  "--x": `${(i - 1.5) * 22}%`,
                  "--x2": `${(i - 1.5) * 36}%`,
                  zIndex: i,
                } as React.CSSProperties
              }
            >
              <div className="transition-transform duration-700 ease-out-soft group-hover:-translate-y-3">
                <ProjectCover project={project} sizes="240px" className="rounded-xl shadow-lg shadow-black/10" />
              </div>
            </div>
          ))}
        </div>
      );
    case "team":
      return (
        <div className="flex -space-x-3">
          {team.map((member) => (
            <Avatar
              key={member.slug}
              member={member}
              size={52}
              className="ring-4 ring-canvas transition-transform duration-300 group-hover:-translate-y-1 group-hover:rotate-[-4deg]"
            />
          ))}
        </div>
      );
    case "reply":
      // A chat bubble with typing dots.
      return (
        <div className="inline-flex items-center gap-1.5 rounded-2xl rounded-bl-sm bg-accent-soft px-4 py-3">
          {[0, 1, 2].map((dot) => (
            <span
              key={dot}
              className="size-2 rounded-full bg-accent motion-safe:animate-bounce"
              style={{ animationDelay: `${dot * 150}ms` }}
            />
          ))}
        </div>
      );
    case "services":
      return (
        <div className="flex flex-wrap gap-2">
          {services.map((service, i) => (
            <span
              key={service.id}
              className="grid size-11 place-items-center rounded-xl bg-accent-soft text-accent transition-transform duration-300 group-hover:-translate-y-1"
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              <Icon name={service.icon} className="size-5" />
            </span>
          ))}
        </div>
      );
  }
}
