import { ArrowRight } from "lucide-react";
import { site } from "@/data/site";
import { featuredProjects } from "@/data/projects";
import { marquee } from "@/data/company";
import { firstName, team } from "@/data/team";
import { ButtonLink } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import { Avatar } from "@/components/ui/avatar";
import { ProjectCover } from "@/components/projects/project-cover";
import { Marquee } from "@/components/motion/marquee";
import { delay } from "@/lib/motion";
import { HeroParallax } from "@/components/motion/hero-parallax";

export function Hero() {
  const covers = featuredProjects.slice(0, 4);
  const names = team.map(firstName).join(" & ");

  return (
    <section className="relative isolate overflow-hidden border-b border-line">
      <HeroBackdrop />

      <Container className="grid items-center gap-14 pt-16 pb-20 sm:pt-24 lg:grid-cols-[1.05fr_1fr] lg:gap-10 lg:pb-28">
        <div>
          <p
            className="inline-flex items-center gap-2 rounded-full border border-line bg-surface/80 px-3 py-1 text-xs font-medium text-muted backdrop-blur motion-safe:animate-rise"
            style={delay(0)}
          >
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full rounded-full bg-emerald-500 opacity-60 motion-safe:animate-ping" />
              <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
            </span>
            {site.availability}
          </p>

          <h1 className="mt-6 text-[2.6rem] leading-[1.05] font-semibold tracking-tight text-balance sm:text-6xl lg:text-[4.25rem]">
            <span className="block motion-safe:animate-rise" style={delay(80)}>
              We build the software
            </span>
            <span className="block motion-safe:animate-rise" style={delay(160)}>
              your business{" "}
              <span className="relative whitespace-nowrap text-accent">
                <span className="text-shimmer">runs on.</span>
                <svg
                  aria-hidden="true"
                  viewBox="0 0 220 12"
                  preserveAspectRatio="none"
                  className="absolute -bottom-1 left-0 h-[0.18em] w-full"
                >
                  <path
                    d="M2 9C50 3 120 2 218 6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeLinecap="round"
                    pathLength={1}
                    className="motion-safe:[animation:draw_1.1s_var(--ease-out-soft)_0.7s_both] [stroke-dasharray:1]"
                  />
                </svg>
              </span>
            </span>
          </h1>

          <p
            className="mt-6 max-w-xl text-lg text-pretty text-muted motion-safe:animate-rise sm:text-xl"
            style={delay(260)}
          >
            {site.name} is a two-partner studio. We design, build and maintain e-commerce stores, SaaS platforms, custom
            business software and AI chatbots, and we stay on after launch.
          </p>

          <div className="mt-9 flex flex-wrap gap-3 motion-safe:animate-rise" style={delay(340)}>
            <ButtonLink href="/hire">
              Start a project{" "}
              <ArrowRight className="size-4 transition-transform group-hover/btn:translate-x-0.5" aria-hidden="true" />
            </ButtonLink>
            <ButtonLink href="/projects" variant="secondary">
              See our work
            </ButtonLink>
          </div>

          <a
            href="#team"
            className="group mt-10 inline-flex items-center gap-3 motion-safe:animate-rise"
            style={delay(420)}
          >
            <span className="flex -space-x-2">
              {team.map((member) => (
                <Avatar key={member.slug} member={member} size={36} className="ring-2 ring-canvas" />
              ))}
            </span>
            <span className="text-sm text-muted">
              Work directly with the founders,{" "}
              <span className="link-fx link-fx-group font-medium text-ink">{names}</span>
            </span>
          </a>
        </div>

        <HeroParallax className="grid grid-cols-2 gap-4 sm:gap-5" aria-hidden="true">
          {covers.map((project, i) => (
            <div key={project.slug} className={i % 2 === 1 ? "translate-y-8" : ""}>
              <div className="motion-safe:animate-rise" style={delay(300 + i * 110)}>
                {/* Mouse parallax layer: each cover sits at a different depth. */}
                <div data-depth={[1, 0.55, 0.8, 1.25][i % 4]}>
                  <div className="motion-safe:animate-float" style={{ animationDelay: `${-i * 1.8}s` }}>
                    <ProjectCover
                      project={project}
                      priority={i < 2}
                      sizes="(min-width: 1024px) 25vw, 50vw"
                      className="shadow-xl shadow-black/5"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </HeroParallax>
      </Container>

      <div className="border-t border-line bg-surface py-6 text-2xl font-semibold tracking-tight text-muted sm:py-8 sm:text-3xl">
        <Marquee items={marquee} />
      </div>
    </section>
  );
}

/** Dotted grid and slowly drifting colour glows behind the hero. */
function HeroBackdrop() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
      <div className="absolute inset-0 [background-image:radial-gradient(var(--line)_1px,transparent_1px)] [background-size:24px_24px] [mask-image:radial-gradient(ellipse_at_70%_30%,black,transparent_70%)]" />
      {/* Glows drift against the mouse (data-depth is negative). */}
      <div data-depth="-1.6" className="absolute inset-0">
        <div className="absolute -top-40 right-[-10%] size-[36rem] rounded-full bg-accent/15 blur-3xl motion-safe:animate-drift" />
      </div>
      <div data-depth="-1" className="absolute inset-0">
        <div
          className="absolute top-1/2 right-[30%] size-[22rem] rounded-full bg-[#f6b35c]/15 blur-3xl motion-safe:animate-drift"
          style={{ animationDelay: "-8s" }}
        />
      </div>
    </div>
  );
}
