import { featuredProjects } from "@/data/projects";
import { ProjectCard } from "@/components/projects/project-card";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { ButtonLink } from "@/components/ui/button";
import { Reveal } from "@/components/motion/reveal";

export function FeaturedWork() {
  return (
    <Section id="work" className="border-t border-line">
      <SectionHeading
        eyebrow="Selected work"
        title="Work."
        titleMuted="Products we've shipped and still look after."
        description="Online retail, SaaS, factory operations and conversational AI, each built for a real business and running in production."
        action={
          <ButtonLink href="/projects" variant="secondary">
            All projects
          </ButtonLink>
        }
      />
      <div className="grid gap-x-8 gap-y-14 md:grid-cols-2">
        {featuredProjects.map((project, i) => (
          <Reveal delay={(i % 2) * 140} key={project.slug}>
            <ProjectCard project={project} />
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
