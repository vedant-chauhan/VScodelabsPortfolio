import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { site } from "@/data/site";
import { Container } from "@/components/ui/container";
import { buttonClasses } from "@/components/ui/button";
import { Reveal } from "@/components/motion/reveal";

export function Cta({
  title = "Have a project in mind?",
  description = "Tell us what you're building. We'll get back with questions, a rough timeline and next steps.",
}: {
  title?: string;
  description?: string;
}) {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <Reveal
          variant="scale"
          className="relative overflow-hidden rounded-3xl bg-ink px-6 py-14 text-canvas sm:px-12 sm:py-20"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 -right-24 size-80 rounded-full bg-accent opacity-40 blur-3xl motion-safe:animate-drift"
          />
          <div className="relative max-w-2xl">
            <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-5xl">{title}</h2>
            <p className="mt-5 text-lg text-pretty opacity-70">{description}</p>
            <div className="mt-9 flex flex-wrap items-center gap-x-6 gap-y-4">
              <Link href="/hire" className={buttonClasses("inverse")}>
                Start a project{" "}
                <ArrowRight
                  className="size-4 transition-transform group-hover/btn:translate-x-0.5"
                  aria-hidden="true"
                />
              </Link>
              <a href={`mailto:${site.email}`} className="text-sm font-medium opacity-80 hover:opacity-100">
                or email {site.email}
              </a>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
