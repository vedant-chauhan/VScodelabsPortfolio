"use client";

import { useRef, useState } from "react";
import { ArrowRight, ChevronLeft, ChevronRight, Hand, MousePointerClick, RotateCcw } from "lucide-react";
import type { ProcessStep } from "@/types/content";
import { Icon } from "@/components/ui/icon";
import { gsap, MOTION_OK, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { cn } from "@/lib/utils";

/** A colour per step, from the theme's palette. */
const TONES = [
  "var(--accent)",
  "var(--kind-founder)",
  "var(--kind-freelance)",
  "var(--kind-milestone)",
  "var(--kind-education)",
];

/** How far (px) each card behind peeks out above the one in front of it. */
const PEEK = 18;
/** Cards deeper than this sit hidden behind the deck. */
const VISIBLE_BEHIND = 3;

type Pose = { y: number; scale: number; rotation: number; opacity: number; shade: number; zIndex: number };

/** Where a card sits when it is `offset` places behind the front card. */
function pose(offset: number, n: number): Pose {
  const depth = Math.min(offset, VISIBLE_BEHIND);
  return {
    y: -depth * PEEK,
    scale: 1 - depth * 0.05,
    rotation: [0, -1.4, 1.2, -0.8][depth],
    opacity: offset > VISIBLE_BEHIND ? 0 : 1,
    shade: depth * 0.16,
    zIndex: n - offset,
  };
}

const pad = (i: number) => String(i + 1).padStart(2, "0");

/**
 * "How we work" as an interactive deck of cards.
 * Click or tap the front card (or swipe it on touch screens) and it drops away,
 * slips behind the deck and settles at the back while the others step forward,
 * cycling endlessly. Buttons, step links and dots offer the same moves for
 * keyboard users; screen readers get a live announcement and the full list.
 */
export function ProcessStack({ steps, heading }: { steps: ProcessStep[]; heading: React.ReactNode }) {
  const n = steps.length;
  const root = useRef<HTMLDivElement>(null);
  const deck = useRef<HTMLDivElement>(null);
  const cards = useRef<(HTMLDivElement | null)[]>([]);
  /** Card indices from front to back. */
  const order = useRef<number[]>(steps.map((_, i) => i));
  const timeline = useRef<gsap.core.Timeline | null>(null);
  const drag = useRef({ id: -1, x: 0, y: 0, dx: 0, moved: false });
  const [active, setActive] = useState(0);

  const shadeOf = (el: HTMLElement) => el.querySelector<HTMLElement>("[data-shade]");

  const { context } = useGSAP(
    () => {
      // Hand the server-rendered poses over to GSAP.
      order.current.forEach((ci, offset) => {
        const el = cards.current[ci];
        if (!el) return;
        const p = pose(offset, n);
        gsap.set(el, {
          y: p.y,
          scale: p.scale,
          rotation: p.rotation,
          opacity: p.opacity,
          zIndex: p.zIndex,
          transformOrigin: "50% 0%",
        });
        gsap.set(shadeOf(el), { opacity: p.shade });
      });

      // The first time the deck scrolls into view, give it a little wiggle to show it's interactive.
      const mm = gsap.matchMedia();
      mm.add(MOTION_OK, () => {
        ScrollTrigger.create({
          trigger: deck.current,
          start: "top 70%",
          once: true,
          onEnter: () => {
            const front = cards.current[order.current[0]];
            if (!front || timeline.current?.isActive()) return;
            gsap
              .timeline({ delay: 0.4 })
              .to(front, { rotation: -3, y: -10, duration: 0.25, ease: "power2.out" })
              .to(front, { rotation: 2, y: -4, duration: 0.2, ease: "power2.inOut" })
              .to(front, { rotation: 0, y: 0, duration: 0.5, ease: "elastic.out(1, 0.5)" });
          },
        });
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  /** Move the deck one card forward (dir 1) or back (dir -1). `fling` is the swipe direction, if any. */
  // Runs from event handlers only; `context.add` records the animations so they're cleaned up on unmount.
  const move = (dir: 1 | -1, opts: { fling?: number; speed?: number } = {}): gsap.core.Timeline =>
    context.add(() => {
      timeline.current?.progress(1); // finish any animation in flight so rapid taps stay responsive

      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const k = reduce ? 0 : (opts.speed ?? 1); // duration multiplier
      const prev = order.current;
      const next = dir === 1 ? [...prev.slice(1), prev[0]] : [prev[n - 1], ...prev.slice(0, n - 1)];
      order.current = next;
      setActive(next[0]);

      const first = cards.current[next[0]];
      const H = first?.offsetHeight ?? 360;
      const W = first?.offsetWidth ?? 480;
      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
      timeline.current = tl;

      const settle = (el: HTMLElement, p: Pose, at: number, duration = 0.6) => {
        tl.to(
          el,
          { x: 0, y: p.y, scale: p.scale, rotation: p.rotation, opacity: p.opacity, duration: duration * k },
          at,
        );
        tl.to(shadeOf(el), { opacity: p.shade, duration: duration * k }, at);
      };

      if (dir === 1) {
        // The front card drops away, slips behind the deck and settles at the back…
        const out = cards.current[prev[0]]!;
        const fling = opts.fling ?? 0;
        gsap.set(out, { zIndex: n + 1 });
        tl.to(
          out,
          {
            y: H * 0.42,
            x: fling * W * 0.55,
            rotation: fling ? fling * 9 : -5,
            scale: 0.96,
            duration: 0.32 * k,
            ease: "power2.in",
          },
          0,
        );
        tl.set(out, { zIndex: 0 }, 0.32 * k);
        settle(out, pose(n - 1, n), 0.32 * k, 0.6);
        // …while every other card steps one place forward.
        next.slice(0, n - 1).forEach((ci, offset) => {
          const el = cards.current[ci]!;
          gsap.set(el, { zIndex: n - offset });
          settle(el, pose(offset, n), (0.1 + offset * 0.04) * k);
        });
      } else {
        // The back card slides out from under the deck and rises to the front…
        const inc = cards.current[next[0]]!;
        gsap.set(inc, { zIndex: 0 });
        tl.to(inc, { y: H * 0.42, rotation: 5, scale: 0.96, opacity: 1, duration: 0.32 * k, ease: "power2.in" }, 0);
        tl.to(shadeOf(inc), { opacity: 0, duration: 0.32 * k }, 0);
        tl.set(inc, { zIndex: n + 1 }, 0.32 * k);
        settle(inc, pose(0, n), 0.32 * k, 0.6);
        // …while the others step one place back.
        next.slice(1).forEach((ci, i) => {
          const el = cards.current[ci]!;
          gsap.set(el, { zIndex: n - (i + 1) });
          settle(el, pose(i + 1, n), (0.05 + i * 0.03) * k);
        });
      }
      // Tidy stacking order once everything has landed.
      tl.add(() => next.forEach((ci, offset) => gsap.set(cards.current[ci], { zIndex: n - offset })));
      return tl;
    });

  /** Bring any step to the front by riffling through the deck the short way round. */
  const goTo = async (target: number) => {
    const pos = order.current.indexOf(target);
    if (pos <= 0) return;
    const forward = pos <= n / 2;
    const count = forward ? pos : n - pos;
    for (let s = 0; s < count; s++) {
      await move(forward ? 1 : -1, { speed: 0.55 });
    }
  };

  // ---- Tap / swipe on the front card ----
  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>, ci: number) => {
    if (ci !== order.current[0] || e.button !== 0) return;
    drag.current = { id: e.pointerId, x: e.clientX, y: e.clientY, dx: 0, moved: false };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = drag.current;
    if (d.id !== e.pointerId) return;
    d.dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    if (!d.moved && Math.abs(d.dx) > 6 && Math.abs(d.dx) > Math.abs(dy)) d.moved = true;
    if (d.moved) gsap.set(e.currentTarget, { x: d.dx, rotation: d.dx * 0.05 });
  };
  const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = drag.current;
    if (d.id !== e.pointerId) return;
    drag.current.id = -1;
    if (!d.moved) return void move(1); // a tap or click
    if (Math.abs(d.dx) > 70) return void move(1, { fling: Math.sign(d.dx) });
    const card = e.currentTarget;
    context.add(() => gsap.to(card, { x: 0, rotation: 0, duration: 0.45, ease: "back.out(2)" })); // not far enough: snap back
  };
  const onPointerCancel = (e: React.PointerEvent<HTMLDivElement>) => {
    if (drag.current.id !== e.pointerId) return;
    drag.current.id = -1;
    const card = e.currentTarget;
    context.add(() => gsap.to(card, { x: 0, rotation: 0, duration: 0.35, ease: "power2.out" }));
  };

  const current = steps[active];

  return (
    <div ref={root} className="grid items-center gap-12 lg:grid-cols-[1fr_1.15fr] lg:gap-20">
      <div>
        {heading}
        {/* Step list (desktop): shows where you are and jumps straight to a step. */}
        <ol className="hidden space-y-1 lg:block">
          {steps.map((step, i) => {
            const on = i === active;
            return (
              <li key={step.title}>
                <button
                  type="button"
                  onClick={() => goTo(i)}
                  aria-current={on ? "step" : undefined}
                  className={cn(
                    "group flex w-full items-center gap-4 rounded-xl px-3 py-2.5 text-left transition-colors",
                    on ? "bg-canvas" : "hover:bg-canvas/60",
                  )}
                >
                  <span className={cn("font-mono text-xs transition-colors", on ? "text-ink" : "text-muted")}>
                    {pad(i)}
                  </span>
                  <span
                    className="h-0.5 rounded-full transition-[width] duration-500 ease-out-soft"
                    style={{ width: on ? 28 : 12, background: TONES[i % TONES.length] }}
                  />
                  <span
                    className={cn("transition-colors", on ? "font-medium text-ink" : "text-muted group-hover:text-ink")}
                  >
                    {step.title}
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
      </div>

      <div>
        {/* The deck. Visual only: the controls below and the live region carry the same information. */}
        <div
          ref={deck}
          aria-hidden="true"
          className="relative mx-auto h-[calc(23rem+3.5rem)] max-w-xl sm:h-[calc(24rem+3.5rem)]"
        >
          {steps.map((step, i) => {
            const tone = TONES[i % TONES.length];
            const p = pose(i, n);
            const last = i === n - 1;
            return (
              <div
                key={step.title}
                ref={(el) => {
                  cards.current[i] = el;
                }}
                data-front={i === active}
                onPointerDown={(e) => onPointerDown(e, i)}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerCancel={onPointerCancel}
                className="process-card absolute inset-x-0 top-[3.375rem] h-[23rem] touch-pan-y select-none sm:h-[24rem]"
                // Server-rendered starting pose (card 1 in front); GSAP takes over after hydration.
                style={{
                  zIndex: p.zIndex,
                  opacity: p.opacity,
                  transform: `translateY(${p.y}px) scale(${p.scale}) rotate(${p.rotation}deg)`,
                  transformOrigin: "50% 0%",
                }}
              >
                <div className="process-card__body relative h-full overflow-hidden rounded-3xl border border-line bg-canvas">
                  <span aria-hidden="true" className="absolute inset-x-0 top-0 h-1.5" style={{ background: tone }} />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute -right-3 -bottom-8 text-[10rem] leading-none font-semibold tracking-tighter text-ink/[0.04] sm:text-[12rem]"
                  >
                    {pad(i)}
                  </span>

                  <div className="relative flex h-full flex-col p-7 sm:p-9">
                    <div className="flex items-center justify-between gap-6">
                      <span className="font-mono text-sm" style={{ color: tone }}>
                        Step {pad(i)} <span className="text-muted">/ {String(n).padStart(2, "0")}</span>
                      </span>
                      <span
                        className="grid size-12 place-items-center rounded-2xl"
                        style={{ background: `color-mix(in srgb, ${tone} 14%, transparent)`, color: tone }}
                      >
                        <Icon name={step.icon} className="size-6" />
                      </span>
                    </div>

                    <div className="mt-auto">
                      <h3 className="text-3xl font-semibold tracking-tight sm:text-4xl">{step.title}</h3>
                      <p className="mt-3 max-w-md text-lg leading-relaxed text-pretty text-muted">{step.description}</p>
                    </div>

                    <div className="mt-7 flex items-center justify-between gap-4 border-t border-line pt-5 text-sm">
                      <span className="text-muted">
                        {last ? "Back to" : "Next:"}{" "}
                        <span className="font-medium text-ink">{steps[last ? 0 : i + 1].title}</span>
                      </span>
                      <span className="process-card__cue grid size-9 place-items-center rounded-full border border-line">
                        {last ? <RotateCcw className="size-4" /> : <ArrowRight className="size-4" />}
                      </span>
                    </div>
                  </div>

                  {/* Dims cards further back in the deck. */}
                  <div
                    data-shade=""
                    className="pointer-events-none absolute inset-0 bg-surface"
                    style={{ opacity: p.shade }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Controls */}
        <div className="mx-auto mt-8 flex max-w-xl items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => move(-1)}
            aria-label="Previous step"
            className="magnetic grid size-11 place-items-center rounded-full border border-line bg-canvas hover:border-ink"
          >
            <ChevronLeft className="size-5" aria-hidden="true" />
          </button>

          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center gap-2">
              {steps.map((step, i) => (
                <button
                  key={step.title}
                  type="button"
                  onClick={() => goTo(i)}
                  aria-label={`Go to step ${i + 1}: ${step.title}`}
                  aria-current={i === active ? "step" : undefined}
                  className="h-2 rounded-full transition-[width,background-color] duration-500 ease-out-soft"
                  style={{
                    width: i === active ? 28 : 8,
                    background: i === active ? TONES[i % TONES.length] : "var(--line)",
                  }}
                />
              ))}
            </div>
            <p className="flex items-center gap-1.5 text-xs text-muted">
              <MousePointerClick className="size-3.5 pointer-coarse:hidden" aria-hidden="true" />
              <Hand className="size-3.5 pointer-fine:hidden" aria-hidden="true" />
              <span className="pointer-coarse:hidden">Click the card for the next step</span>
              <span className="pointer-fine:hidden">Tap or swipe the card</span>
            </p>
          </div>

          <button
            type="button"
            onClick={() => move(1)}
            aria-label="Next step"
            className="magnetic grid size-11 place-items-center rounded-full bg-ink text-canvas hover:bg-accent hover:text-accent-ink"
          >
            <ChevronRight className="size-5" aria-hidden="true" />
          </button>
        </div>

        {/* Screen readers: announce the current step, and list them all. */}
        <p aria-live="polite" className="sr-only">
          Step {active + 1} of {n}: {current.title}. {current.description}
        </p>
        <ol className="sr-only">
          {steps.map((step, i) => (
            <li key={step.title}>
              Step {i + 1}: {step.title}. {step.description}
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
