import { ViewTransition } from "react";
import Link from "next/link";
import { ArrowRight, MapPin } from "lucide-react";
import { team } from "@/data/team";
import { projectsByMember } from "@/data/projects";
import { Section } from "@/components/ui/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { Portrait } from "@/components/ui/avatar";
import { withHref } from "@/lib/utils";
import { HireButton } from "@/components/contact/hire-button";
import type { TeamMember } from "@/types/content";
import { Reveal } from "@/components/motion/reveal";

export function Team({
  eyebrow = "Meet the founders",
  title = "The founders.",
  titleMuted = "The two people behind every project.",
  description = "You work directly with the partners who plan, design, build and support your product, from the first call to long after launch.",
  className,
}: {
  eyebrow?: string;
  title?: string;
  titleMuted?: string;
  description?: string;
  className?: string;
}) {
  return (
    <Section id="team" className={className ?? "border-t border-line"}>
      <SectionHeading eyebrow={eyebrow} title={title} titleMuted={titleMuted} description={description} />
      <div className="grid gap-8 md:grid-cols-2">
        {team.map((member, i) => (
          <Reveal delay={i * 140} key={member.slug}>
            <FounderCard member={member} />
          </Reveal>
        ))}
      </div>
    </Section>
  );
}

function FounderCard({ member }: { member: TeamMember }) {
  const links = withHref(member.links);
  const projects = projectsByMember(member.slug);

  return (
    <article className="spotlight group relative flex h-full flex-col overflow-hidden rounded-3xl border border-line bg-surface">
      <div className="overflow-hidden">
        {/* Morphs into the portrait on the profile page. */}
        <ViewTransition name={`portrait-${member.slug}`} share="morph" default="none">
          <Portrait
            member={member}
            aspect="aspect-[5/4]"
            className="rounded-none transition-transform duration-700 ease-out-soft group-hover:scale-[1.03]"
            sizes="(min-width: 768px) 50vw, 100vw"
          />
        </ViewTransition>
      </div>

      <div className="flex flex-1 flex-col p-7 sm:p-8">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted">
          <span className="font-medium text-accent">{member.role}</span>
          {member.location && (
            <span className="inline-flex items-center gap-1">
              <MapPin className="size-3.5" aria-hidden="true" /> {member.location}
            </span>
          )}
          {member.experienceYears && <span>{member.experienceYears}+ years experience</span>}
        </div>

        <h3 className="mt-3 text-2xl font-semibold tracking-tight">
          <Link href={`/team/${member.slug}`} className="after:absolute after:inset-0">
            {member.name}
          </Link>
        </h3>
        <p className="mt-1 font-medium">{member.headline}</p>
        <p className="mt-4 leading-relaxed text-pretty text-muted">{member.bio}</p>

        <ul className="mt-5 flex flex-wrap gap-2">
          {member.focus.map((item) => (
            <li key={item} className="rounded-full bg-surface-2 px-3 py-1 text-xs font-medium">
              {item}
            </li>
          ))}
        </ul>

        {projects.length > 0 && (
          <p className="mt-5 text-sm text-muted">
            <span className="font-medium text-ink">Worked on:</span>{" "}
            {projects.map((project) => project.name).join(", ")}
          </p>
        )}

        <div className="mt-auto flex flex-wrap items-center gap-x-6 gap-y-4 pt-7">
          {/* z-10 keeps the button above the card's full-size profile link. */}
          <HireButton partner={member.slug} className="relative z-10" />
          <span className="inline-flex items-center gap-1.5 text-sm font-medium">
            View full profile
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
          </span>
          {links.length > 0 && (
            <span className="relative z-10 ml-auto flex gap-4 text-sm font-medium">
              {links.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="link-fx hover:text-accent"
                >
                  {link.label} ↗
                </a>
              ))}
            </span>
          )}
        </div>
      </div>
    </article>
  );
}
