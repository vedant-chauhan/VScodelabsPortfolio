/**
 * Wraps each word in a mask so it can rise into view (see .word-mask / .word in globals.css).
 * Inside a <Reveal> the words rise on scroll; add the `words-on-load` class to a parent to animate on page load.
 */
export function SplitWords({
  text,
  offset = 0,
}: {
  text: string;
  /** Index of the first word, to continue a stagger. */ offset?: number;
}) {
  const words = text.split(" ");
  return (
    <>
      {words.map((word, i) => (
        <span key={i}>
          <span className="word-mask">
            <span className="word" style={{ "--i": offset + i } as React.CSSProperties}>
              {word}
            </span>
          </span>
          {i < words.length - 1 && " "}
        </span>
      ))}
    </>
  );
}
