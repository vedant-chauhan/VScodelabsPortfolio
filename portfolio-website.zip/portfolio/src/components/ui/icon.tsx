import {
  Bot,
  CodeXml,
  Compass,
  Factory,
  Globe,
  LayoutDashboard,
  LifeBuoy,
  PenTool,
  Rocket,
  ShoppingBag,
  Wrench,
  type LucideProps,
} from "lucide-react";
import type { IconName } from "@/types/content";

const icons = {
  "shopping-bag": ShoppingBag,
  "layout-dashboard": LayoutDashboard,
  factory: Factory,
  bot: Bot,
  globe: Globe,
  "life-buoy": LifeBuoy,
  compass: Compass,
  "pen-tool": PenTool,
  code: CodeXml,
  rocket: Rocket,
  wrench: Wrench,
} satisfies Record<IconName, React.ComponentType<LucideProps>>;

export function Icon({ name, ...props }: { name: IconName } & LucideProps) {
  const Component = icons[name];
  return <Component aria-hidden="true" {...props} />;
}
