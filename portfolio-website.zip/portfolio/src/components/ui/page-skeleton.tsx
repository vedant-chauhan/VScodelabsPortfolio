/** Placeholder shown for a split second while a case study or profile page streams in. */
export function PageSkeleton() {
  return (
    <div aria-busy="true" aria-label="Loading" className="mx-auto w-full max-w-6xl px-4 pt-14 pb-24 sm:px-6 lg:px-8">
      <div className="h-4 w-24 rounded-full bg-surface-2 motion-safe:animate-pulse" />
      <div className="mt-10 h-14 w-2/3 rounded-2xl bg-surface-2 motion-safe:animate-pulse" />
      <div className="mt-6 h-5 w-1/2 rounded-full bg-surface-2 motion-safe:animate-pulse" />
      <div className="mt-14 aspect-[16/7] rounded-3xl bg-surface-2 motion-safe:animate-pulse" />
    </div>
  );
}
