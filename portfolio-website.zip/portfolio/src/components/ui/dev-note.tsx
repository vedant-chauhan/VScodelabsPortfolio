/**
 * A reminder about missing content. Shown only while running `npm run dev`;
 * it is never rendered in a production build.
 */
export function DevNote({ children }: { children: React.ReactNode }) {
  if (process.env.NODE_ENV === "production") return null;
  return (
    <div className="rounded-2xl border border-dashed border-accent/50 bg-accent-soft/40 px-5 py-4 font-mono text-xs leading-relaxed text-accent">
      <strong className="font-semibold">To do: </strong>
      {children}
      <span className="mt-1 block opacity-70">This note only appears in development.</span>
    </div>
  );
}
