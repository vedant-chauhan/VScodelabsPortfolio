import Image from "next/image";
import type { TeamMember } from "@/types/content";
import { cn } from "@/lib/utils";

function initials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2);
}

/** Large portrait: the partner's photo, or a styled initials card until one is added. */
export function Portrait({
  member,
  className,
  aspect = "aspect-[4/5]",
  sizes = "(min-width: 768px) 40vw, 100vw",
  priority,
}: {
  member: TeamMember;
  className?: string;
  /** Tailwind aspect-ratio class. */
  aspect?: string;
  sizes?: string;
  priority?: boolean;
}) {
  return (
    <div className={cn("relative overflow-hidden rounded-3xl bg-surface-2", aspect, className)}>
      {member.photo ? (
        <Image
          src={member.photo}
          alt={`Portrait of ${member.name}`}
          fill
          sizes={sizes}
          // `priority` is deprecated in Next 16; load the above-the-fold portrait eagerly instead.
          loading={priority ? "eager" : undefined}
          fetchPriority={priority ? "high" : undefined}
          // Faces sit in the upper third of a portrait, so landscape crops keep that area in view.
          className="object-cover object-[50%_20%]"
        />
      ) : (
        <div
          aria-hidden="true"
          className="absolute inset-0 grid place-items-center"
          style={{
            background:
              "radial-gradient(120% 80% at 20% 0%, var(--accent-soft), transparent 60%), radial-gradient(100% 70% at 100% 100%, var(--accent-soft), transparent 55%), var(--surface-2)",
          }}
        >
          <div className="absolute inset-0 opacity-40 [background-image:radial-gradient(var(--line)_1px,transparent_1px)] [background-size:18px_18px]" />
          <span className="relative text-[clamp(4rem,12vw,8rem)] font-semibold tracking-tighter text-accent">
            {initials(member.name)}
          </span>
        </div>
      )}
    </div>
  );
}

/** Small round avatar for lists. */
export function Avatar({ member, size = 40, className }: { member: TeamMember; size?: number; className?: string }) {
  const src = member.avatar || member.photo;
  return (
    <span
      className={cn(
        "relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full bg-accent-soft",
        className,
      )}
      style={{ width: size, height: size }}
    >
      {src ? (
        <Image
          src={src}
          alt=""
          fill
          sizes={`${size}px`}
          className={cn("object-cover", !member.avatar && "object-[50%_20%]")}
        />
      ) : (
        <span aria-hidden="true" className="font-semibold text-accent" style={{ fontSize: size * 0.36 }}>
          {initials(member.name)}
        </span>
      )}
    </span>
  );
}
