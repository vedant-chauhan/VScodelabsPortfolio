import { cn } from "@/lib/utils";
import { SplitWords } from "./split-words";
import { delay } from "@/lib/motion";
import { Reveal } from "@/components/motion/reveal";

export function Eyebrow({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <p className={cn("font-mono text-xs font-medium uppercase tracking-[0.18em] text-accent", className)}>{children}</p>
  );
}

/**
 * Section title. Two-tone when `titleMuted` is set: a short bold lead ("Work.")
 * followed by a muted continuation ("Products we've shipped…"). Words rise in on scroll.
 */
export function SectionHeading({
  eyebrow,
  title,
  titleMuted,
  description,
  className,
  action,
}: {
  eyebrow?: string;
  title: string;
  titleMuted?: string;
  description?: string;
  className?: string;
  action?: React.ReactNode;
}) {
  return (
    <Reveal
      variant="fade"
      className={cn("mb-12 flex flex-col gap-6 sm:mb-16 md:flex-row md:items-end md:justify-between", className)}
    >
      <div className="max-w-2xl">
        {eyebrow && <Eyebrow className="mb-4">{eyebrow}</Eyebrow>}
        <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
          <SplitWords text={title} />
          {titleMuted && (
            <>
              {" "}
              <span className="text-ink/50">
                <SplitWords text={titleMuted} offset={title.split(" ").length} />
              </span>
            </>
          )}
        </h2>
        {description && <p className="mt-4 text-lg text-pretty text-muted">{description}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </Reveal>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  children?: React.ReactNode;
}) {
  return (
    <header className="border-b border-line">
      <div className="mx-auto w-full max-w-6xl px-4 pt-16 pb-14 sm:px-6 sm:pt-24 sm:pb-20 lg:px-8">
        <Eyebrow className="mb-5 motion-safe:animate-rise">{eyebrow}</Eyebrow>
        <h1 className="words-on-load max-w-3xl text-4xl font-semibold tracking-tight text-balance sm:text-5xl lg:text-6xl">
          <SplitWords text={title} />
        </h1>
        {description && (
          <p
            className="mt-6 max-w-2xl text-lg text-pretty text-muted motion-safe:animate-rise sm:text-xl"
            style={delay(160)}
          >
            {description}
          </p>
        )}
        {children && (
          <div className="motion-safe:animate-rise" style={delay(240)}>
            {children}
          </div>
        )}
      </div>
    </header>
  );
}
