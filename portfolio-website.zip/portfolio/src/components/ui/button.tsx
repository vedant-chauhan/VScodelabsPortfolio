import Link from "next/link";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "inverse";

/** `magnetic` (globals.css): leans toward the cursor and presses in on click; it also sets the transitions. */
const base =
  "magnetic group/btn inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium disabled:pointer-events-none disabled:opacity-60";

const variants: Record<Variant, string> = {
  primary: "bg-ink text-canvas hover:bg-accent hover:text-accent-ink",
  secondary: "border border-line bg-surface text-ink hover:border-ink",
  ghost: "text-ink hover:text-accent",
  /** For use on dark (bg-ink) panels. */
  inverse: "bg-canvas text-ink hover:bg-accent hover:text-accent-ink",
};

export function buttonClasses(variant: Variant = "primary", className?: string) {
  return cn(base, variants[variant], className);
}

export function ButtonLink({
  href,
  variant = "primary",
  className,
  external,
  children,
}: {
  href: string;
  variant?: Variant;
  className?: string;
  external?: boolean;
  children: React.ReactNode;
}) {
  if (external) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={buttonClasses(variant, className)}>
        {children}
      </a>
    );
  }
  return (
    <Link href={href} className={buttonClasses(variant, className)}>
      {children}
    </Link>
  );
}
