import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import type { CareerEntry, CareerPhoto } from "@/types/content";
import { getProject } from "@/data/projects";
import { careerKinds, formatPeriod, isPoint, sortNewestFirst } from "@/lib/career";
import { Reveal } from "@/components/motion/reveal";
import { cn } from "@/lib/utils";
import { KindSwatch, SampleBadge } from "./career-chart";

/**
 * The detailed career story: newest first, cards alternating left and right of a
 * centre line on wide screens (single column on phones), each sliding in from its side.
 * An entry's photos fill the empty half of its row on wide screens, or sit under the card on phones.
 */
export function CareerTimeline({ entries }: { entries: CareerEntry[] }) {
  const items = sortNewestFirst(entries);
  if (items.length === 0) return null;

  return (
    <ol className="relative">
      <span aria-hidden="true" className="absolute top-2 bottom-2 left-[7px] w-px bg-line md:left-1/2" />
      {items.map((entry, i) => {
        const meta = careerKinds[entry.kind];
        const left = i % 2 === 0;
        const projects = (entry.projects ?? []).flatMap((slug) => getProject(slug) ?? []);
        const ongoing = !isPoint(entry) && !entry.end;
        return (
          <Reveal
            as="li"
            key={entry.kind + entry.title + entry.start}
            variant={left ? "left" : "right"}
            className="relative grid pb-10 pl-9 last:pb-0 md:grid-cols-2 md:gap-14 md:pl-0"
          >
            {/* Dot on the line */}
            <span
              aria-hidden="true"
              data-pop=""
              className="absolute top-2 left-0 grid size-[15px] place-items-center rounded-full ring-4 ring-canvas md:left-1/2 md:-translate-x-1/2"
              style={{ background: meta.color }}
            >
              {ongoing && (
                <span
                  className="absolute inset-0 rounded-full opacity-60 motion-safe:animate-ping"
                  style={{ background: meta.color }}
                />
              )}
            </span>

            <div className={cn("md:row-start-1", left ? "md:col-start-1 md:text-right" : "md:col-start-2")}>
              <div
                className={cn(
                  "spotlight rounded-2xl border border-line bg-surface p-5 transition-[border-color,translate] hover:-translate-y-0.5 hover:border-ink/30 sm:p-6",
                  left ? "md:ml-auto" : "",
                  "max-w-md",
                )}
              >
                <p className={cn("flex flex-wrap items-center gap-2 text-xs text-muted", left && "md:justify-end")}>
                  <KindSwatch kind={entry.kind} />
                  <span className="font-medium text-ink">{meta.label}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{formatPeriod(entry)}</span>
                  {entry.sample && <SampleBadge />}
                </p>
                <h3 className="mt-2 text-lg font-semibold tracking-tight">{entry.title}</h3>
                {entry.organization && <p className="text-sm text-muted">{entry.organization}</p>}
                {entry.description && (
                  <p className="mt-2 text-sm leading-relaxed text-pretty text-muted">{entry.description}</p>
                )}
                {projects.length > 0 && (
                  <div className="mt-4">
                    <p className="font-mono text-[10px] tracking-[0.14em] text-muted uppercase">
                      {projects.length === 1 ? "Project" : "Projects"}
                    </p>
                    <ul className={cn("mt-2 flex flex-wrap gap-2", left && "md:justify-end")}>
                      {projects.map((project) => (
                        <li key={project.slug}>
                          <Link
                            href={`/projects/${project.slug}`}
                            className="inline-flex items-center gap-1 rounded-full border border-line bg-surface-2 px-3 py-1 text-xs font-medium transition-colors hover:border-accent hover:text-accent"
                          >
                            {project.name} <ArrowRight className="size-3" aria-hidden="true" />
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {entry.href && (
                  <p className="mt-3 text-sm font-medium">
                    <a
                      href={entry.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 hover:text-accent"
                    >
                      Verify <ArrowUpRight className="size-3.5" aria-hidden="true" />
                    </a>
                  </p>
                )}
              </div>
            </div>

            {entry.photos && entry.photos.length > 0 && (
              <Polaroids
                photos={entry.photos}
                className={cn(
                  "mt-8 md:row-start-1 md:mt-2",
                  left ? "md:col-start-2 md:justify-start" : "md:col-start-1 md:justify-end",
                )}
              />
            )}
          </Reveal>
        );
      })}
    </ol>
  );
}

const TILTS = ["-rotate-[4deg]", "rotate-[3deg]", "-rotate-[2deg]"];

/** Up to three photos as overlapping, slightly tilted polaroids that straighten on hover. */
function Polaroids({ photos, className }: { photos: CareerPhoto[]; className?: string }) {
  return (
    <div className={cn("flex max-w-md items-start", className)}>
      {photos.slice(0, 3).map((photo, i) => {
        return (
          <figure
            key={photo.src}
            data-settle=""
            className={cn(
              "relative w-[52%] shrink-0 rounded-lg border border-line bg-surface p-2 shadow-lg shadow-black/10 transition-[rotate,translate,scale] duration-300 ease-out hover:z-20 motion-reduce:transition-none hover:-translate-y-1 hover:scale-[1.04] hover:rotate-0 sm:w-[48%] md:w-[46%]",
              // Polaroid-style deeper bottom edge when there's no caption to fill it.
              !photo.caption && "pb-6",
              TILTS[i % TILTS.length],
              i > 0 && "-ml-[8%] mt-10",
            )}
            style={{ "--settle-delay": `${i * 110}ms` } as React.CSSProperties}
          >
            <div className="relative aspect-[4/5] overflow-hidden rounded-md bg-surface-2">
              <Image
                src={photo.src}
                alt={photo.alt}
                fill
                sizes="(min-width: 768px) 210px, 45vw"
                className="object-cover"
              />
            </div>
            {photo.caption && (
              <figcaption className="px-1 pt-2 pb-0.5 text-center font-mono text-[11px] tracking-wide text-muted">
                {photo.caption}
              </figcaption>
            )}
          </figure>
        );
      })}
    </div>
  );
}
