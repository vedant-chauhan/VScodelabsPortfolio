import type { CareerEntry, TeamMember } from "@/types/content";
import { careerKinds, formatPeriod, isPoint, now, toYears } from "@/lib/career";
import { Reveal } from "@/components/motion/reveal";
import { Avatar } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

type Lane = { member: TeamMember; entries: CareerEntry[] };

/**
 * A career "at a glance" chart on a shared years axis: roles are bars that grow in,
 * single dates (graduations, milestones, certifications) are markers that pop in,
 * and a dashed line marks today.
 * Pass one lane for a single profile, or several to compare partners on one axis.
 * Every entry is also listed in <CareerTimeline>, which is the accessible version.
 */
export async function CareerChart({ lanes, showLaneHeaders = false }: { lanes: Lane[]; showLaneHeaders?: boolean }) {
  const all = lanes.flatMap((lane) => lane.entries);
  if (all.length === 0) return null;

  const { year: currentYear, fraction: today } = await now();
  const minYear = Math.floor(Math.min(...all.map((entry) => toYears(entry.start))));
  const maxYear = Math.max(currentYear, ...all.map((entry) => Math.floor(toYears(entry.end ?? entry.start)))) + 1;
  const span = maxYear - minYear;
  const pos = (years: number) => ((years - minYear) / span) * 100;
  const years = Array.from({ length: span }, (_, i) => minYear + i);
  const kindsUsed = (Object.keys(careerKinds) as (keyof typeof careerKinds)[]).filter((kind) =>
    all.some((entry) => entry.kind === kind),
  );
  const grid = {
    backgroundImage: "linear-gradient(to right, var(--line) 1px, transparent 1px)",
    backgroundSize: `${100 / span}% 100%`,
  };

  return (
    <figure>
      <figcaption className="mb-6 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted">
        {kindsUsed.map((kind) => (
          <span key={kind} className="inline-flex items-center gap-2">
            <KindSwatch kind={kind} />
            {careerKinds[kind].label}
          </span>
        ))}
      </figcaption>

      <div className="-mx-4 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0">
        <div
          role="img"
          aria-label={`Career chart from ${minYear} to today. Every entry is also listed in the timeline below.`}
          className="relative min-w-[640px] rounded-2xl border border-line bg-surface [--label:150px] md:min-w-[860px] md:[--label:270px]"
        >
          {/* Year axis */}
          <div className="grid border-b border-line" style={{ gridTemplateColumns: "var(--label) 1fr" }}>
            <div className="px-3 py-3 font-mono text-xs tracking-[0.14em] text-muted uppercase md:px-5">Role</div>
            <div className="relative h-11">
              {years.map((year) => (
                <span
                  key={year}
                  className="absolute top-1/2 -translate-y-1/2 pl-2 font-mono text-xs text-muted"
                  style={{ left: `${pos(year)}%` }}
                >
                  {year}
                </span>
              ))}
            </div>
          </div>

          {lanes.map((lane) => (
            <div key={lane.member.slug}>
              {showLaneHeaders && (
                <div className="flex items-center gap-3 border-b border-line bg-surface-2/60 px-5 py-3">
                  <Avatar member={lane.member} size={28} />
                  <span className="font-semibold tracking-tight">{lane.member.name}</span>
                  <span className="text-sm text-muted">{lane.member.role}</span>
                </div>
              )}
              {[...lane.entries]
                .sort((a, b) => toYears(a.start) - toYears(b.start))
                .map((entry, i) => {
                  const meta = careerKinds[entry.kind];
                  const point = isPoint(entry);
                  // A year-only single date ("2025") sits in the middle of its year, not on the gridline.
                  const yearOnly = point && !entry.start.includes("-");
                  const start = pos(toYears(entry.start) + (yearOnly ? 0.5 : 0));
                  const ongoing = !point && !entry.end;
                  const end = point ? start : pos(entry.end ? toYears(entry.end) : today);
                  return (
                    <Reveal
                      key={entry.kind + entry.title + entry.start}
                      variant="fade"
                      delay={i * 70}
                      className="group grid border-b border-line transition-colors last:border-b-0 hover:bg-surface-2/50"
                      style={{ gridTemplateColumns: "var(--label) 1fr" }}
                    >
                      <div className="min-w-0 px-3 py-3 md:px-5">
                        <p className="flex items-start gap-2 text-sm leading-snug font-medium">
                          <span className="mt-1">
                            <KindSwatch kind={entry.kind} />
                          </span>
                          <span>
                            {entry.title} {entry.sample && <SampleBadge />}
                          </span>
                        </p>
                        <p className="mt-0.5 pl-5 text-xs text-muted">
                          {[entry.organization, formatPeriod(entry)].filter(Boolean).join(" · ")}
                        </p>
                      </div>
                      <div className="relative" style={grid}>
                        {point ? (
                          <span
                            data-pop=""
                            className={cn(
                              "absolute top-1/2 size-3.5 -translate-x-1/2 -translate-y-1/2 shadow-sm transition-[scale] group-hover:scale-125",
                              entry.kind === "milestone" && "rotate-45 rounded-[3px]",
                              entry.kind === "certification" && "rounded-full border-[3px] bg-surface",
                              entry.kind !== "milestone" &&
                                entry.kind !== "certification" &&
                                "rounded-full ring-4 ring-surface",
                            )}
                            style={{
                              left: `${start}%`,
                              ...(entry.kind === "certification"
                                ? { borderColor: meta.color }
                                : { background: meta.color }),
                            }}
                          />
                        ) : (
                          <span
                            data-draw=""
                            className="absolute top-1/2 h-3 -translate-y-1/2 rounded-full transition-[height] group-hover:h-4"
                            style={{
                              left: `${start}%`,
                              width: `${Math.max(end - start, 0.8)}%`,
                              background: ongoing
                                ? `linear-gradient(to right, ${meta.color} 75%, color-mix(in srgb, ${meta.color} 35%, transparent))`
                                : meta.color,
                            }}
                          />
                        )}
                      </div>
                    </Reveal>
                  );
                })}
            </div>
          ))}

          {/* Today */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute top-0 bottom-0 border-l-2 border-dashed border-accent/70"
            style={{ left: `calc(var(--label) + (100% - var(--label)) * ${pos(today) / 100})` }}
          >
            <span
              className={cn(
                "absolute -top-px left-0 rounded-b-md bg-accent px-1.5 py-0.5 font-mono text-[10px] font-medium tracking-wider text-accent-ink uppercase",
                pos(today) > 92 ? "-translate-x-full" : "-translate-x-1/2",
              )}
            >
              Today
            </span>
          </div>
        </div>
      </div>
      <p className="mt-3 text-xs text-muted sm:hidden">Swipe sideways to see the full chart.</p>
    </figure>
  );
}

export function KindSwatch({ kind }: { kind: keyof typeof careerKinds }) {
  const meta = careerKinds[kind];
  return (
    <span
      aria-hidden="true"
      className={cn(
        "inline-block size-3 shrink-0",
        kind === "milestone" && "rotate-45 rounded-[2px]",
        kind === "certification" && "rounded-full border-[2.5px]",
        !meta.point && "rounded-full",
      )}
      style={kind === "certification" ? { borderColor: meta.color } : { background: meta.color }}
    />
  );
}

export function SampleBadge() {
  return (
    <span className="shrink-0 rounded-full border border-dashed border-accent/60 px-1.5 py-px font-mono text-[10px] font-normal tracking-wide text-accent uppercase">
      Sample
    </span>
  );
}
