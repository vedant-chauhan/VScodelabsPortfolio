"use client";

import { useId } from "react";
import { cn } from "@/lib/utils";

type Theme = "light" | "dark";

function currentTheme(): Theme {
  const set = document.documentElement.getAttribute("data-theme");
  if (set === "light" || set === "dark") return set;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

/**
 * Light/dark switch. The sun morphs into a moon, and the new theme spreads out
 * in a circle from the button (View Transitions API). Browsers without it, and
 * visitors who prefer reduced motion, get an instant switch.
 * The choice is saved in localStorage and applied before paint by the boot script.
 */
export function ThemeToggle({ className, withLabel }: { className?: string; withLabel?: boolean }) {
  const maskId = useId();

  const toggle = (event: React.MouseEvent<HTMLButtonElement>) => {
    const root = document.documentElement;
    const next: Theme = currentTheme() === "dark" ? "light" : "dark";

    const apply = () => {
      root.setAttribute("data-theme", next);
      try {
        localStorage.setItem("theme", next);
      } catch {
        // Private browsing: the choice just isn't remembered.
      }
    };

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!document.startViewTransition || reduceMotion) {
      apply();
      return;
    }

    // Start the circle from the click (or the button's centre for keyboard presses).
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX || rect.left + rect.width / 2;
    const y = event.clientY || rect.top + rect.height / 2;
    root.style.setProperty("--theme-x", `${x}px`);
    root.style.setProperty("--theme-y", `${y}px`);
    root.setAttribute("data-theme-switching", "");

    const transition = document.startViewTransition(apply);
    transition.finished.finally(() => root.removeAttribute("data-theme-switching"));
  };

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label="Switch between light and dark mode"
      title="Switch theme"
      className={cn(
        "theme-toggle group inline-flex items-center gap-3 rounded-full text-ink transition-colors hover:text-accent",
        withLabel ? "py-2" : "grid size-10 place-items-center hover:bg-surface-2",
        className,
      )}
    >
      <svg viewBox="0 0 24 24" className="size-[22px] shrink-0" aria-hidden="true">
        <mask id={maskId}>
          <rect width="24" height="24" fill="white" />
          <circle className="theme-toggle__cut" cx="30" cy="4" r="7" fill="black" />
        </mask>
        <circle className="theme-toggle__core" cx="12" cy="12" r="5" fill="currentColor" mask={`url(#${maskId})`} />
        <g className="theme-toggle__rays" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <line x1="12" y1="1.5" x2="12" y2="3.5" />
          <line x1="12" y1="20.5" x2="12" y2="22.5" />
          <line x1="1.5" y1="12" x2="3.5" y2="12" />
          <line x1="20.5" y1="12" x2="22.5" y2="12" />
          <line x1="4.6" y1="4.6" x2="6" y2="6" />
          <line x1="18" y1="18" x2="19.4" y2="19.4" />
          <line x1="4.6" y1="19.4" x2="6" y2="18" />
          <line x1="18" y1="6" x2="19.4" y2="4.6" />
        </g>
      </svg>
      {withLabel && (
        <span className="text-lg">
          <span className="theme-toggle__label-light">Switch to dark mode</span>
          <span className="theme-toggle__label-dark">Switch to light mode</span>
        </span>
      )}
    </button>
  );
}
