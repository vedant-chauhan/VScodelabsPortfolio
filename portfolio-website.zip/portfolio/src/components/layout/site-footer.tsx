import Link from "next/link";
import { navigation, site } from "@/data/site";
import { services } from "@/data/services";
import { Container } from "@/components/ui/container";
import { telHref, withHref } from "@/lib/utils";
import { Logo } from "./logo";
import { Reveal } from "@/components/motion/reveal";

export function SiteFooter() {
  const socials = withHref(site.socials);

  return (
    <footer className="border-t border-line bg-surface">
      <Container className="grid gap-12 py-16 sm:grid-cols-2 lg:grid-cols-4">
        <div className="sm:col-span-2 lg:col-span-1">
          <Logo />
          <p className="mt-4 max-w-xs text-sm text-muted">{site.description}</p>
        </div>

        <FooterColumn title="Services">
          {services.map((service) => (
            <li key={service.id}>
              <Link href={`/services#${service.id}`} className="link-fx hover:text-ink">
                {service.title}
              </Link>
            </li>
          ))}
        </FooterColumn>

        <FooterColumn title="Studio">
          {navigation.map((item) => (
            <li key={item.href}>
              <Link href={item.href} className="link-fx hover:text-ink">
                {item.label}
              </Link>
            </li>
          ))}
        </FooterColumn>

        <FooterColumn title="Contact">
          <li>
            <a href={`mailto:${site.email}`} className="link-fx hover:text-ink">
              {site.email}
            </a>
          </li>
          {site.phones.map((phone) => (
            <li key={phone}>
              <a href={telHref(phone)} className="link-fx hover:text-ink">
                {phone}
              </a>
            </li>
          ))}
          <li>{site.location}</li>
          {socials.map((link) => (
            <li key={link.label}>
              <a href={link.href} target="_blank" rel="noopener noreferrer" className="link-fx hover:text-ink">
                {link.label}
              </a>
            </li>
          ))}
        </FooterColumn>
      </Container>

      <Container className="flex flex-col gap-2 border-t border-line py-6 text-xs text-muted sm:flex-row sm:justify-between">
        <p>
          © <CopyrightYear /> {site.name}. All rights reserved.
        </p>
        <p>Designed, built and maintained in-house.</p>
      </Container>

      {/* Oversized wordmark that rises into view at the very bottom. */}
      <div aria-hidden="true" className="overflow-hidden">
        <Reveal
          variant="fade"
          // It's the last thing on the page, so on phones it never passes the default trigger line.
          margin="0px"
          className="-mb-[0.18em] text-center leading-none font-semibold tracking-tighter whitespace-nowrap select-none"
          // Sized from the name's length so it always spans the page without overflowing.
          style={{ fontSize: `${Math.min(18, 92 / (0.56 * site.name.length))}vw` }}
        >
          <span className="bg-linear-to-b from-ink/15 to-ink/0 bg-clip-text text-transparent">{site.name}</span>
        </Reveal>
      </div>
    </footer>
  );
}

/** Cached so the page can still be prerendered; refreshes with the default cache lifetime. */
async function CopyrightYear() {
  "use cache";
  return <>{new Date().getFullYear()}</>;
}

function FooterColumn({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="font-mono text-xs font-medium uppercase tracking-[0.18em] text-ink">{title}</h2>
      <ul className="mt-4 space-y-2.5 text-sm text-muted">{children}</ul>
    </div>
  );
}
