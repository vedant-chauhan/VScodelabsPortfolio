"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { navigation } from "@/data/site";
import { buttonClasses } from "@/components/ui/button";
import { HireButton } from "@/components/contact/hire-button";
import { ThemeToggle } from "./theme-toggle";
import { cn } from "@/lib/utils";

function isActive(pathname: string | null, href: string) {
  return pathname === href || Boolean(pathname?.startsWith(`${href}/`));
}

function Nav({ pathname }: { pathname: string | null }) {
  const [open, setOpen] = useState(false);
  const links = navigation.filter((item) => item.href !== "/contact");

  return (
    <>
      <nav aria-label="Main" className="hidden items-center gap-8 md:flex">
        {links.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            aria-current={isActive(pathname, item.href) ? "page" : undefined}
            className={cn(
              "link-fx text-sm hover:text-ink",
              isActive(pathname, item.href) ? "font-medium text-ink" : "text-muted",
            )}
          >
            {item.label}
          </Link>
        ))}
        <span className="-mx-3 flex items-center">
          <ThemeToggle />
        </span>
        <HireButton className="py-2" />
      </nav>

      <div className="flex items-center gap-1 md:hidden">
        <HireButton icon={false} className="px-4 py-1.5 text-[13px]" />
        <button
          type="button"
          className="-mr-2 grid size-10 place-items-center rounded-full"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {open && (
        <nav
          id="mobile-nav"
          aria-label="Mobile"
          className="absolute inset-x-0 top-16 border-b border-line bg-canvas px-4 pt-2 pb-6 shadow-lg motion-safe:animate-menu md:hidden"
        >
          <ul className="flex flex-col">
            {navigation.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  onClick={() => setOpen(false)}
                  aria-current={isActive(pathname, item.href) ? "page" : undefined}
                  className={cn(
                    "block border-b border-line py-4 text-lg",
                    isActive(pathname, item.href) ? "font-medium text-ink" : "text-muted",
                  )}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <ThemeToggle withLabel className="mt-3 w-full text-muted" />
          <Link href="/hire" onClick={() => setOpen(false)} className={buttonClasses("primary", "mt-4 w-full")}>
            Hire us
          </Link>
        </nav>
      )}
    </>
  );
}

export function MainNav() {
  return <Nav pathname={usePathname()} />;
}

/** Same links without an active state; used as the Suspense fallback. */
export function MainNavFallback() {
  return <Nav pathname={null} />;
}
