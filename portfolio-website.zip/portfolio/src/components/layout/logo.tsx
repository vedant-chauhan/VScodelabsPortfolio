import Link from "next/link";
import { site } from "@/data/site";

/** Text logo. Swap the monogram <span> for an <Image> once you have a logo file. */
export function Logo() {
  return (
    <Link href="/" className="group flex items-center gap-2.5" aria-label={`${site.name}, home`}>
      <span className="grid size-8 place-items-center rounded-lg bg-ink font-mono text-[11px] font-semibold tracking-tight text-canvas transition-colors group-hover:bg-accent group-hover:text-accent-ink">
        {site.monogram}
      </span>
      <span className="text-[15px] font-semibold tracking-tight">{site.name}</span>
    </Link>
  );
}
