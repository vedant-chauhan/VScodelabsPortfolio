import { Suspense } from "react";
import { Container } from "@/components/ui/container";
import { Logo } from "./logo";
import { MainNav, MainNavFallback } from "./main-nav";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-canvas/80 backdrop-blur-md">
      <Container className="flex h-16 items-center justify-between gap-6">
        <Logo />
        {/* MainNav reads the current path; the fallback renders the same links without the active state. */}
        <Suspense fallback={<MainNavFallback />}>
          <MainNav />
        </Suspense>
      </Container>
    </header>
  );
}
