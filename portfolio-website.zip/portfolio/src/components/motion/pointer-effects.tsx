"use client";

import { useEffect, useRef } from "react";

/** Clicks on these get the stronger, full-accent ripple. */
const INTERACTIVE = "a, button, [role='button'], input, select, textarea, label, summary";
const MAX_RIPPLES = 6;
/** Matches the longest ripple animation in globals.css, plus a little slack. */
const RIPPLE_MS = 1100;
/** How far a magnetic element follows the cursor: a share of the distance, capped in px. */
const PULL = { x: 0.22, y: 0.3, maxX: 6, maxY: 4 };

/**
 * Mouse and pen effects, never on touch and never with reduced motion:
 *
 * - **Click ripple:** every click sends a thin accent ring, a fainter echo and a soft bloom out from the
 *   pointer. Clicks on links and buttons get the full accent; elsewhere it's softer. The ripples live in a
 *   fixed layer with its own view-transition name, so they keep playing across page and theme transitions.
 * - **Magnetic buttons:** elements with the `magnetic` class (every button) lean a few pixels toward the
 *   cursor while it's over them, and settle back when it leaves. The motion itself is CSS (globals.css).
 */
export function PointerEffects() {
  const layerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const layer = layerRef.current;
    if (!layer) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    const motionOn = () => document.documentElement.getAttribute("data-motion") === "on" && !reduce.matches;

    const onDown = (event: PointerEvent) => {
      if (event.pointerType === "touch" || event.button !== 0 || !motionOn()) return;
      const target = event.target as Element | null;
      const ripple = document.createElement("span");
      ripple.className = "click-ripple";
      if (target?.closest?.(INTERACTIVE)) ripple.dataset.strong = "";
      ripple.style.left = `${event.clientX}px`;
      ripple.style.top = `${event.clientY}px`;
      // Bloom, ring, echo.
      ripple.append(document.createElement("i"), document.createElement("i"), document.createElement("i"));
      layer.append(ripple);
      while (layer.childElementCount > MAX_RIPPLES) layer.firstElementChild?.remove();
      window.setTimeout(() => ripple.remove(), RIPPLE_MS);
    };

    let current: HTMLElement | null = null;
    let frame = 0;
    const release = () => {
      current?.style.removeProperty("--mag-x");
      current?.style.removeProperty("--mag-y");
      current = null;
    };
    const onMove = (event: PointerEvent) => {
      if (event.pointerType === "touch") return;
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const el = (event.target as Element | null)?.closest?.<HTMLElement>(".magnetic") ?? null;
        if (el !== current) release();
        if (!el || !motionOn()) return;
        current = el;
        const rect = el.getBoundingClientRect();
        const dx = event.clientX - (rect.left + rect.width / 2);
        const dy = event.clientY - (rect.top + rect.height / 2);
        const clamp = (value: number, max: number) => Math.max(-max, Math.min(max, value));
        el.style.setProperty("--mag-x", `${clamp(dx * PULL.x, PULL.maxX).toFixed(2)}px`);
        el.style.setProperty("--mag-y", `${clamp(dy * PULL.y, PULL.maxY).toFixed(2)}px`);
      });
    };
    const onLeave = () => {
      cancelAnimationFrame(frame);
      release();
    };

    document.addEventListener("pointerdown", onDown, { passive: true });
    document.addEventListener("pointermove", onMove, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);
    window.addEventListener("scroll", onLeave, { passive: true });
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("pointermove", onMove);
      document.documentElement.removeEventListener("pointerleave", onLeave);
      window.removeEventListener("scroll", onLeave);
      cancelAnimationFrame(frame);
      release();
    };
  }, []);

  return <div ref={layerRef} aria-hidden="true" className="click-layer" />;
}
