"use client";

import { useEffect, useRef } from "react";

/**
 * A number that counts up from zero when it scrolls into view.
 * The server renders the final value, so it's correct without JavaScript
 * and for visitors who prefer reduced motion.
 */
export function CountUp({ value, duration = 1600 }: { value: number; duration?: number }) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || document.documentElement.getAttribute("data-motion") !== "on") return;

    el.textContent = "0";
    let frame = 0;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) return;
        io.disconnect();
        const start = performance.now();
        const tick = (now: number) => {
          const progress = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - progress, 3);
          el.textContent = Math.round(value * eased).toLocaleString("en-IN");
          if (progress < 1) frame = requestAnimationFrame(tick);
        };
        frame = requestAnimationFrame(tick);
      },
      { threshold: 0.6 },
    );
    io.observe(el);

    return () => {
      io.disconnect();
      cancelAnimationFrame(frame);
    };
  }, [value, duration]);

  return (
    <>
      <span ref={ref} aria-hidden="true">
        {value.toLocaleString("en-IN")}
      </span>
      <span className="sr-only">{value.toLocaleString("en-IN")}</span>
    </>
  );
}
