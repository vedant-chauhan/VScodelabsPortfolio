"use client";

import { useEffect } from "react";
import Lenis from "lenis";
import "lenis/dist/lenis.css";
import { gsap, ScrollTrigger } from "@/lib/gsap";

/**
 * Smooth, inertial wheel scrolling (Lenis), kept in sync with GSAP ScrollTrigger.
 * - Off for visitors who prefer reduced motion.
 * - Touch devices keep native scrolling (Lenis only smooths the mouse wheel/trackpad by default).
 * - Same-page anchor links (#brief, #team, the skip link) glide to their target, below the sticky header
 *   (via `scroll-padding-top` on <html>).
 * Add `data-lenis-prevent` to any element that should keep native wheel scrolling.
 */
export function SmoothScroll() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const lenis = new Lenis({
      duration: 1.1,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      anchors: true, // uses the page's scroll-padding-top, like native anchor jumps
    });

    lenis.on("scroll", ScrollTrigger.update);
    const tick = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(tick);
      lenis.destroy();
    };
  }, []);

  return null;
}
