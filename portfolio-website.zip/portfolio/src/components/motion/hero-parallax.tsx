"use client";

import { useRef } from "react";
import { gsap, MOTION_OK, useGSAP } from "@/lib/gsap";

/**
 * Mouse parallax for the hero: every descendant with `data-depth` drifts toward the
 * cursor by an amount proportional to its depth (negative values move the other way),
 * with a slight tilt, eased by GSAP. Desktop only (fine pointer), off for reduced motion.
 */
export function HeroParallax({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  const root = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(`${MOTION_OK} and (hover: hover) and (pointer: fine)`, () => {
        const section = root.current?.closest("section") ?? window;
        const layers = gsap.utils.toArray<HTMLElement>(
          "[data-depth]",
          section instanceof Window ? root.current : section,
        );
        const movers = layers.map((el) => {
          const depth = parseFloat(el.dataset.depth ?? "0");
          return {
            depth,
            x: gsap.quickTo(el, "x", { duration: 1.1, ease: "power3.out" }),
            y: gsap.quickTo(el, "y", { duration: 1.1, ease: "power3.out" }),
            r: gsap.quickTo(el, "rotation", { duration: 1.4, ease: "power3.out" }),
          };
        });

        const onMove = (event: PointerEvent) => {
          // -1 … 1 from the centre of the viewport
          const nx = (event.clientX / window.innerWidth) * 2 - 1;
          const ny = (event.clientY / window.innerHeight) * 2 - 1;
          for (const m of movers) {
            m.x(nx * 22 * m.depth);
            m.y(ny * 16 * m.depth);
            m.r(nx * 2.5 * m.depth);
          }
        };
        const onLeave = () => movers.forEach((m) => (m.x(0), m.y(0), m.r(0)));

        window.addEventListener("pointermove", onMove, { passive: true });
        document.documentElement.addEventListener("pointerleave", onLeave);
        return () => {
          window.removeEventListener("pointermove", onMove);
          document.documentElement.removeEventListener("pointerleave", onLeave);
        };
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <div ref={root} {...props}>
      {children}
    </div>
  );
}
