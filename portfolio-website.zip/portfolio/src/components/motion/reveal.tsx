"use client";

import { useEffect, useRef, useState } from "react";

type Tag = "div" | "li" | "section" | "article" | "figure" | "details" | "h2" | "h3" | "p";
type Variant = "up" | "fade" | "scale" | "left" | "right";

/** Matches the transition duration in globals.css, plus a little slack. */
const TRANSITION_MS = 1000;

/** By default content reveals once it's past the bottom 10% of the screen, so it's clearly in view. */
const DEFAULT_MARGIN = "0px 0px -10% 0px";

// One IntersectionObserver per trigger margin, shared by every <Reveal> that uses it.
const observers = new Map<string, IntersectionObserver>();
const callbacks = new WeakMap<Element, () => void>();

function observe(el: Element, margin: string, onEnter: () => void) {
  let observer = observers.get(margin);
  if (!observer) {
    const created = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          created.unobserve(entry.target);
          callbacks.get(entry.target)?.();
          callbacks.delete(entry.target);
        }
      },
      { rootMargin: margin, threshold: 0.1 },
    );
    observers.set(margin, created);
    observer = created;
  }
  callbacks.set(el, onEnter);
  observer.observe(el);
  return () => {
    observer.unobserve(el);
    callbacks.delete(el);
  };
}

/**
 * Fades and slides its content in the first time it scrolls into view.
 *
 * - `variant`: "up" (default), "fade", "scale", "left" or "right" (slides in from that side)
 * - `delay`: milliseconds, for staggering items in a list
 * - `margin`: the observer's rootMargin. Use "0px" for content at the very end of the page,
 *   which can never scroll above the default trigger line on short screens
 * - children with `data-draw` (lines, bars) grow from the left; children with `data-pop` (markers) pop in
 *
 * Content is only hidden when the inline script in layout.tsx has confirmed
 * JavaScript is running and the visitor allows motion, so it's always visible
 * without JavaScript and with reduced motion. Because each instance updates
 * itself after it has hydrated, server and client HTML always match.
 */
export function Reveal({
  as = "div",
  variant = "up",
  delay = 0,
  margin = DEFAULT_MARGIN,
  style,
  children,
  ...props
}: { as?: Tag; variant?: Variant; delay?: number; margin?: string } & React.HTMLAttributes<HTMLElement>) {
  const ref = useRef<HTMLElement>(null);
  const entered = useRef(false);
  const [phase, setPhase] = useState<"waiting" | "visible" | "done">("waiting");

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute("data-reveal-ready", "");
    const el = ref.current;
    if (entered.current) {
      // Already revealed (e.g. the page was hidden mid-animation and is now shown again): finish up.
      const timer = window.setTimeout(() => setPhase("done"), 0);
      return () => window.clearTimeout(timer);
    }
    if (!el || root.getAttribute("data-motion") !== "on" || !("IntersectionObserver" in window)) return;

    let timer = 0;
    const stop = observe(el, margin, () => {
      entered.current = true;
      setPhase("visible");
      // Afterwards, drop the reveal styles so hover transitions aren't slowed by the stagger delay.
      timer = window.setTimeout(() => setPhase("done"), delay + TRANSITION_MS);
    });
    return () => {
      stop();
      window.clearTimeout(timer);
    };
  }, [delay, margin]);

  const Component = as as "div";
  return (
    <Component
      ref={ref as React.Ref<HTMLDivElement>}
      data-reveal={phase === "done" ? undefined : variant === "up" ? "" : variant}
      data-revealed={phase === "visible" ? "" : undefined}
      style={{ "--delay": `${delay}ms`, ...style } as React.CSSProperties}
      {...props}
    >
      {children}
    </Component>
  );
}
