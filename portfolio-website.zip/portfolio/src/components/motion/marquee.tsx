import { cn } from "@/lib/utils";

/** An endlessly scrolling row of words. Pauses on hover; static with reduced motion. */
export function Marquee({ items, className }: { items: string[]; className?: string }) {
  const row = (copy: boolean) => (
    <ul aria-hidden={copy || undefined} className="flex shrink-0 items-center">
      {items.map((item) => (
        <li key={item} className="flex items-center whitespace-nowrap">
          <span>{item}</span>
          <span aria-hidden="true" className="mx-8 text-accent sm:mx-10">
            ✦
          </span>
        </li>
      ))}
    </ul>
  );

  return (
    <div
      className={cn(
        "group flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]",
        className,
      )}
    >
      <div className="flex w-max motion-safe:animate-marquee group-hover:[animation-play-state:paused]">
        {row(false)}
        {row(true)}
      </div>
    </div>
  );
}
