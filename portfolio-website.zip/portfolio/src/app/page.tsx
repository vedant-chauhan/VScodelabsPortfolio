import { site } from "@/data/site";
import { services } from "@/data/services";
import { team } from "@/data/team";
import { Hero } from "@/components/sections/hero";
import { ServicesGrid } from "@/components/sections/services-grid";
import { FeaturedWork } from "@/components/sections/featured-work";
import { Process } from "@/components/sections/process";
import { TechStack } from "@/components/sections/tech-stack";
import { Team } from "@/components/sections/team";
import { WhyUs } from "@/components/sections/why-us";
import { Testimonials } from "@/components/sections/testimonials";
import { Cta } from "@/components/sections/cta";

export default function HomePage() {
  // Structured data so search engines understand who you are.
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: site.name,
    description: site.description,
    url: site.url,
    email: site.email,
    ...(site.phones.length > 0 && { telephone: site.phones }),
    areaServed: "Worldwide",
    knowsAbout: services.map((service) => service.title),
    founder: team.map((member) => ({
      "@type": "Person",
      name: member.name,
      jobTitle: member.role,
      url: `${site.url}/team/${member.slug}`,
    })),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
      />
      <Hero />
      <ServicesGrid />
      <FeaturedWork />
      <Testimonials />
      <WhyUs />
      <Team />
      <Process />
      <TechStack />
      <Cta />
    </>
  );
}
