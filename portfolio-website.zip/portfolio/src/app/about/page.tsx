import type { Metadata } from "next";
import { site } from "@/data/site";
import { values } from "@/data/company";
import { firstName, team } from "@/data/team";
import { Section } from "@/components/ui/container";
import { PageHeader, SectionHeading } from "@/components/ui/section-heading";
import { Team } from "@/components/sections/team";
import { WhyUs } from "@/components/sections/why-us";
import { Testimonials } from "@/components/sections/testimonials";
import { TechStack } from "@/components/sections/tech-stack";
import { Cta } from "@/components/sections/cta";
import { Reveal } from "@/components/motion/reveal";
import { CareerChart } from "@/components/career/career-chart";
import { DevNote } from "@/components/ui/dev-note";
import { visibleCareer } from "@/lib/career";

export const metadata: Metadata = {
  title: "About",
  description: `${site.name} is a two-partner software studio founded by ${team.map((m) => m.name).join(" and ")}.`,
};

export default function AboutPage() {
  const lanes = team
    .map((member) => ({ member, entries: visibleCareer(member.career) }))
    .filter((lane) => lane.entries.length > 0);

  return (
    <>
      {/* TODO: replace with your own story: how you met, when you started, what you care about. */}
      <PageHeader
        eyebrow="About"
        title={`We're ${team.map(firstName).join(" and ")}.`}
        description="Two partners who build software for businesses, from online stores and SaaS products to the systems that run a factory floor. We take projects from idea to launch, then stay on to keep them running."
      />

      <Team
        eyebrow="The founders"
        title="Meet us."
        titleMuted="Get to know the people you'll work with."
        description="Open a profile to see each partner's background, expertise and the projects they've worked on."
        className="border-t-0"
      />

      {lanes.length > 0 && (
        <Section id="journey" className="border-t border-line">
          <SectionHeading
            eyebrow="Our journey"
            title="Two careers."
            titleMuted="One studio."
            description="Where each of us has worked, the roles we've grown into, and when we graduated. Open a profile to see the projects behind each role."
          />
          {lanes.some((lane) => lane.entries.some((entry) => entry.sample)) && (
            <div className="mb-8">
              <DevNote>
                This chart shows sample entries. Add your real history to <code>career</code> in{" "}
                <code>src/data/team.ts</code>; samples never appear on the live site.
              </DevNote>
            </div>
          )}
          <CareerChart lanes={lanes} showLaneHeaders />
        </Section>
      )}

      <WhyUs />

      <Section className="border-t border-line">
        <SectionHeading eyebrow="How we think" title="Values." titleMuted="What you can expect from us." />
        <div className="grid gap-10 md:grid-cols-3">
          {values.map((value, i) => (
            <Reveal delay={i * 120} key={value.title} className="relative pt-6">
              <span aria-hidden="true" className="absolute inset-x-0 top-0 h-px bg-line" />
              <span aria-hidden="true" data-draw="" className="absolute inset-x-0 top-0 h-0.5 bg-accent" />
              <span className="font-mono text-xs text-muted">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-3 text-xl font-semibold tracking-tight">{value.title}</h3>
              <p className="mt-2 leading-relaxed text-pretty text-muted">{value.description}</p>
            </Reveal>
          ))}
        </div>
      </Section>

      <Testimonials />
      <TechStack />
      <Cta />
    </>
  );
}
