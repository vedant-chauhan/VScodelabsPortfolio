import { ButtonLink } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import { Eyebrow } from "@/components/ui/section-heading";

export default function NotFound() {
  return (
    <Container className="py-32 text-center">
      <Eyebrow>404</Eyebrow>
      <h1 className="mt-4 text-4xl font-semibold tracking-tight sm:text-5xl">This page doesn&apos;t exist.</h1>
      <p className="mx-auto mt-4 max-w-md text-lg text-muted">It may have moved, or the link might be wrong.</p>
      <div className="mt-8 flex justify-center gap-3">
        <ButtonLink href="/">Go home</ButtonLink>
        <ButtonLink href="/projects" variant="secondary">
          See our work
        </ButtonLink>
      </div>
    </Container>
  );
}
