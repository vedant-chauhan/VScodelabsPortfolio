import type { Metadata } from "next";
import { Suspense, ViewTransition } from "react";
import { PageSkeleton } from "@/components/ui/page-skeleton";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, ArrowUpRight, Briefcase, Languages, Mail, MapPin } from "lucide-react";
import { site } from "@/data/site";
import { firstName, getMember, team } from "@/data/team";
import { projectsByMember } from "@/data/projects";
import { Container } from "@/components/ui/container";
import { Eyebrow } from "@/components/ui/section-heading";
import { ButtonLink, buttonClasses } from "@/components/ui/button";
import { Avatar, Portrait } from "@/components/ui/avatar";
import { DevNote } from "@/components/ui/dev-note";
import { ProjectCard } from "@/components/projects/project-card";
import { HireButton } from "@/components/contact/hire-button";
import { Cta } from "@/components/sections/cta";
import { withHref } from "@/lib/utils";
import { delay } from "@/lib/motion";
import { Reveal } from "@/components/motion/reveal";
import { CareerChart } from "@/components/career/career-chart";
import { CareerTimeline } from "@/components/career/career-timeline";
import { visibleCareer } from "@/lib/career";

export function generateStaticParams() {
  return team.map((member) => ({ slug: member.slug }));
}

export async function generateMetadata({ params }: PageProps<"/team/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const member = getMember(slug);
  if (!member) return {};
  return {
    title: `${member.name} — ${member.role}`,
    description: `${member.headline} ${member.bio}`,
    openGraph: { type: "profile", ...(member.photo && { images: [member.photo] }) },
  };
}

export default function TeamMemberPage({ params }: PageProps<"/team/[slug]">) {
  // Reading params inside Suspense keeps client-side navigation instant (Cache Components).
  // The page is still fully prerendered at build time for every slug from generateStaticParams.
  return (
    <Suspense fallback={<PageSkeleton />}>
      <TeamMemberContent params={params} />
    </Suspense>
  );
}

async function TeamMemberContent({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const member = getMember(slug);
  if (!member) notFound();

  const name = firstName(member);
  const email = member.email || site.email;
  const links = withHref(member.links);
  const projects = projectsByMember(member.slug);
  const expertise = member.expertise.filter((group) => group.items.length > 0);
  const partners = team.filter((other) => other.slug !== member.slug);
  const career = visibleCareer(member.career);

  const facts = [
    member.location && { icon: MapPin, text: member.location },
    member.experienceYears && { icon: Briefcase, text: `${member.experienceYears}+ years experience` },
    member.languages.length > 0 && { icon: Languages, text: member.languages.join(", ") },
  ].filter(Boolean) as { icon: typeof MapPin; text: string }[];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: member.name,
    jobTitle: member.role,
    description: member.bio,
    url: `${site.url}/team/${member.slug}`,
    ...(member.photo && { image: `${site.url}${member.photo}` }),
    worksFor: { "@type": "Organization", name: site.name, url: site.url },
    knowsAbout: [...member.focus, ...expertise.flatMap((group) => group.items)],
    ...(links.length > 0 && { sameAs: links.map((link) => link.href) }),
  };

  return (
    <article>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
      />

      {/* Intro */}
      <header className="border-b border-line">
        <Container className="pt-10 pb-16 sm:pt-14 sm:pb-24">
          <Link href="/about#team" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink">
            <ArrowLeft className="size-4" aria-hidden="true" /> Meet the team
          </Link>

          <div className="mt-10 grid gap-10 md:grid-cols-[0.85fr_1.15fr] md:items-center lg:gap-16">
            <ViewTransition name={`portrait-${member.slug}`} share="morph" default="none">
              <Portrait
                member={member}
                priority
                aspect="aspect-[4/3] md:aspect-[4/5]"
                sizes="(min-width: 768px) 40vw, 100vw"
                className="shadow-xl shadow-black/5"
              />
            </ViewTransition>

            <div>
              <Eyebrow className="mb-4 motion-safe:animate-rise">{member.role}</Eyebrow>
              <h1
                className="text-4xl font-semibold tracking-tight text-balance motion-safe:animate-rise sm:text-6xl"
                style={delay(80)}
              >
                {member.name}
              </h1>
              <p
                className="mt-4 text-xl font-medium text-pretty motion-safe:animate-rise sm:text-2xl"
                style={delay(140)}
              >
                {member.headline}
              </p>

              {facts.length > 0 && (
                <ul className="mt-6 flex flex-wrap gap-2 motion-safe:animate-rise" style={delay(200)}>
                  {facts.map(({ icon: Icon, text }) => (
                    <li
                      key={text}
                      className="inline-flex items-center gap-1.5 rounded-full border border-line bg-surface px-3 py-1 text-sm"
                    >
                      <Icon className="size-3.5 text-muted" aria-hidden="true" /> {text}
                    </li>
                  ))}
                </ul>
              )}

              <p
                className="mt-6 max-w-xl text-lg leading-relaxed text-pretty text-muted motion-safe:animate-rise"
                style={delay(260)}
              >
                {member.bio}
              </p>

              <div className="mt-8 flex flex-wrap gap-3 motion-safe:animate-rise" style={delay(320)}>
                <HireButton partner={member.slug}>Hire me</HireButton>
                <a href={`mailto:${email}`} className={buttonClasses("secondary")}>
                  <Mail className="size-4" aria-hidden="true" /> Email {name}
                </a>
                {links.map((link) => (
                  <ButtonLink key={link.label} href={link.href} variant="secondary" external>
                    {link.label} <ArrowUpRight className="size-4" aria-hidden="true" />
                  </ButtonLink>
                ))}
              </div>

              {member.quote && (
                <blockquote
                  className="mt-10 border-l-2 border-accent pl-5 text-lg leading-relaxed text-pretty italic motion-safe:animate-rise"
                  style={delay(380)}
                >
                  “{member.quote}”
                </blockquote>
              )}
            </div>
          </div>
        </Container>
      </header>

      <Container className="divide-y divide-line">
        <ProfileSection title={`About ${name}`}>
          <div className="space-y-5 text-lg leading-relaxed text-pretty text-muted">
            {member.about.map((paragraph) => (
              <p key={paragraph.slice(0, 24)}>{paragraph}</p>
            ))}
          </div>
        </ProfileSection>

        <ProfileSection title="Expertise">
          <div className="space-y-6">
            <div>
              <h3 className="font-mono text-xs uppercase tracking-[0.14em] text-muted">Focus</h3>
              <Chips items={member.focus} />
            </div>
            {expertise.map((group) => (
              <div key={group.label}>
                <h3 className="font-mono text-xs uppercase tracking-[0.14em] text-muted">{group.label}</h3>
                <Chips items={group.items} />
              </div>
            ))}
            {member.expertise.some((group) => group.items.length === 0) && (
              <DevNote>
                Fill in the empty expertise groups (for example the technologies {name} uses most) in{" "}
                <code>src/data/team.ts</code>.
              </DevNote>
            )}
          </div>
        </ProfileSection>

        {career.length > 0 && (
          <section id="career" className="overflow-x-clip py-14 sm:py-20">
            <Reveal className="mb-10 max-w-2xl">
              <h2 className="text-2xl font-semibold tracking-tight">Career timeline</h2>
              <p className="mt-2 text-muted">
                {name}&apos;s path so far: each role, the projects delivered in it, and education.
              </p>
            </Reveal>
            {career.some((entry) => entry.sample) && (
              <div className="mb-8">
                <DevNote>
                  Entries marked <strong>Sample</strong> are placeholders and are hidden on the live site. Replace them
                  with {name}&apos;s real history in <code>career</code> in <code>src/data/team.ts</code> and remove{" "}
                  <code>sample: true</code>.
                </DevNote>
              </div>
            )}
            <Reveal variant="fade">
              <h3 className="mb-4 font-mono text-xs uppercase tracking-[0.14em] text-muted">At a glance</h3>
            </Reveal>
            <CareerChart lanes={[{ member, entries: career }]} />
            <Reveal variant="fade" className="mt-16 mb-8">
              <h3 className="font-mono text-xs uppercase tracking-[0.14em] text-muted">The story</h3>
            </Reveal>
            <CareerTimeline entries={career} />
          </section>
        )}

        {projects.length > 0 && (
          <ProfileSection title={`Projects ${name} worked on`} wide revealContent={false}>
            <div className="grid gap-x-8 gap-y-14 md:grid-cols-2">
              {projects.map((project, i) => (
                <Reveal delay={(i % 2) * 140} key={project.slug}>
                  <ProjectCard project={project} />
                </Reveal>
              ))}
            </div>
          </ProfileSection>
        )}

        {partners.map((partner) => (
          <Link
            key={partner.slug}
            href={`/team/${partner.slug}`}
            className="group flex items-center justify-between gap-6 py-10"
          >
            <span className="flex items-center gap-4">
              <Avatar member={partner} size={56} />
              <span>
                <span className="block font-mono text-xs uppercase tracking-[0.14em] text-muted">Also on the team</span>
                <span className="mt-1 block text-2xl font-semibold tracking-tight">{partner.name}</span>
              </span>
            </span>
            <ArrowRight className="size-6 transition-transform group-hover:translate-x-1" aria-hidden="true" />
          </Link>
        ))}
      </Container>

      <Cta title={`Work with ${team.map(firstName).join(" and ")}`} />
    </article>
  );
}

function ProfileSection({
  title,
  wide,
  revealContent = true,
  children,
}: {
  title: string;
  wide?: boolean;
  /** Set false when the content animates its own items. */
  revealContent?: boolean;
  children: React.ReactNode;
}) {
  return (
    <section className={wide ? "py-14 sm:py-20" : "grid gap-6 py-14 sm:py-20 md:grid-cols-[240px_1fr] md:gap-12"}>
      <Reveal
        as="h2"
        className={wide ? "mb-10 text-2xl font-semibold tracking-tight" : "text-2xl font-semibold tracking-tight"}
      >
        {title}
      </Reveal>
      {revealContent ? <Reveal delay={80}>{children}</Reveal> : <div>{children}</div>}
    </section>
  );
}

function Chips({ items }: { items: string[] }) {
  return (
    <ul className="mt-3 flex flex-wrap gap-2">
      {items.map((item) => (
        <li key={item} className="rounded-full border border-line bg-surface px-3 py-1 text-sm">
          {item}
        </li>
      ))}
    </ul>
  );
}
