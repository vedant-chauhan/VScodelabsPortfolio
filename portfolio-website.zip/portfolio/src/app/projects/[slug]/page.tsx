import type { Metadata } from "next";
import { Suspense, ViewTransition } from "react";
import { PageSkeleton } from "@/components/ui/page-skeleton";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, ArrowUpRight, Check, Lock } from "lucide-react";
import { getProject, projects } from "@/data/projects";
import { getService } from "@/data/services";
import { getMember } from "@/data/team";
import { testimonialsFor } from "@/data/testimonials";
import { Avatar } from "@/components/ui/avatar";
import { TestimonialAuthor } from "@/components/sections/testimonials";
import { delay } from "@/lib/motion";
import { ProjectCover } from "@/components/projects/project-cover";
import { ButtonLink } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import { Eyebrow } from "@/components/ui/section-heading";
import { Cta } from "@/components/sections/cta";
import { displayUrl } from "@/lib/utils";
import { Reveal } from "@/components/motion/reveal";

export function generateStaticParams() {
  return projects.map((project) => ({ slug: project.slug }));
}

export async function generateMetadata({ params }: PageProps<"/projects/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) return {};
  return {
    title: `${project.name} — ${project.category}`,
    description: project.summary,
  };
}

export default function ProjectPage({ params }: PageProps<"/projects/[slug]">) {
  // Reading params inside Suspense keeps client-side navigation instant (Cache Components).
  // The page is still fully prerendered at build time for every slug from generateStaticParams.
  return (
    <Suspense fallback={<PageSkeleton />}>
      <ProjectContent params={params} />
    </Suspense>
  );
}

async function ProjectContent({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) notFound();

  const index = projects.indexOf(project);
  const next = projects[(index + 1) % projects.length];

  const facts = [
    { label: "Client", value: project.client },
    { label: "Industry", value: project.industry },
    { label: "Our role", value: project.role },
    { label: "Year", value: project.year },
  ].filter((fact): fact is { label: string; value: string } => Boolean(fact.value));

  const services = project.services.map(getService).filter((service) => service !== undefined);
  const members = project.team.map(getMember).filter((member) => member !== undefined);
  const quotes = testimonialsFor(project.slug);

  return (
    <article>
      <header className="border-b border-line">
        <Container className="pt-10 pb-14 sm:pt-14 sm:pb-20">
          <Link href="/projects" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink">
            <ArrowLeft className="size-4" aria-hidden="true" /> All work
          </Link>
          <div className="mt-10 grid gap-10 lg:grid-cols-[1.3fr_1fr] lg:items-end">
            <div>
              <Eyebrow className="mb-5 motion-safe:animate-rise">{project.category}</Eyebrow>
              <h1
                className="text-4xl font-semibold tracking-tight text-balance motion-safe:animate-rise sm:text-6xl"
                style={delay(80)}
              >
                {project.name}
              </h1>
              <p
                className="mt-5 max-w-2xl text-lg text-pretty text-muted motion-safe:animate-rise sm:text-xl"
                style={delay(160)}
              >
                {project.summary}
              </p>
            </div>
            <div className="flex flex-wrap gap-3 motion-safe:animate-rise lg:justify-end" style={delay(240)}>
              {project.liveUrl && (
                <ButtonLink href={project.liveUrl} external>
                  Visit {displayUrl(project.liveUrl)} <ArrowUpRight className="size-4" aria-hidden="true" />
                </ButtonLink>
              )}
              {project.confidential && (
                <span className="inline-flex items-center gap-2 rounded-full border border-line px-4 py-2.5 text-sm text-muted">
                  <Lock className="size-4" aria-hidden="true" /> Private client system
                </span>
              )}
            </div>
          </div>
        </Container>
      </header>

      <Container className="py-12 sm:py-16">
        {/* Matches the name on the project card, so the card's cover morphs into this one. */}
        <ViewTransition name={`project-${project.slug}`} share="morph" default="none">
          <ProjectCover project={project} priority sizes="(min-width: 1152px) 1152px, 100vw" className="rounded-3xl" />
        </ViewTransition>
      </Container>

      <Container className="grid gap-14 pb-20 lg:grid-cols-[1fr_2fr] lg:gap-20">
        <aside className="lg:sticky lg:top-24 lg:self-start">
          {members.length > 0 && (
            <div className="mb-8">
              <h2 className="font-mono text-xs uppercase tracking-[0.14em] text-muted">Built by</h2>
              <ul className="mt-4 space-y-3">
                {members.map((member) => (
                  <li key={member.slug}>
                    <Link href={`/team/${member.slug}`} className="group flex items-center gap-3">
                      <Avatar member={member} size={44} />
                      <span>
                        <span className="block font-medium group-hover:text-accent">{member.name}</span>
                        <span className="block text-sm text-muted">{member.role}</span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <dl className="divide-y divide-line border-y border-line">
            {facts.map((fact) => (
              <div key={fact.label} className="grid grid-cols-[110px_1fr] gap-4 py-4 text-sm">
                <dt className="text-muted">{fact.label}</dt>
                <dd className="font-medium">{fact.value}</dd>
              </div>
            ))}
            {services.length > 0 && (
              <div className="grid grid-cols-[110px_1fr] gap-4 py-4 text-sm">
                <dt className="text-muted">Services</dt>
                <dd className="space-y-1 font-medium">
                  {services.map((service) => (
                    <Link
                      key={service.id}
                      href={`/services#${service.id}`}
                      className="link-fx block w-fit hover:text-accent"
                    >
                      {service.title}
                    </Link>
                  ))}
                </dd>
              </div>
            )}
          </dl>
          {project.stack.length > 0 && (
            <div className="mt-8">
              <h2 className="font-mono text-xs uppercase tracking-[0.14em] text-muted">Built with</h2>
              <ul className="mt-4 flex flex-wrap gap-2">
                {project.stack.map((tool) => (
                  <li key={tool} className="rounded-full border border-line bg-surface px-3 py-1 text-sm">
                    {tool}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>

        <div className="space-y-16">
          <CaseSection title="The challenge">
            <p>{project.challenge}</p>
          </CaseSection>

          <CaseSection title="What we built">
            <p>{project.solution}</p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {project.features.map((feature, i) => (
                <Reveal
                  delay={(i % 2) * 100}
                  key={feature.title}
                  className="spotlight rounded-2xl border border-line bg-surface p-6"
                >
                  <h3 className="font-semibold tracking-tight text-ink">{feature.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed">{feature.description}</p>
                </Reveal>
              ))}
            </div>
          </CaseSection>

          {quotes.map((quote) => (
            <Reveal as="figure" key={quote.name} className="rounded-2xl border border-line bg-surface p-7 sm:p-9">
              <blockquote className="text-xl leading-relaxed font-medium text-pretty sm:text-2xl">
                “{quote.quote}”
              </blockquote>
              <TestimonialAuthor item={quote} />
            </Reveal>
          ))}

          {project.results.length > 0 && (
            <CaseSection title="Outcome">
              <ul className="space-y-3">
                {project.results.map((result) => (
                  <li key={result} className="flex gap-3">
                    <Check className="mt-1 size-5 shrink-0 text-accent" aria-hidden="true" />
                    <span>{result}</span>
                  </li>
                ))}
              </ul>
            </CaseSection>
          )}
        </div>
      </Container>

      {next && next.slug !== project.slug && (
        <Container>
          <Link
            href={`/projects/${next.slug}`}
            className="group flex items-center justify-between gap-6 border-t border-line py-10"
          >
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.14em] text-muted">Next project</p>
              <p className="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">{next.name}</p>
            </div>
            <ArrowRight className="size-6 transition-transform group-hover:translate-x-1" aria-hidden="true" />
          </Link>
        </Container>
      )}

      <Cta title="Need something similar?" />
    </article>
  );
}

function CaseSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <Reveal as="h2" className="text-2xl font-semibold tracking-tight">
        {title}
      </Reveal>
      <div className="mt-4 text-lg leading-relaxed text-pretty text-muted">{children}</div>
    </section>
  );
}
