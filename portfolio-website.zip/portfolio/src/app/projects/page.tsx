import type { Metadata } from "next";
import { ArrowUpRight } from "lucide-react";
import { otherWork, projects } from "@/data/projects";
import { ProjectCard } from "@/components/projects/project-card";
import { Container, Section } from "@/components/ui/container";
import { PageHeader, SectionHeading } from "@/components/ui/section-heading";
import { Cta } from "@/components/sections/cta";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Work",
  description:
    "Case studies: Apparel 60 e-commerce, an appointment SaaS platform, Diamond Polymer factory management and the MV Bot chatbot.",
};

export default function ProjectsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Work"
        title="Real products, built for real businesses."
        description="A selection of the platforms we've designed, built and launched. Most are still maintained by us today."
      />

      <Container className="py-16 sm:py-24">
        <div className="grid gap-x-8 gap-y-16 md:grid-cols-2">
          {projects.map((project, i) => (
            <Reveal delay={(i % 2) * 140} key={project.slug}>
              <ProjectCard project={project} />
            </Reveal>
          ))}
        </div>
      </Container>

      <Section className="border-t border-line bg-surface">
        <SectionHeading
          eyebrow="And more"
          title="More work."
          titleMuted="Beyond the case studies."
          description="We've delivered and maintained a range of other live projects across different industries and tools, including several we can't show publicly. Ask us for examples close to what you're planning."
          className="mb-10 sm:mb-12"
        />
        {otherWork.length > 0 && (
          <ul className="divide-y divide-line border-y border-line">
            {otherWork.map((item, i) => (
              <Reveal
                as="li"
                variant="fade"
                delay={i * 60}
                key={item.name}
                className="grid gap-2 py-5 sm:grid-cols-[1fr_180px_2fr] sm:items-baseline sm:gap-6"
              >
                <span className="font-medium">
                  {item.href ? (
                    <a
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 hover:text-accent"
                    >
                      {item.name} <ArrowUpRight className="size-4" aria-hidden="true" />
                    </a>
                  ) : (
                    item.name
                  )}
                </span>
                <span className="font-mono text-xs uppercase tracking-[0.14em] text-muted">{item.category}</span>
                <span className="text-muted">{item.description}</span>
              </Reveal>
            ))}
          </ul>
        )}
      </Section>

      <Cta />
    </>
  );
}
