import { ImageResponse } from "next/og";
import { site } from "@/data/site";
import { services } from "@/data/services";

// The preview image shown when the site is shared on WhatsApp, LinkedIn, X, Slack, etc.
export const alt = `${site.name} — ${site.tagline}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          background: "#111318",
          color: "#f6f5f1",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 64,
              height: 64,
              borderRadius: 14,
              background: "#2f54eb",
              fontSize: 22,
              fontWeight: 700,
            }}
          >
            {site.monogram}
          </div>
          <div style={{ fontSize: 30, fontWeight: 600 }}>{site.name}</div>
        </div>
        <div style={{ display: "flex", fontSize: 76, fontWeight: 700, lineHeight: 1.05, letterSpacing: -2, maxWidth: 950 }}>
          We build the software your business runs on.
        </div>
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
          {services.slice(0, 4).map((service) => (
            <div
              key={service.id}
              style={{
                display: "flex",
                padding: "10px 20px",
                borderRadius: 999,
                border: "1px solid rgba(246,245,241,0.25)",
                fontSize: 22,
                color: "rgba(246,245,241,0.8)",
              }}
            >
              {service.title}
            </div>
          ))}
        </div>
      </div>
    ),
    size,
  );
}
