import type { MetadataRoute } from "next";
import { site } from "@/data/site";
import { projects } from "@/data/projects";
import { team } from "@/data/team";

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ["", "/services", "/projects", "/about", "/hire", "/contact"].map((path) => ({
    url: `${site.url}${path}`,
    changeFrequency: "monthly" as const,
    priority: path === "" ? 1 : 0.8,
  }));

  const caseStudies = projects.map((project) => ({
    url: `${site.url}/projects/${project.slug}`,
    changeFrequency: "yearly" as const,
    priority: 0.6,
  }));

  const profiles = team.map((member) => ({
    url: `${site.url}/team/${member.slug}`,
    changeFrequency: "yearly" as const,
    priority: 0.7,
  }));

  const hirePages = team.map((member) => ({
    url: `${site.url}/hire/${member.slug}`,
    changeFrequency: "monthly" as const,
    priority: 0.8,
  }));

  return [...pages, ...caseStudies, ...profiles, ...hirePages];
}
