import type { Metadata } from "next";
import { Suspense } from "react";
import { notFound } from "next/navigation";
import { getMember, team } from "@/data/team";
import { HirePage } from "@/components/hire/hire-page";
import { PageSkeleton } from "@/components/ui/page-skeleton";

export function generateStaticParams() {
  return team.map((member) => ({ slug: member.slug }));
}

export async function generateMetadata({ params }: PageProps<"/hire/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const member = getMember(slug);
  if (!member) return {};
  return {
    title: `Hire ${member.name}`,
    description: `Hire ${member.name}, ${member.role}. ${member.headline}`,
  };
}

export default function HirePartnerPage({ params }: PageProps<"/hire/[slug]">) {
  // Reading params inside Suspense keeps client-side navigation instant (Cache Components).
  // Every partner's page is still fully prerendered at build time.
  return (
    <Suspense fallback={<PageSkeleton />}>
      <HirePartnerContent params={params} />
    </Suspense>
  );
}

async function HirePartnerContent({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const member = getMember(slug);
  if (!member) notFound();
  return <HirePage member={member} />;
}
