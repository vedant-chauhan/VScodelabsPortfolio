import type { Metadata } from "next";
import { site } from "@/data/site";
import { team } from "@/data/team";
import { HirePage } from "@/components/hire/hire-page";

export const metadata: Metadata = {
  title: "Hire us",
  description: `Hire ${site.name} (${team.map((m) => m.name).join(" and ")}) to design, build and maintain your website, store, SaaS product or business software.`,
};

export default function HireStudioPage() {
  return <HirePage />;
}
