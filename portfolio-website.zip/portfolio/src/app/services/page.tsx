import type { Metadata } from "next";
import Link from "next/link";
import { Check } from "lucide-react";
import { services } from "@/data/services";
import { projects } from "@/data/projects";
import { Icon } from "@/components/ui/icon";
import { Container } from "@/components/ui/container";
import { PageHeader } from "@/components/ui/section-heading";
import { Process } from "@/components/sections/process";
import { Faq } from "@/components/sections/faq";
import { Cta } from "@/components/sections/cta";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Services",
  description:
    "E-commerce development, SaaS products, custom business software, AI chatbots, websites and long-term maintenance.",
};

export default function ServicesPage() {
  return (
    <>
      <PageHeader
        eyebrow="Services"
        title="Everything it takes to get your product live, and keep it running."
        description="Hire us for a complete build, a single piece of it, or ongoing support for software you already have."
      />

      <Container className="py-8 sm:py-12">
        {services.map((service) => {
          const examples = projects.filter((project) => project.services.includes(service.id));
          return (
            <section
              key={service.id}
              id={service.id}
              className="grid gap-8 border-b border-line py-12 last:border-b-0 md:grid-cols-[1fr_1fr] md:gap-16 sm:py-16"
            >
              <Reveal>
                <span className="grid size-12 place-items-center rounded-xl bg-accent-soft text-accent">
                  <Icon name={service.icon} className="size-6" />
                </span>
                <h2 className="mt-6 text-2xl font-semibold tracking-tight sm:text-3xl">{service.title}</h2>
                <p className="mt-4 text-lg leading-relaxed text-pretty text-muted">{service.summary}</p>
                {examples.length > 0 && (
                  <p className="mt-6 text-sm text-muted">
                    See it in:{" "}
                    {examples.map((project, i) => (
                      <span key={project.slug}>
                        {i > 0 && ", "}
                        <Link href={`/projects/${project.slug}`} className="link-fx font-medium text-ink">
                          {project.name}
                        </Link>
                      </span>
                    ))}
                  </p>
                )}
              </Reveal>
              <Reveal delay={120} className="rounded-2xl border border-line bg-surface p-6 sm:p-8">
                <h3 className="font-mono text-xs uppercase tracking-[0.14em] text-muted">What you get</h3>
                <ul className="mt-5 space-y-3.5">
                  {service.deliverables.map((item) => (
                    <li key={item} className="flex gap-3">
                      <Check className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Reveal>
            </section>
          );
        })}
      </Container>

      <Process />
      <Faq />
      <Cta />
    </>
  );
}
