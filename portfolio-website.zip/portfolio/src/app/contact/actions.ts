"use server";

import { site } from "@/data/site";
import { getMember } from "@/data/team";

export type ContactField = "name" | "email" | "phone" | "company" | "service" | "budget" | "partner" | "message";

export type ContactState = {
  status: "idle" | "success" | "error";
  message: string;
  errors?: Partial<Record<ContactField, string>>;
  /** Echoed back so the form keeps what the visitor typed when validation fails. */
  values?: Partial<Record<ContactField, string>>;
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const LIMITS: Record<ContactField, number> = {
  name: 100,
  email: 200,
  phone: 40,
  company: 150,
  service: 100,
  budget: 100,
  partner: 60,
  message: 5000,
};

/**
 * Sends a contact-form or "Hire" enquiry by email through Resend (https://resend.com).
 * Needs RESEND_API_KEY (see .env.example). Enquiries go to CONTACT_TO_EMAIL, or the site email when it's unset.
 * When the visitor picks a partner who has a direct `email` in team.ts, that partner is added as a recipient.
 */
export async function sendContactMessage(_previous: ContactState, formData: FormData): Promise<ContactState> {
  // Honeypot: real visitors never see or fill this field.
  if (String(formData.get("website") ?? "").trim() !== "") {
    return { status: "success", message: "Thanks, your message is on its way." };
  }

  const values = Object.fromEntries(
    (Object.keys(LIMITS) as ContactField[]).map((field) => [
      field,
      String(formData.get(field) ?? "")
        .trim()
        .slice(0, LIMITS[field]),
    ]),
  ) as Record<ContactField, string>;

  // Only accept partners that actually exist.
  const partner = values.partner ? getMember(values.partner) : undefined;
  values.partner = partner?.slug ?? "";

  const errors: ContactState["errors"] = {};
  if (values.name.length < 2) errors.name = "Please tell us your name.";
  if (!EMAIL_PATTERN.test(values.email)) errors.email = "Please enter a valid email address.";
  if (values.message.length < 20) errors.message = "Please add a little more detail (at least 20 characters).";

  if (Object.keys(errors).length > 0) {
    return { status: "error", message: "Please fix the highlighted fields.", errors, values };
  }

  const firstName = partner?.name.split(" ")[0];
  const thanks = partner
    ? `Thanks! ${firstName} has your message and will reply soon.`
    : "Thanks! We've got your message and will reply soon.";

  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.CONTACT_TO_EMAIL || site.email;
  const from = process.env.CONTACT_FROM_EMAIL ?? `${site.name} website <onboarding@resend.dev>`;

  if (!apiKey || !to) {
    if (process.env.NODE_ENV !== "production") {
      console.info("[contact] Email delivery is not configured, so the submission was only logged:", values);
      return { status: "success", message: `${thanks} (Development mode: logged to the server console.)` };
    }
    console.error("[contact] RESEND_API_KEY is missing, so the message could not be sent.");
    return {
      status: "error",
      message: `Sorry, the form isn't working right now. Please email us at ${site.email}.`,
      values,
    };
  }

  const details = [
    ["Name", values.name],
    ["Email", values.email],
    ["Phone", values.phone],
    ["Company", values.company],
    ["Wants to work with", partner?.name ?? ""],
    ["Interested in", values.service],
    ["Budget", values.budget],
  ]
    .filter(([, value]) => value !== "")
    .map(([label, value]) => `${label}: ${value}`);
  const text = [...details, "", values.message].join("\n");

  const recipients = new Set(to.split(",").map((address) => address.trim()));
  if (partner?.email) recipients.add(partner.email);

  const subject = partner
    ? `Hire request for ${firstName} from ${values.name}${values.company ? ` (${values.company})` : ""}`
    : `New enquiry from ${values.name}${values.company ? ` (${values.company})` : ""}`;

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from, to: [...recipients], reply_to: values.email, subject, text }),
    });

    if (!response.ok) {
      console.error("[contact] Resend responded with", response.status, await response.text());
      throw new Error("Email provider error");
    }
  } catch (error) {
    console.error("[contact] Failed to send enquiry:", error);
    return {
      status: "error",
      message: `Sorry, something went wrong sending your message. Please try again or email us at ${site.email}.`,
      values,
    };
  }

  return { status: "success", message: thanks };
}
