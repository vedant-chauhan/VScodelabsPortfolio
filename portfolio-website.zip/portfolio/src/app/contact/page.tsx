import type { Metadata } from "next";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { site } from "@/data/site";
import { Container } from "@/components/ui/container";
import { PageHeader } from "@/components/ui/section-heading";
import { ContactForm } from "@/components/contact/contact-form";
import { telHref, whatsappUrl, withHref } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Contact",
  description: `Tell us about your project. ${site.responseTime}`,
};

export default function ContactPage() {
  const details = [
    { icon: Mail, label: "Email", items: [{ value: site.email, href: `mailto:${site.email}` }] },
    site.phones.length > 0 && {
      icon: Phone,
      label: "Phone",
      items: site.phones.map((phone) => ({ value: phone, href: telHref(phone) })),
    },
    site.whatsapp && {
      icon: MessageCircle,
      label: "WhatsApp",
      items: [{ value: "Chat with us", href: whatsappUrl(site.whatsapp, site.whatsappMessage) }],
    },
    { icon: MapPin, label: "Location", items: [{ value: site.location }] },
  ].filter((detail) => Boolean(detail)) as {
    icon: typeof Mail;
    label: string;
    items: { value: string; href?: string }[];
  }[];
  const socials = withHref(site.socials);

  return (
    <>
      <PageHeader
        eyebrow="Contact"
        title="Let's talk about your project."
        description={`Share a few details and we'll come back with questions, ideas and next steps. ${site.responseTime}`}
      />

      <Container className="grid gap-12 py-16 sm:py-20 lg:grid-cols-[1fr_2fr] lg:gap-16">
        <aside className="space-y-8">
          <ul className="space-y-6">
            {details.map(({ icon: Icon, label, items }) => (
              <li key={label} className="flex gap-4">
                <span className="grid size-10 shrink-0 place-items-center rounded-full border border-line">
                  <Icon className="size-4" aria-hidden="true" />
                </span>
                <div>
                  <p className="text-sm text-muted">{label}</p>
                  {items.map(({ value, href }) =>
                    href ? (
                      <a
                        key={value}
                        href={href}
                        className="link-fx block w-fit font-medium hover:text-accent"
                        {...(href.startsWith("http") && { target: "_blank", rel: "noopener noreferrer" })}
                      >
                        {value}
                      </a>
                    ) : (
                      <p key={value} className="font-medium">
                        {value}
                      </p>
                    ),
                  )}
                </div>
              </li>
            ))}
          </ul>
          {socials.length > 0 && (
            <div className="flex flex-wrap gap-4 border-t border-line pt-6 text-sm font-medium">
              {socials.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="link-fx hover:text-accent"
                >
                  {link.label} ↗
                </a>
              ))}
            </div>
          )}
        </aside>

        <ContactForm />
      </Container>
    </>
  );
}
