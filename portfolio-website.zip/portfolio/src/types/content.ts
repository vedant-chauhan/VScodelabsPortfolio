/**
 * Shapes for everything the site displays.
 * All real content lives in `src/data/*` — edit those files, not the components.
 */

export type IconName =
  | "shopping-bag"
  | "layout-dashboard"
  | "factory"
  | "bot"
  | "globe"
  | "life-buoy"
  | "compass"
  | "pen-tool"
  | "code"
  | "rocket"
  | "wrench";

export type Service = {
  id: string;
  title: string;
  /** Short name for big display type, e.g. "E-commerce" (the home-page services wheel). */
  short: string;
  summary: string;
  icon: IconName;
  /** Concrete things a client gets. Shown as a checklist on /services. */
  deliverables: string[];
};

/** Illustration style used when a project has no screenshot yet. */
export type CoverVariant = "store" | "calendar" | "dashboard" | "chat";

export type Project = {
  slug: string;
  name: string;
  /** Short label shown on cards, e.g. "E-commerce". */
  category: string;
  /** One line under the name. */
  tagline: string;
  /** 1–2 sentences used on cards and in page metadata. */
  summary: string;
  industry: string;
  /** Public URL, if the product is live and can be shown. */
  liveUrl?: string;
  /** Set true for internal tools you can't link to or show in full. */
  confidential?: boolean;
  client?: string;
  year?: string;
  /** Your role on the project, e.g. "Design, development, hosting & maintenance". */
  role?: string;
  /** Service ids from `services.ts` this project demonstrates. */
  services: string[];
  /** Slugs of the partners (from `team.ts`) who worked on it. Shown on the case study and profile pages. */
  team: string[];
  /** Technologies used. Leave empty to hide the section. */
  stack: string[];
  challenge: string;
  solution: string;
  features: { title: string; description: string }[];
  /** Outcomes. Prefer measurable results ("Orders up 40%") once you have them. */
  results: string[];
  cover: {
    variant: CoverVariant;
    /** Gradient colours behind the illustration. */
    from: string;
    to: string;
    /** Real screenshot in /public, e.g. "/images/projects/apparel-60.jpg" (1600×1000). */
    image?: string;
    imageAlt?: string;
  };
  featured: boolean;
};

export type TeamMember = {
  /** URL of the profile page: /team/<slug> */
  slug: string;
  name: string;
  role: string;
  /** One line under the name, e.g. "Full-stack engineer focused on e-commerce and SaaS". */
  headline: string;
  /** 1–2 sentences for cards. */
  bio: string;
  /** Longer story for the profile page, one string per paragraph. First person reads warmest. */
  about: string[];
  /**
   * Portrait photo in /public, e.g. "/images/team/shantanu.jpg" (at least 1000×1250, 4:5).
   * Keep the face in the upper third: landscape crops (founder cards, the profile on phones) keep that area.
   */
  photo?: string;
  /** Square head-and-shoulders crop for the small round avatars (at least 256×256). Falls back to `photo`. */
  avatar?: string;
  location?: string;
  /** Shown as "N+ years experience" when set. */
  experienceYears?: number;
  focus: string[];
  /** Grouped skills. Groups with no items are hidden. */
  expertise: { label: string; items: string[] }[];
  /**
   * Career history, plotted as a chart and a detailed timeline on the profile page
   * and combined on the About page. Order doesn't matter; it's sorted by date.
   */
  career: CareerEntry[];
  languages: string[];
  /** A short personal line about how you work, in your own words. */
  quote?: string;
  /** Direct email. Falls back to the studio email when empty. */
  email?: string;
  links: { label: string; href: string }[];
};

export type CareerKind = "education" | "work" | "freelance" | "founder" | "milestone" | "certification";

export type CareerPhoto = {
  /** Path under /public, e.g. "/images/team/shantanu-2026-01.jpg". 4:5 portrait works best. */
  src: string;
  /** What the photo shows, for screen readers. */
  alt: string;
  /** Optional short caption, shown under the photo. */
  caption?: string;
};

export type CareerEntry = {
  kind: CareerKind;
  /** e.g. "Software Engineer", "B.E. Computer Engineering", "Launched Apparel 60". */
  title: string;
  /** Company, university or issuer. */
  organization?: string;
  /** "2021" or "2021-06". */
  start: string;
  /** Leave out for "Present". Not used for single dates (milestones, certifications, `point` entries). */
  end?: string;
  /** A single date rather than a span, e.g. a graduation year when the start year isn't listed. */
  point?: boolean;
  description?: string;
  /** Slugs of the projects worked on (or launched); each links to its case study. */
  projects?: string[];
  /** Photos from this period, shown as polaroids beside the entry in the timeline (not in the chart). */
  photos?: CareerPhoto[];
  /** External link, e.g. a certificate's verification page. */
  href?: string;
  /** Placeholder entry: shown (with a "Sample" badge) only in development, never on the live site. */
  sample?: boolean;
};

export type Testimonial = {
  quote: string;
  name: string;
  title?: string;
  company?: string;
  /** Project slug, so the quote also appears on that case study. */
  project?: string;
};

export type Stat = {
  /** Small illustration shown in the tile: "projects", "team", "services" or "reply". */
  visual?: "projects" | "team" | "services" | "reply";
  value: number;
  prefix?: string;
  suffix?: string;
  label: string;
};

export type ProcessStep = {
  title: string;
  description: string;
  icon: IconName;
};

export type TechGroup = {
  label: string;
  items: string[];
};

export type Faq = {
  question: string;
  answer: string;
};
