import type { TeamMember } from "@/types/content";
import { site } from "./site";

/**
 * The two partners. Each gets a card on the home and About pages and a full
 * profile at /team/<slug>.
 *
 * This is what clients use to decide whether to trust you, so replace every
 * TODO with real details. Empty fields and lists are hidden automatically.
 *
 * `career` drives the career chart and timeline on each profile and the
 * combined "Our journey" chart on the About page. Dates are "YYYY" or "YYYY-MM";
 * leave `end` out for a current role, and set `point: true` for a single date
 * (like a graduation year). `projects` lists case-study slugs, which show as links.
 * `photos` (in /public/images/team) appear as polaroids beside that entry in the timeline.
 * Kinds: education, work, freelance, founder, milestone, certification.
 * Portraits go in /public/images/team (4:5, at least 1000×1250).
 */
export const team: TeamMember[] = [
  {
    slug: "shantanu-kyada",
    name: "Shantanu Kyada",
    // TODO: your real title, e.g. "Co-founder · Engineering lead"
    role: "Co-founder",
    // TODO: one line on what you're known for.
    headline: "Full-stack engineer focused on architecture and delivery.",
    bio: "Works across the stack, from planning and architecture to shipping and maintaining production systems for clients.",
    // TODO: your own story, in your own words.
    about: [
      "I'm involved in our projects from the first call: understanding how the business works, shaping the scope, and planning how the system should be built so it holds up as the client grows.",
      "After launch I stay on the product, keeping it fast, secure and up to date, and adding the features the client needs next.",
    ],
    photo: "/images/team/shantanu.jpg",
    avatar: "/images/team/shantanu-avatar.jpg",
    location: "India", // TODO: city
    experienceYears: undefined, // TODO: e.g. 5
    focus: ["Full-stack development", "Architecture", "Client delivery"],
    expertise: [
      { label: "Domains", items: ["E-commerce", "SaaS platforms", "Factory & business software", "AI chatbots"] },
      // TODO: the languages, frameworks and tools you use most.
      { label: "Technologies", items: [] },
    ],
    career: [
      {
        kind: "work",
        title: "Product Manager",
        organization: "GNWebSoft Pvt. Ltd.",
        start: "2026",
        // Shown as polaroids beside this role. Add a `caption` (e.g. "Weekend ride") if you like.
        photos: [
          {
            src: "/images/team/shantanu-2026-01.jpg",
            alt: "Shantanu Kyada standing on a beach with his arms folded",
          },
          {
            src: "/images/team/shantanu-2026-09.jpg",
            alt: "Shantanu Kyada sitting on a motorcycle beside a lake, with green hills behind",
          },
        ],
      },
      {
        kind: "founder",
        title: "Co-founder",
        organization: site.name,
        start: "2025",
        description: "Works on every VSCodesLabs project.",
        projects: ["apparel-60", "diamond-polymer", "appointment-saas", "mv-bot"],
      },
      // TODO (optional): add your university and branch, e.g. organization: "…", title: "B.Tech, Computer Engineering".
      { kind: "education", title: "Graduated with a B.Tech", start: "2025", point: true },
      {
        kind: "work",
        title: "Associate Product Manager",
        organization: "GNWebSoft Pvt. Ltd.",
        start: "2024",
        end: "2026",
      },
    ],
    languages: [], // TODO: e.g. ["English", "Hindi", "Gujarati"]
    quote: undefined, // TODO: one line about how you work with clients
    email: "", // TODO: direct email, or leave empty to use the studio email
    links: [
      { label: "LinkedIn", href: "" },
      { label: "GitHub", href: "" },
    ],
  },
  {
    slug: "vedant-chauhan",
    name: "Vedant Chauhan",
    // TODO: your real title, e.g. "Co-founder · Product & frontend"
    role: "Co-founder",
    // TODO: one line on what you're known for.
    headline: "Full-stack engineer focused on product, UI and integrations.",
    bio: "Works across the stack, from product design and front-end builds to integrations and keeping live products running smoothly.",
    // TODO: your own story, in your own words.
    about: [
      "I care about how the software feels to the people who use it every day, whether that's a shopper checking out, a business owner managing bookings or a factory team logging stock.",
      "I build those experiences end to end, connect them to the tools our clients already rely on, and keep improving them after launch.",
    ],
    photo: "/images/team/vedant.jpg",
    avatar: "/images/team/vedant-avatar.jpg",
    location: "India", // TODO: city
    experienceYears: undefined, // TODO: e.g. 5
    focus: ["Full-stack development", "Product & UI", "Integrations"],
    expertise: [
      { label: "Domains", items: ["E-commerce", "SaaS platforms", "Factory & business software", "AI chatbots"] },
      // TODO: the languages, frameworks and tools you use most.
      { label: "Technologies", items: [] },
    ],
    career: [
      {
        kind: "founder",
        title: "Co-founder",
        organization: site.name,
        start: "2025",
        description: "Works on every VSCodesLabs project.",
        projects: ["apparel-60", "diamond-polymer", "appointment-saas", "mv-bot"],
        // Shown as polaroids beside this entry. (The Holi photo has the crowd behind him removed.)
        photos: [
          {
            src: "/images/team/vedant-night.jpg",
            alt: "Vedant Chauhan smiling at a table on a terrace lit with string lights",
          },
          {
            src: "/images/team/vedant-holi.jpg",
            alt: "Vedant Chauhan smiling at a Holi celebration, with a colourful canopy and stage behind him",
          },
        ],
      },
      {
        kind: "work",
        title: "Data Analyst",
        organization: "Inkey IT Solutions Pvt. Ltd.",
        start: "2025-01",
      },
      // TODO (optional): add your university and branch.
      { kind: "education", title: "Graduated with a B.Tech", start: "2025", point: true },
    ],
    languages: [],
    quote: undefined,
    email: "",
    links: [
      { label: "LinkedIn", href: "" },
      { label: "GitHub", href: "" },
    ],
  },
];

export function getMember(slug: string) {
  return team.find((member) => member.slug === slug);
}

export function firstName(member: TeamMember) {
  return member.name.split(" ")[0];
}
