import type { Testimonial } from "@/types/content";

/**
 * Client quotes are the strongest trust signal on the site.
 * The section stays hidden until you add at least one.
 * Use real quotes only, with the client's permission.
 *
 * Example:
 * {
 *   quote: "They rebuilt our store in six weeks and still answer every message the same day.",
 *   name: "Full Name",
 *   title: "Founder",
 *   company: "Apparel 60",
 *   project: "apparel-60",
 * },
 */
export const testimonials: Testimonial[] = [];

export function testimonialsFor(projectSlug: string) {
  return testimonials.filter((testimonial) => testimonial.project === projectSlug);
}
