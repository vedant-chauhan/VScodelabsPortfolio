import type { Faq, ProcessStep, Stat, TechGroup } from "@/types/content";

/**
 * Animated numbers in the "Why us" section. Keep them true.
 * TODO: once you have them, swap in stronger numbers such as years of experience,
 * projects delivered, clients served or uptime.
 */
export const stats: Stat[] = [
  { visual: "projects", value: 4, suffix: "+", label: "Products live in production" },
  { visual: "team", value: 2, label: "Partners on every project" },
  { visual: "reply", value: 24, prefix: "<", suffix: "h", label: "First reply to new enquiries" },
  { visual: "services", value: 6, label: "Services under one roof" },
];

/** Words that scroll across the band under the hero. */
export const marquee = [
  "E-commerce stores",
  "SaaS platforms",
  "Factory & business software",
  "AI chatbots",
  "Websites & web apps",
  "Maintenance & support",
  "Built, launched & maintained",
];

/** Short proof points in the "Why us" section. Keep them factual. */
export const highlights = [
  { title: "End to end", description: "Planning, design, build, hosting and launch, handled by one team." },
  { title: "Live in production", description: "Every case study here is a real product in use today." },
  { title: "Here after launch", description: "We maintain what we build, and take over existing projects." },
  { title: "Direct access", description: "You talk to the two people who write the code." },
];

export const process: ProcessStep[] = [
  {
    title: "Discover",
    icon: "compass",
    description: "We learn about your business, users and goals, then agree on scope, timeline and cost in writing.",
  },
  {
    title: "Design",
    icon: "pen-tool",
    description: "Flows and screens you can review and change before development starts.",
  },
  {
    title: "Build",
    icon: "code",
    description: "Development in short cycles with regular demos, so you see progress as it happens.",
  },
  {
    title: "Launch",
    icon: "rocket",
    description: "Testing, deployment, domain and hosting. We handle go-live end to end.",
  },
  {
    title: "Maintain",
    icon: "wrench",
    description: "Monitoring, fixes and new features after launch, on a plan that suits you.",
  },
];

/**
 * TODO: this is a starter list. Replace it with the tools you actually use —
 * clients and recruiters do read it.
 */
export const techStack: TechGroup[] = [
  { label: "Frontend", items: ["React", "Next.js", "TypeScript", "Tailwind CSS"] },
  { label: "Backend", items: ["Node.js", "Express", "REST APIs", "Python"] },
  { label: "Data", items: ["PostgreSQL", "MySQL", "MongoDB", "Redis"] },
  { label: "Cloud & DevOps", items: ["AWS", "Vercel", "Docker", "CI/CD"] },
  { label: "AI & integrations", items: ["OpenAI / LLM APIs", "Payment gateways", "WhatsApp & SMS APIs"] },
];

export const values = [
  {
    title: "Ownership",
    description: "We treat your product like our own, before and after launch.",
  },
  {
    title: "Plain communication",
    description: "Clear estimates, regular updates and no jargon. You always know where things stand.",
  },
  {
    title: "Built to last",
    description: "Clean, documented code that is easy to extend, whether by us or by your future team.",
  },
];

/** TODO: these answers are business policies — confirm each one is true for you. */
export const faqs: Faq[] = [
  {
    question: "How much does a project cost?",
    answer:
      "It depends on scope. After a short discovery call we send a fixed quote for well-defined projects, or a monthly rate for ongoing work. Small websites start lower than full platforms.",
  },
  {
    question: "How long does it take?",
    answer:
      "A business website usually takes a few weeks; e-commerce stores, SaaS products and custom systems take longer. You'll get a timeline with milestones before we start.",
  },
  {
    question: "Do you maintain the product after launch?",
    answer:
      "Yes. We offer maintenance plans covering hosting, updates, fixes and new features, and we already maintain several of the products shown here.",
  },
  {
    question: "Can you take over an existing project?",
    answer:
      "Yes. We start with a code and infrastructure review, fix what's urgent, then continue development and support.",
  },
  {
    question: "Who owns the code?",
    answer: "You do. Once the project is paid for, the source code and accounts are handed over to you.",
  },
];
