import type { Service } from "@/types/content";

/**
 * What you sell. Order matters: the first four appear first on the home page.
 * Each service links to projects that list its `id` in `projects.ts`.
 */
export const services: Service[] = [
  {
    id: "ecommerce",
    title: "E-commerce development",
    short: "E-commerce",
    summary:
      "Online stores that sell: catalogue, cart, checkout, payments and the admin tools to run orders day to day.",
    icon: "shopping-bag",
    deliverables: [
      "Custom storefront, mobile-first",
      "Payment gateway integration",
      "Product, inventory and order management",
      "Admin dashboard for your team",
      "SEO and page-speed setup",
    ],
  },
  {
    id: "saas",
    title: "SaaS product development",
    short: "SaaS products",
    summary:
      "Multi-business platforms with accounts, roles and dashboards — built so one product can serve many customers.",
    icon: "layout-dashboard",
    deliverables: [
      "Multi-tenant architecture",
      "Sign-up, login and role-based access",
      "Subscription and billing flows",
      "Dashboards and reporting",
      "Email and in-app notifications",
    ],
  },
  {
    id: "business-software",
    title: "Custom business software",
    short: "Business software",
    summary:
      "Systems made for how your company actually works — inventory, production, dispatch and reporting in one place.",
    icon: "factory",
    deliverables: [
      "Inventory and stock tracking",
      "Production and workflow management",
      "Orders, dispatch and shipment tracking",
      "Reports and data exports",
      "User roles and permissions",
    ],
  },
  {
    id: "chatbots",
    title: "AI chatbots & automation",
    short: "AI chatbots",
    summary:
      "Chatbots that answer customer questions, capture leads and hand off to your team when a human is needed.",
    icon: "bot",
    deliverables: [
      "Website and messaging chatbots",
      "Answers grounded in your own content",
      "Lead capture and human handoff",
      "Integrations with your existing tools",
    ],
  },
  {
    id: "web",
    title: "Websites & web apps",
    short: "Websites",
    summary:
      "Fast, responsive business websites, portals and internal tools built on modern frameworks.",
    icon: "globe",
    deliverables: [
      "Company and marketing websites",
      "Customer and partner portals",
      "Internal tools and admin panels",
      "Third-party API integrations",
    ],
  },
  {
    id: "maintenance",
    title: "Maintenance & support",
    short: "Maintenance",
    summary:
      "We keep live products healthy after launch: fixes, updates, hosting, backups and new features as you grow.",
    icon: "life-buoy",
    deliverables: [
      "Bug fixes and dependency updates",
      "Hosting, deployment and backups",
      "Performance and security patches",
      "New features on a monthly plan",
      "Takeover of existing projects",
    ],
  },
];

export function getService(id: string) {
  return services.find((service) => service.id === id);
}
