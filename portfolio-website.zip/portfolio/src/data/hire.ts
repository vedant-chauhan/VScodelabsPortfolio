/**
 * Content for the Hire pages (/hire and /hire/<partner>).
 * TODO: these describe how you work and get paid, so confirm every line is true for you.
 */

export const engagementModels = [
  {
    title: "Fixed-scope project",
    bestFor: "New websites, online stores, MVPs and clearly defined features.",
    points: [
      "Scope, timeline and price agreed in writing before we start",
      "Progress demos at every milestone",
      "Code, accounts and documentation handed over at the end",
    ],
  },
  {
    title: "Monthly retainer",
    bestFor: "Products that keep growing after launch.",
    points: [
      "A set amount of development time each month",
      "We work through your roadmap in priority order",
      "One team that already knows your product",
    ],
  },
  {
    title: "Maintenance & support",
    bestFor: "Live products that need to stay fast, secure and up to date.",
    points: ["Hosting, backups and updates", "Bug fixes and security patches", "Help when something breaks"],
  },
];

export const nextSteps = [
  { title: "We reply", description: "Usually within one working day, with any questions about your brief." },
  { title: "Discovery call", description: "A short call to understand your goals, users and constraints." },
  { title: "Proposal", description: "Scope, timeline and a clear quote, in writing." },
  { title: "Kick-off", description: "We start building, with regular demos as your product takes shape." },
];
