import type { Project } from "@/types/content";

/**
 * Case studies. Each entry becomes a card on /projects and a page at /projects/<slug>.
 *
 * TODO for every project (see CONTENT_CHECKLIST.md):
 *  - `stack`: the tools you actually used (the section stays hidden while empty)
 *  - `year`, `client`, `role`
 *  - `results`: real outcomes, numbers if you have them
 *  - `cover.image`: a screenshot in /public/images/projects (1600×1000)
 *  - confirm the features below match what you built
 *  - `team`: keep only the partner(s) who actually worked on each project
 */
export const projects: Project[] = [
  {
    slug: "apparel-60",
    name: "Apparel 60",
    category: "E-commerce",
    tagline: "A complete online store for a clothing brand.",
    summary:
      "A production e-commerce platform for Apparel 60, covering catalogue, cart, checkout and order management. Live at apparel60.co.in.",
    industry: "Fashion & apparel retail",
    liveUrl: "https://www.apparel60.co.in",
    role: "Design, development, launch & ongoing maintenance",
    services: ["ecommerce", "maintenance"],
    team: ["shantanu-kyada", "vedant-chauhan"],
    stack: [],
    challenge:
      "Apparel 60 needed its own storefront to sell directly to customers: a catalogue the team can update without a developer, and a smooth path from browsing to paying on any device.",
    solution:
      "We built and launched a custom e-commerce platform: the customer-facing store, a cart and checkout flow, and the admin tools the team uses to manage products and orders. We continue to maintain and improve it.",
    features: [
      {
        title: "Product catalogue",
        description: "Categories, product pages, sizes and variants that the team manages from the admin panel.",
      },
      {
        title: "Cart & checkout",
        description: "A short checkout with online payments, built mobile-first.",
      },
      {
        title: "Order management",
        description: "Orders, statuses and customer details in one dashboard.",
      },
      {
        title: "Ongoing maintenance",
        description: "Updates, fixes and new features after launch.",
      },
    ],
    results: ["Live in production at apparel60.co.in", "Maintained by us since launch"],
    cover: { variant: "store", from: "#f97362", to: "#f6b35c" },
    featured: true,
  },
  {
    // TODO: give the product its real name and slug.
    slug: "appointment-saas",
    name: "Appointment SaaS",
    category: "SaaS platform",
    tagline: "One place for any business to manage its schedule and operations.",
    summary:
      "A multi-business SaaS platform where any business can manage appointments, staff schedules and day-to-day operations from a single dashboard.",
    industry: "Service businesses (any sector)",
    role: "Product design & full-stack development",
    services: ["saas", "web"],
    team: ["shantanu-kyada", "vedant-chauhan"],
    stack: [],
    challenge:
      "Service businesses juggle bookings across phone calls, messages and paper diaries, which leads to double bookings, missed appointments and no clear view of the day.",
    solution:
      "We built a SaaS platform any business can sign up for and set up for itself: services, staff, working hours and bookings, all run from one dashboard.",
    features: [
      {
        title: "Online booking",
        description: "Customers pick a service and an open slot; the calendar updates instantly.",
      },
      {
        title: "Staff & schedule management",
        description: "Working hours, breaks and appointments for every team member.",
      },
      {
        title: "Multi-business",
        description: "Each business gets its own workspace, settings and data on the same platform.",
      },
      {
        title: "Business dashboard",
        description: "Today's schedule and key activity at a glance.",
      },
    ],
    results: ["Built to serve any business type from one codebase"],
    cover: { variant: "calendar", from: "#5b7cfa", to: "#8f6cf0" },
    featured: true,
  },
  {
    slug: "diamond-polymer",
    name: "Diamond Polymer",
    category: "Factory management",
    tagline: "Custom software that runs the factory, from inventory to shipments.",
    summary:
      "A custom application built for Diamond Polymer to manage factory operations end to end, from raw-material inventory through to dispatch and shipments.",
    industry: "Manufacturing",
    client: "Diamond Polymer",
    confidential: true,
    role: "Requirements, design & full-stack development",
    services: ["business-software", "maintenance"],
    team: ["shantanu-kyada", "vedant-chauhan"],
    stack: [],
    challenge:
      "Stock, production and dispatch were tracked in separate places, so nobody had a reliable, up-to-date view of what was in the factory or what had shipped.",
    solution:
      "We built a single application around the factory's own workflow: inventory is recorded as it arrives, moves through production, and leaves as tracked shipments, with reports at every stage.",
    features: [
      {
        title: "Inventory management",
        description: "Raw materials and finished goods, with stock levels that update as work happens.",
      },
      {
        title: "Production tracking",
        description: "Follow material through each stage of the factory floor.",
      },
      {
        title: "Shipment management",
        description: "Dispatch orders, track shipments and keep delivery records.",
      },
      {
        title: "Reports",
        description: "Stock, production and dispatch reports for management.",
      },
    ],
    results: ["One system replacing scattered records", "In daily use on the factory floor"],
    cover: { variant: "dashboard", from: "#18a38a", to: "#3cc6c0" },
    featured: true,
  },
  {
    slug: "mv-bot",
    name: "MV Bot",
    category: "AI chatbot",
    tagline: "A conversational assistant that handles routine questions around the clock.",
    // TODO: describe what MV Bot does, who uses it and where it runs.
    summary:
      "MV Bot is a chatbot application that answers questions, guides users and handles routine conversations automatically.",
    industry: "Customer support",
    role: "Design & development",
    services: ["chatbots"],
    team: ["shantanu-kyada", "vedant-chauhan"],
    stack: [],
    challenge:
      "Teams lose hours answering the same questions again and again, and customers who message outside working hours wait for a reply.",
    solution:
      "We built MV Bot, a chatbot that answers common questions instantly, guides users to the right information and hands the conversation to a person when it needs one.",
    features: [
      {
        title: "Natural conversations",
        description: "Understands questions written the way people actually type them.",
      },
      {
        title: "Always available",
        description: "Replies instantly at any hour.",
      },
      {
        title: "Human handoff",
        description: "Passes complex conversations to your team with context.",
      },
    ],
    results: ["Instant answers to routine questions"],
    cover: { variant: "chat", from: "#2f3440", to: "#59617a" },
    featured: true,
  },
];

export function getProject(slug: string) {
  return projects.find((project) => project.slug === slug);
}

export const featuredProjects = projects.filter((project) => project.featured);

export function projectsByMember(slug: string) {
  return projects.filter((project) => project.team.includes(slug));
}

/**
 * Other work, shown as a list under the case studies on /projects.
 * Add the smaller or confidential projects you've delivered, e.g.
 * { name: "Clinic website", category: "Website", description: "Booking-enabled site for a dental clinic." }
 */
export const otherWork: { name: string; category: string; description: string; href?: string }[] = [];
