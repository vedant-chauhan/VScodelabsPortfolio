/**
 * Global site settings: brand, contact details, navigation.
 * Every value marked TODO needs your real details before launch.
 */

export const site = {
  name: "VSCodesLabs",
  // Two or three characters used in the logo mark and favicon.
  monogram: "V/S",
  tagline: "Software that runs your business",
  description:
    "A two-partner software studio. We design, build and maintain e-commerce stores, SaaS platforms, custom business software and AI chatbots.",

  // Set NEXT_PUBLIC_SITE_URL in .env once you have a domain.
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",

  // Contact details. Empty values are hidden on the site.
  email: "vscodeslabs@gmail.com",
  /** Phone numbers with country code, listed in this order wherever phones are shown. */
  phones: ["+91 91048 39400", "+91 91735 08734"],
  /**
   * WhatsApp number with country code, e.g. "+91 98765 43210".
   * Turns on the floating chat button on every page and the WhatsApp link on /contact.
   */
  whatsapp: "",
  /** Message pre-filled in the visitor's WhatsApp when they tap the button. */
  whatsappMessage: "Hi! I found your website and would like to talk about a project.",
  location: "India · Working with clients everywhere",
  availability: "Taking on new projects",
  /** Typical first-reply time shown on the contact page. */
  responseTime: "We reply within one working day.",

  // TODO: add your profile URLs. Entries with an empty href are hidden.
  socials: [
    { label: "LinkedIn", href: "" },
    { label: "GitHub", href: "" },
    { label: "Instagram", href: "" },
  ],

  // TODO: pick the ranges and currency that fit your clients.
  budgets: ["Under ₹50,000", "₹50,000 – ₹2 lakh", "₹2 – 5 lakh", "₹5 lakh+", "Not sure yet"],
};

export const navigation = [
  { label: "Services", href: "/services" },
  { label: "Work", href: "/projects" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
] as const;
