# Prompt: Build our studio portfolio website

**How to use this file**

1. Fill in the **"Your details"** block in section 0. Anything you leave as-is stays a placeholder that the site hides or marks TODO.
2. Copy **everything from section 0 to the end** and paste it into your AI coding tool
   (Claude, ChatGPT, Cursor, Windsurf, v0, Lovable, Bolt, etc.).
3. If the tool works best in small steps, send one section at a time, starting with sections 1–4, then the pages.

**Recommended build order** (for tools that work in steps):
1. Project setup, design tokens (light and dark) and the boot script (sections 2, 8)
2. Types and data files (section 4, copy from section 7)
3. Layout: header with the theme toggle, footer, the WhatsApp button and the global effects (section 6, "Global layout")
4. Pages: Home, Services, Work, case studies, About, Contact, 404
5. Motion and creative details (section 8)
6. Partner profiles with career timelines, and the Hire pages
7. SEO, docs and the acceptance checks (sections 12–15)

### Using it with Claude

- **Claude Code (recommended: it creates the files and runs the build for you).** Put this file in an empty folder,
  open Claude Code there, and send:
  > Read `website-build-prompt.md` and build the website it describes in this folder. Follow every section,
  > run `npm run build`, `npm run lint` and `npm run typecheck` until all pass, then check the acceptance criteria in section 15.
- **claude.ai chat.** Attach this file (or paste it) and send:
  > Build the website described in the attached prompt. Start with the project setup and `src/data/*` files,
  > then give me every remaining file in full, one per code block, each labelled with its path.

  If the reply stops partway, send "continue from the last file".

---

## 0. Your details (edit before pasting)

```yaml
studio_name: "VSCodesLabs"              # the company name, used everywhere
monogram: "V/S"                          # 2–3 characters for the logo mark and favicon
tagline: "Software that runs your business"
domain: "https://yourdomain.com"
email: "vscodeslabs@gmail.com"
phones: ["+91 91048 39400", "+91 91735 08734"]   # with country code; empty list = hidden
whatsapp: ""                             # e.g. "+91 98765 43210"; empty hides the chat button
whatsapp_message: "Hi! I found your website and would like to talk about a project."
location: "India · Working with clients everywhere"
availability: "Taking on new projects"
response_time: "We reply within one working day."
budget_ranges: ["Under ₹50,000", "₹50,000 – ₹2 lakh", "₹2 – 5 lakh", "₹5 lakh+", "Not sure yet"]
socials:
  linkedin: ""
  github: ""
  instagram: ""

# The more real detail here, the more clients will trust you. Empty fields are hidden.
partners:
  - slug: "shantanu-kyada"
    name: "Shantanu Kyada"
    role: "Co-founder"
    headline: "Full-stack engineer focused on architecture and delivery."
    bio: "Works across the stack, from planning and architecture to shipping and maintaining production systems for clients."
    about:           # 2–3 short first-person paragraphs for the profile page
      - "I'm involved in our projects from the first call: understanding how the business works, shaping the scope, and planning how the system should be built so it holds up as the client grows."
      - "After launch I stay on the product, keeping it fast, secure and up to date, and adding the features the client needs next."
    photo: "/images/team/shantanu.jpg"          # 4:5 portrait, 1024×1280, face in the upper third (supplied separately)
    avatar: "/images/team/shantanu-avatar.jpg"  # square head-and-shoulders crop, 256×256, for small round avatars
    location: "India"
    experience_years:   # e.g. 5
    focus: ["Full-stack development", "Architecture", "Client delivery"]
    domains: ["E-commerce", "SaaS platforms", "Factory & business software", "AI chatbots"]
    technologies: []  # e.g. ["React", "Node.js", "PostgreSQL", "AWS"]
    # Career history: plotted as a chart + timeline. Dates "YYYY" or "YYYY-MM"; no end = ongoing.
    # kind: education | work | freelance | founder | milestone | certification
    # point: true = a single date (e.g. a graduation year). projects: case-study slugs worked on in that role.
    career:
      - { kind: "work", title: "Product Manager", organization: "GNWebSoft Pvt. Ltd.", start: "2026",
          # photos from this period, shown as polaroids beside the entry (files supplied separately, 4:5, no EXIF)
          photos: [
            { src: "/images/team/shantanu-2026-01.jpg", alt: "Shantanu Kyada standing on a beach with his arms folded" },
            { src: "/images/team/shantanu-2026-09.jpg", alt: "Shantanu Kyada sitting on a motorcycle beside a lake, with green hills behind" } ] }
      - { kind: "founder", title: "Co-founder", organization: "{studio_name}", start: "2025",
          description: "Works on every VSCodesLabs project.",
          projects: ["apparel-60", "diamond-polymer", "appointment-saas", "mv-bot"] }
      - { kind: "education", title: "Graduated with a B.Tech", start: "2025", point: true }  # add university/branch if wanted
      - { kind: "work", title: "Associate Product Manager", organization: "GNWebSoft Pvt. Ltd.", start: "2024", end: "2026" }
    languages: []     # e.g. ["English", "Hindi", "Gujarati"]
    quote: ""         # one line on how you work with clients
    email: ""         # empty = studio email
    linkedin: ""
    github: ""
  - slug: "vedant-chauhan"
    name: "Vedant Chauhan"
    role: "Co-founder"
    headline: "Full-stack engineer focused on product, UI and integrations."
    bio: "Works across the stack, from product design and front-end builds to integrations and keeping live products running smoothly."
    about:
      - "I care about how the software feels to the people who use it every day, whether that's a shopper checking out, a business owner managing bookings or a factory team logging stock."
      - "I build those experiences end to end, connect them to the tools our clients already rely on, and keep improving them after launch."
    photo: "/images/team/vedant.jpg"            # 4:5 portrait (supplied separately)
    avatar: "/images/team/vedant-avatar.jpg"
    location: "India"
    experience_years:
    focus: ["Full-stack development", "Product & UI", "Integrations"]
    domains: ["E-commerce", "SaaS platforms", "Factory & business software", "AI chatbots"]
    technologies: []
    career:
      - { kind: "founder", title: "Co-founder", organization: "{studio_name}", start: "2025",
          description: "Works on every VSCodesLabs project.",
          projects: ["apparel-60", "diamond-polymer", "appointment-saas", "mv-bot"],
          photos: [
            { src: "/images/team/vedant-night.jpg", alt: "Vedant Chauhan smiling at a table on a terrace lit with string lights" },
            { src: "/images/team/vedant-holi.jpg", alt: "Vedant Chauhan smiling at a Holi celebration, with a colourful canopy and stage behind him" } ] }
      - { kind: "work", title: "Data Analyst", organization: "Inkey IT Solutions Pvt. Ltd.", start: "2025-01" }
      - { kind: "education", title: "Graduated with a B.Tech", start: "2025", point: true }
    languages: []
    quote: ""
    email: ""
    linkedin: ""
    github: ""

# Real client quotes only, with permission. The section is hidden while this is empty.
testimonials: []   # e.g. { quote: "…", name: "…", title: "Founder", company: "Apparel 60", project: "apparel-60" }
```

---

## 1. Role and goal

You are a senior full-stack engineer and product designer. Build a **production-ready portfolio and
lead-generation website** for a two-partner software studio (the partners are listed in section 0).

The site must:

- Explain what the studio sells: e-commerce, SaaS products, custom business software, AI chatbots, websites
  and long-term maintenance.
- Prove it with four real case studies: **Apparel 60**, **Appointment SaaS**, **Diamond Polymer**, **MV Bot**.
- Mention that the studio has also delivered and maintained many other live projects using a wide range of tools.
- Turn visitors into enquiries through **full Hire pages** (one for the studio and one per partner), a contact
  form, email links and a floating WhatsApp button.
- **Build trust in the two founders**: real faces, a detailed profile page for each, **plotted career timelines**,
  who worked on what, and client testimonials.
- **Feel creative and modern, not plain**: a playful light/dark switch, page transitions with shared-element morphs,
  staggered entrances, words that rise in, scroll reveals, count-up numbers, a scrolling ticker, a cursor
  spotlight and hover micro-interactions. All of it stays fast, never gets in the way, and
  switches off for reduced-motion users.
- Be easy for non-developers to update: **all content lives in a few data files**, never hard-coded in components.

## 2. Tech stack

Use this stack unless your environment requires otherwise. If it does, keep the same structure and behaviour.

- **Next.js 16.4+** (App Router, TypeScript, `src/` directory, `@/*` import alias, `cacheComponents` and
  `partialPrefetching` enabled) with **React 19.3** (for `<ViewTransition>`)
- **Tailwind CSS v4**, with design tokens as CSS variables in `src/app/globals.css`
- **lucide-react** for icons
- **Geist Sans + Geist Mono** via `next/font/google`
- Contact form: a **Server Action** plus the **Resend REST API**, called with `fetch` (no SDK)
- **GSAP 3.15** (`gsap`, `gsap/ScrollTrigger`, `@gsap/react` for `useGSAP`; free for commercial use, including
  all plugins) for scroll-scrubbed effects and the hero parallax.
- **Lenis 1.3** for smooth, inertial wheel scrolling, synced to ScrollTrigger.
- No database, CMS or UI component library. Everything else animates with CSS. Keep dependencies minimal and
  pin exact versions.
- Target hosting: Vercel (must also run with `npm run build && npm start` on any Node 20.9+ host)

Notes for Next.js 16 with `cacheComponents: true`:

- Every page should prerender as static.
- Values that change between renders, such as `new Date()` for the footer copyright year, must be inside an async
  component marked `"use cache"`, or the build fails.
- Wrap the client component that calls `usePathname()` (active nav state) in `<Suspense>` with a static fallback.
- `params` is a Promise. Await it in `generateMetadata` and the page.
- In dynamic routes (`/projects/[slug]`, `/team/[slug]`, `/hire/[slug]`), use `generateStaticParams`. Read `params`
  inside a child component wrapped in `<Suspense fallback={<PageSkeleton />}>`, or dev mode warns that URL data
  blocks instant navigation. The pages are still fully prerendered.
- `<ViewTransition>` is imported from `react` and needs no config. Put it in the root layout and on the elements
  that morph.
- With `scroll-behavior: smooth` on `html`, add `data-scroll-behavior="smooth"` to `<html>`. Next.js asks for this.
- The current year/month used by the footer and the career chart's "Today" line come from a `"use cache"` helper.

## 3. Non-negotiable rules

1. **Never invent facts.** No fake client logos, testimonials, statistics, years of experience, career history or
   project counts. Where real data is missing, write neutral copy and leave a `// TODO:` comment in the data file.
   Placeholder career entries carry `sample: true`. They render only in development (with a "Sample" badge) and are
   filtered out of production builds.
2. **Empty optional fields are hidden**, never shown as blank labels. This covers phone, WhatsApp, social links,
   project year, client, tech stack, photos and the "other work" list.
3. **Content is separated from presentation.** Components read from `src/data/*` only.
4. **Responsive from 360px wide**, with no horizontal scrolling.
5. **Light and dark mode**: follow `prefers-color-scheme` by default, with a header toggle that overrides it
   (section 8). Use tokens only (no hard-coded colours in components,
   except inside project cover illustrations and the WhatsApp brand green).
6. **Accessible**: semantic landmarks, a skip link, visible focus rings, labelled form fields, `aria-current` on the
   active nav link, `aria-live` form messages, and sufficient colour contrast.
7. The build, type-check and lint must pass with zero errors.

## 4. Content architecture

Create typed data files. Define the types in `src/types/content.ts`:

```ts
type IconName = "shopping-bag" | "layout-dashboard" | "factory" | "bot" | "globe" | "life-buoy"
  | "compass" | "pen-tool" | "code" | "rocket" | "wrench";

type Service = { id: string; title: string; short: string /* e.g. "E-commerce", for the wheel */; summary: string; icon: IconName; deliverables: string[] };

type CoverVariant = "store" | "calendar" | "dashboard" | "chat";

type Project = {
  slug: string; name: string; category: string; tagline: string; summary: string; industry: string;
  liveUrl?: string; confidential?: boolean; client?: string; year?: string; role?: string;
  services: string[];          // Service ids
  stack: string[];             // empty = section hidden
  challenge: string; solution: string;
  features: { title: string; description: string }[];
  results: string[];
  cover: { variant: CoverVariant; from: string; to: string; image?: string; imageAlt?: string };
  featured: boolean;
};

type TeamMember = {
  slug: string; name: string; role: string; headline: string; bio: string;
  about: string[];             // profile-page paragraphs
  photo?: string;  // 4:5 portrait, face in the upper third
  avatar?: string; // square head-and-shoulders crop for small round avatars; falls back to photo
  location?: string; experienceYears?: number;
  focus: string[];
  expertise: { label: string; items: string[] }[];   // e.g. Domains, Technologies; empty groups hidden
  career: CareerEntry[];
  languages: string[]; quote?: string; email?: string;
  links: { label: string; href: string }[];
};
type CareerEntry = {
  kind: "education" | "work" | "freelance" | "founder" | "milestone" | "certification";
  title: string; organization?: string;
  start: string;   // "2021" or "2021-06"
  end?: string;    // omit = present; unused for single dates
  point?: boolean; // a single date rather than a span, e.g. a graduation year (milestone/certification always are)
  description?: string;
  projects?: string[]; // case-study slugs worked on in this role; shown as links
  photos?: CareerPhoto[]; // shown as polaroids beside the entry in the timeline, never in the chart
  href?: string;   // e.g. a certificate's verification page
  sample?: boolean; // placeholder: rendered only in development (with a "Sample" badge), never in production
};
type CareerPhoto = { src: string /* under /public, 4:5 */; alt: string; caption?: string };
type Testimonial = { quote: string; name: string; title?: string; company?: string; project?: string };
type Stat = {
  value: number; prefix?: string; suffix?: string; label: string;
  visual?: "projects" | "team" | "services" | "reply";   // illustration in its bento tile
};
// Project also gets: team: string[]  (partner slugs who worked on it; shown as "Built by" and on profiles)
type ProcessStep = { title: string; description: string; icon: IconName };
type TechGroup = { label: string; items: string[] };
type Faq = { question: string; answer: string };
```

Data files:

| File | Contents |
| --- | --- |
| `src/data/site.ts` | Everything from section 0 plus `navigation` (Services, Work, About, Contact). `url` comes from `NEXT_PUBLIC_SITE_URL` and defaults to `http://localhost:3000`. |
| `src/data/services.ts` | `services[]` plus `getService(id)` |
| `src/data/projects.ts` | `projects[]`, `getProject(slug)`, `featuredProjects`, `projectsByMember(slug)`, and `otherWork[]` (`{ name, category, description, href? }`, empty by default) |
| `src/data/team.ts` | `team[]` (including each partner's `career`), `getMember(slug)`, `firstName(member)` |
| `src/data/testimonials.ts` | `testimonials[]` (empty by default), `testimonialsFor(projectSlug)` |
| `src/data/company.ts` | `stats`, `marquee`, `highlights`, `process`, `techStack`, `values`, `faqs` |
| `src/data/hire.ts` | `engagementModels` (title, bestFor, points[]), `nextSteps` (title, description) |

## 5. Site map

| Route | Purpose |
| --- | --- |
| `/` | Home |
| `/services` | All services in detail, the process and the FAQ |
| `/projects` | All case studies, plus "Beyond the case studies" |
| `/projects/[slug]` | One case-study page per project (`generateStaticParams`) |
| `/about` | Founders, why-us numbers, values, testimonials and tech stack |
| `/team/[slug]` | One full profile page per partner (`generateStaticParams`) |
| `/hire` | Full Hire page for the studio |
| `/hire/[slug]` | Hire page addressed to one partner (`generateStaticParams`) |
| `/contact` | Contact details and the enquiry form |
| `not-found` | Friendly 404 |
| `/sitemap.xml`, `/robots.txt` | Generated from the data files |
| `opengraph-image` | Generated 1200×630 link-preview image |
| `icon.svg` | Monogram favicon |

## 6. Page-by-page specification

### Global layout (every page)

- **Skip link** ("Skip to content") to `#main`.
- **Sticky header** (64px tall, translucent canvas background with backdrop blur, bottom border):
  - Logo: a dark rounded square with the monogram in mono font, plus the studio name.
  - Desktop nav: Services, Work, About, the **sun/moon theme toggle** (section 8), then a dark pill "💼 Hire us"
    button → `/hire`.
  - Mobile: a compact "Hire us" pill next to a hamburger. The hamburger opens a full-width dropdown (it fades
    down) with all four links, a "Switch to dark/light mode" row with the animated icon, and a full-width "Hire us"
    button. The menu closes when a link is tapped.
  - Every "Start a project" button on the site (hero and CTA band) also links to `/hire`.
- **Footer** with four columns: logo + description · Services (links to `/services#<id>`) · Studio (nav links) ·
  Contact (email, each phone number, location, socials if set). A bottom row reads "© {year} {studio}. All rights reserved."
  on the left and "Designed, built and maintained in-house." on the right. Below that, an **oversized wordmark**
  of the studio name fades into view, partly cut off by the bottom edge (section 8).
- **Floating WhatsApp button** (section 11).
- **Global effects**, mounted once in the root layout:
  - The `<head>` boot script (theme + motion flags)
  - A film-grain overlay
  - The spotlight tracker
  - `<ViewTransition default="page">` around `<main>`, for page transitions
- **Every section heading** (`SectionHeading`) is **two-tone**: a short bold lead (`title`, e.g. "Work.")
  followed by a muted continuation (`titleMuted`, e.g. "Products we've shipped and still look after.") in
  `text-ink/50`. The small mono eyebrow stays above. All the words rise out of a mask on scroll, the muted words
  continuing the stagger. **Every page title** (`PageHeader`) rises in word by word on load.
- **Smooth scrolling** (Lenis) on every page, mounted once in the root layout. Mouse wheel and trackpad only
  (touch stays native), and off for reduced motion. Anchor links glide to their target, and `scroll-padding-top:
  5rem` on `<html>` keeps them below the sticky header, both with Lenis and natively.

### Home `/`

1. **Hero** (two columns on desktop, stacked on mobile):
   - Availability pill with a pulsing green dot: "Taking on new projects".
   - H1: **"We build the software your business runs on."**
   - Sub-copy: "{Studio} is a two-partner studio. We design, build and maintain e-commerce stores, SaaS
     platforms, custom business software and AI chatbots, and we stay on after launch."
   - "runs on." is in a slowly **shimmering accent gradient** (`.text-shimmer`), with a hand-drawn SVG underline
     (in the plain accent colour) that draws itself in.
   - Buttons: "Start a project →" (primary) · "See our work" (secondary).
   - Below them, overlapping round avatars of both founders and the text "Work directly with the founders,
     **Shantanu & Vedant**", linking to `#team`.
   - Right side: a 2×2 grid of the four project cover illustrations, with the right column offset downward. Each cover
     rises in with a stagger, then floats gently and continuously, out of sync with the others.
   - Background: a faint dotted grid with a radial fade, plus two large blurred colour glows (accent and warm amber)
     that drift slowly.
   - **Mouse parallax** (desktop, fine pointer, motion allowed): the four covers sit at different depths
     (`data-depth` 1, 0.55, 0.8, 1.25) and ease toward the cursor with a slight tilt (GSAP `quickTo`, 1.1s
     power3). The glows (`data-depth` −1.6 / −1) drift the opposite way. Put the depth on its own wrapper layer,
     so it never fights the CSS rise and float animations.
   - Every hero element enters with a staggered fade-up (pill → headline lines → text → buttons → founders → covers).
   - Under the hero, a full-width band with a **scrolling marquee** of the `marquee` words in large muted type,
     separated by accent ✦ symbols. It pauses on hover and fades at both edges.
2. **Services**: eyebrow "What we do"; title "Services." + muted "From first idea to a product your team uses every
   day."; description "We take on the whole build, or the part you need help with."; an "All services" button.
   - **Desktop (≥1024px, JavaScript on, motion allowed): the pinned services wheel**, inspired by Sidejob.
     - A tall scroll area, `100vh + (n−1)×60vh`, with a sticky full-height frame under the header.
     - Across the top: a mono counter "03 / 06", a thin progress line that fills with accent, and "Scroll".
     - Left (1.45fr): the services' `short` names in huge type (`clamp(2.5rem, 4.3vw, 4.5rem)`), stacked in
       1.3em rows inside a masked column that fades at the top and bottom. As you scroll, GSAP scrubs the list's
       `yPercent` so the active name sits centred. The active name turns accent, slides right a little and gets a
       short accent dash in front. The others are `ink/15`.
     - Each name is a button that scrolls to its position.
     - Right: a spotlight card for the active service that re-enters with `rise` on change. It holds:
       - a slightly tilted cover of the first project using that service
       - the icon and full title
       - the summary and three deliverables
       - "See it in {project}" and "Learn more →"
     - Use ScrollTrigger with `scrub: 0.6` and no `pin`, and set the active index with
       `Math.round(progress × (n−1))`.
   - **Phones, reduced motion and no JavaScript**: six cards in a 3×2 grid joined by 1px dividers, each with an
     icon in a soft accent square, title, summary and "Learn more →", linking to `/services#<id>`. Cards have the
     cursor spotlight, and icons tilt and grow on hover.
   - Toggle between the two with CSS only: `.services-wheel` / `.services-cards`, keyed on
     `[data-motion="on"]` + a `min-width: 1024px` media query, so there's no flash.
3. **Selected work**: eyebrow "Selected work"; title "Products we've shipped and still look after.";
   description "Online retail, SaaS, factory operations and conversational AI, each built for a real business and
   running in production."; an "All projects" button. A two-column grid of project cards. Each card's cover
   **morphs** into the case-study cover when clicked.
4. **Testimonials** (only when `testimonials` isn't empty): eyebrow "Client words"; title "What our clients say."
   Quote cards with a large accent quotation mark, the quote, and name · title, company · linked project.
5. **Why us**: eyebrow "Why clients work with us"; title "A small team you can actually rely on."; description
   "No account managers or hand-offs in between. The people you meet on the first call are the people who build,
   launch and look after your product."
   - A **bento grid** of the `stats` with **count-up numbers** (suffix in the accent colour). Tiles have rounded
     canvas cards with the spotlight, and scale in one after another. The layout is one large 2×2 tile, two small
     tiles and one wide tile.
   - Each tile shows its `visual`:
     - `projects`: the four project covers fanned like playing cards; they spread further on hover
     - `team`: overlapping founder avatars that lift on hover
     - `reply`: a chat bubble with three bouncing typing dots
     - `services`: a row of the six service icons, lifting one after another on hover
   - Then the four `highlights` as check-icon items.
6. **Meet the founders** (`id="team"`): eyebrow "Meet the founders"; title "The two people behind every project.";
   description "You work directly with the partners who plan, design, build and support your product, from the
   first call to long after launch." Two large cards, each with:
   - A 5:4 portrait (photo, or a styled initials card on soft accent gradients with a dotted texture) that zooms
     slightly on hover and **morphs** into the profile portrait when opened. The whole card has the spotlight.
   - Role (accent) · location · "N+ years experience" (if set), then the name, headline, bio and focus chips.
   - "Worked on: …" (project names from `project.team`), and "View full profile →" (the whole card links to `/team/<slug>`).
   - A "💼 Hire {first name}" button → `/hire/<slug>` (with `relative z-10` above the stretched link), then
     "View full profile →", and LinkedIn/GitHub links where set.
7. **Process**: eyebrow "How we work"; title "Process." + muted "A clear path from first call to long after
   launch." It's laid out as an **interactive deck of cards** (`ProcessStack`, a client component using GSAP).
   - **Layout:** two columns on desktop. Left: the heading, then a step list (number, a coloured dash that
     widens when active, the name), where each row is a button that jumps to that step. Right: the deck with its
     controls below. On mobile there's a single column with the step list hidden.
   - **The deck:** five absolutely positioned cards in a container of `card height + 3.375rem`. The card
     `offset` places behind the front one gets this pose (`transformOrigin 50% 0%`):
     - `y = −min(offset,3) × 18px` (it peeks above)
     - `scale = 1 − depth × 0.05`
     - `rotation = [0, −1.4, 1.2, −0.8][depth]°`
     - `z-index = n − offset`
     - a `bg-surface` overlay at `depth × 16%`
     - `opacity 0` when `offset > 3`

     Each card has a 1.5-unit colour bar along its top edge, so the stacked cards show a layered band of step
     colours. Render the starting poses inline on the server (card 1 in front), and let GSAP take over after
     hydration.
   - **Card content:** none of it is rewritten.
     - a "Step 0N / 05" label in the step's colour (accent, founder violet, freelance teal, milestone coral,
       education amber) and an icon tile (compass, pen-tool, code, rocket, wrench)
     - the title in 3–4xl and the full description
     - a footer row: "Next: {next title}", or "Back to {first title}" on the last card, with a round arrow or
       restart icon button
     - a giant faint numeral in the corner
   - **Advancing:** clicking or tapping the front card advances the deck.
     1. The front card drops 42% of its height, tilts −5° and scales to 0.96 (0.32s, `power2.in`).
     2. It then moves to `z-index 0` and settles into the back pose (0.6s, `power3.out`).
     3. Meanwhile every other card steps one pose forward (0.6s, staggered 40ms).
     4. After the last card it cycles back to card 1.
   - **Going back:** the back card slides out from under the deck, jumps to the top layer and rises to the front.
   - **Jumping:** the dots and the step list riffle the short way round at 0.55× duration.
   - **Rapid taps:** finish the in-flight timeline first (`timeline.progress(1)`).
   - **Swiping:** pointer-drag the front card sideways. It follows the finger with a tilt. Past 70px it flings
     in that direction and goes to the back; otherwise it snaps back with `back.out`. Use `touch-action: pan-y`
     so vertical page scrolling still works on phones. A press with no movement counts as a tap.
   - **Cues that it's interactive:**
     - the visible stack edges
     - a pointer cursor on the front card, which lifts 6px with a deeper shadow on hover
     - the front card's footer button filled with ink, its arrow nudging
     - a "Click the card for the next step" hint (pointer-fine) or "Tap or swipe the card" hint (pointer-coarse)
     - a one-time wiggle of the front card the first time the deck scrolls into view
   - **Controls under the deck:** a ‹ previous button, five dots (the active one wide and coloured, each a jump
     button) and a › next button.
   - **Accessibility:**
     - The visual deck is `aria-hidden`.
     - An `aria-live="polite"` line announces "Step N of 5: Title. Description".
     - An sr-only ordered list carries every step.
     - The buttons carry `aria-label` / `aria-current="step"`.
   - **Reduced motion:** every move is instant (duration × 0) and there's no wiggle.
   - Used on Home and Services.
8. **Tech stack**: eyebrow "Tools"; title "We pick the stack for the project, not the other way round.";
   description "Across our live projects we've worked with a broad set of tools. These are the ones we reach for
   most." A definition list: group label (mono, uppercase) on the left, pill tags on the right.
9. **CTA band**: a dark rounded panel (`bg-ink`) with a blurred accent glow in the top-right corner. Title "Have a
   project in mind?"; text "Tell us what you're building. We'll get back with questions, a rough timeline and next
   steps."; a light "Start a project →" button (inverse variant) and "or email {email}".
10. A JSON-LD `ProfessionalService` script with name, description, url, email, telephone (every phone number, if any),
   `areaServed: "Worldwide"`, `knowsAbout` set to the service titles, and `founder` set to the partners as `Person` objects.

### Services `/services`

- Page header: eyebrow "Services"; H1 "Everything it takes to get your product live, and keep it running.";
  description "Hire us for a complete build, a single piece of it, or ongoing support for software you already
  have."
- One section per service (`id` used as the anchor; the site-wide `scroll-padding-top` keeps it clear of the sticky
  header), in two columns:
  - Left: icon, H2 title, summary, and "See it in:" with links to the projects that list this service.
  - Right: a surface card titled "What you get" with a checklist of deliverables.
- Then the Process, FAQ (accordion built with `<details>`, with a plus icon that rotates 45° when open) and CTA sections.

### Work `/projects`

- Header: eyebrow "Work"; H1 "Real products, built for real businesses."; description "A selection of the
  platforms we've designed, built and launched. Most are still maintained by us today."
- A grid of all project cards (two columns).
- A "Beyond the case studies" section (eyebrow "And more") with the text: "We've delivered and maintained a
  range of other live projects across different industries and tools, including several we can't show publicly.
  Ask us for examples close to what you're planning." Under it, show the `otherWork` list as rows
  (name/link · category · description) when it isn't empty.
- CTA.

### Case study `/projects/[slug]`

- "← All work" back link, eyebrow = category, H1 = name, summary.
- Actions: "Visit {domain} ↗" button when `liveUrl` is set (opens in a new tab); a "🔒 Private client system" chip
  when `confidential`.
- A large project cover, wrapped in `<ViewTransition name="project-<slug>" share="morph" default="none">` to match the
  card. Don't give it a load-in animation; the morph is its entrance.
- Two columns:
  - Left (sticky on desktop): "Built by", listing each partner on the project (avatar, name, role, linked to their
    profile). Then a facts list of Client, Industry, Our role and Year (only those set), plus Services (linked).
    "Built with" stack pills appear only when `stack` isn't empty.
  - Right: "The challenge" · "What we built" (solution text plus spotlight feature cards in a 2-column grid) · the project's
    testimonial, if any · "Outcome" (checklist).
- A "Next project" link to the next project, wrapping round to the first.
- CTA titled "Need something similar?"
- `generateMetadata`: title "{name} — {category}", description = summary. Unknown slugs → `notFound()`.

### About `/about`

- Header: eyebrow "About"; H1 "We're {first names joined with 'and'}."; description "Two partners who build
  software for businesses, from online stores and SaaS products to the systems that run a factory floor. We take
  projects from idea to launch, then stay on to keep them running." Add a TODO comment asking for the partners' real story.
- Then, in order:
  - The founder cards (eyebrow "The founders", title "Get to know the people you'll work with.")
  - **"Our journey"** (eyebrow "Our journey", title "Two careers, one studio."), described as "Where each of us
    has worked, the roles we've grown into, and when we graduated. Open a profile to see the projects behind each
    role.": a `CareerChart` with both partners on one shared years axis, each in their own lane with an avatar
    header. Hide it when no non-sample entries exist.
  - The Why-us section
  - "How we think" values, in three numbered columns whose accent top lines draw in
  - Testimonials, Tech stack and CTA

### Partner profile `/team/[slug]`

- "← Meet the team" link to `/about#team`.
- Intro, in two columns on desktop. The portrait is 4:3 on mobile and 4:5 on desktop, and is the morph target of
  the founder card (`name="portrait-<slug>"`). Then, staggered:
  - Eyebrow with the role, H1 with the name, and the headline.
  - Fact chips: location, "N+ years experience", languages.
  - The bio.
  - Buttons: **"💼 Hire me"** (primary → `/hire/<slug>`), "✉ Email {first name}" (secondary; mailto: partner email,
    or the studio email), plus LinkedIn ↗ and GitHub ↗ where set.
  - The personal quote, if set, as an accent-bordered blockquote.
- Sections with the heading on the left and content on the right, separated by dividers:
  - "About {first name}" (the `about` paragraphs)
  - "Expertise" (Focus plus each non-empty expertise group, as chips)
  - **"Career timeline"** (full width), introduced as "{first name}'s path so far: each role, the projects
    delivered in it, and education.", with two parts:
    - **"At a glance"**: a `CareerChart` plotted on a years axis. A label column (kind swatch, title, organization ·
      period, "Sample" badge) sits beside a track with year gridlines. Roles are rounded bars in their kind colour
      (ongoing roles fade out at "today"). Single dates are markers: milestones are diamonds, certifications are
      rings, and any other `point` entry (a graduation) is a filled dot in its kind colour. A year-only single
      date sits in the middle of its year column, not on the gridline. A dashed accent
      "Today" line runs down the chart, with a legend above. Bars grow from the left (`data-draw`) and markers pop
      in (`data-pop`) as rows reveal. The label column is 150px on mobile (the chart scrolls sideways) and 270px
      on desktop.
    - **"The story"**: a `CareerTimeline`, newest first, alternating left/right of a centre line on desktop and a
      single column on mobile. Each card has a kind dot (ongoing ones pulse), kind label · period, title,
      organization and description. Below that, a small "Project"/"Projects" label and rounded chips, one per
      `projects` slug ("Apparel 60 →"), each linking to its case study; then a "Verify ↗" link when `href` is
      set. Chips right-align on left-hand cards. Cards slide in from their side.
    - An entry's `photos` (up to three) fill the empty half of its row on desktop (`md:row-start-1` in the other
      column, aligned towards the centre line) and sit under the card on mobile. Each is a polaroid: a `bg-surface`
      frame with a border, `p-2` and a large soft shadow, and a 4:5 `next/image` (`fill`, `object-cover`). Below
      it, an optional centred mono caption; without one, the frame gets a deeper bottom edge (`pb-6`). Never
      print dates on the photos. They overlap (the second shifts left by 8% and down by 40px)
      and tilt -4°, 3°, -2°. On hover one straightens, lifts, scales to 1.04 and comes to the front
      (no transition with reduced motion). They enter with `data-settle`, staggered 110ms apart. Strip EXIF/GPS
      from phone photos before adding them.
      Clip the section with `overflow-x-clip` so off-screen cards never cause sideways scroll.
  - Kind colours are theme-aware tokens: `--kind-education/work/freelance/founder/milestone/certification`.
  - In development, when any entry is a sample, show a To-do note above the chart explaining that samples are
    hidden on the live site. Hide the whole section in production when no real entries exist.
  - Helpers in `src/lib/career.ts`:
    - `careerKinds` (label, colour and point/range for each kind)
    - `isPoint(entry)`: true for milestones, certifications and entries with `point: true`
    - `toYears("2021-06")` → 2021.42
    - `formatPeriod` → "Jul 2020 – Dec 2022" / "Jan 2023 – Present" / "Mar 2025"
    - `visibleCareer`, which drops samples in production
    - `sortNewestFirst`
    - `now()` (`"use cache"`)
  - The chart's axis runs from the earliest start year to the current year + 1. Each track's year gridlines are a
    repeating `linear-gradient` sized at `100% / years`. The "Today" line sits at `calc(var(--label) + (100% -
    var(--label)) * today%)`. Its tag flips to the left near the right edge so it never gets clipped.
  - "Projects {first name} worked on" (project cards)
- "Also on the team: {other partner} →" link, then a CTA titled "Work with Shantanu and Vedant".
- JSON-LD `Person` (name, jobTitle, description, url, image, worksFor, knowsAbout, sameAs).
- In development only (`NODE_ENV !== "production"`), show dashed "To do" notes where profile content, testimonials or
  technologies are missing. They must never render in production.

### Hire `/hire` and `/hire/[slug]` (the main conversion page; a full page, not a pop-up)

One shared `HirePage` component. Without a partner it's the studio page; `/hire/<slug>` (`generateStaticParams`,
with params read inside `<Suspense>`) addresses one partner. Buttons:
- `<HireButton />` renders "💼 Hire us" → `/hire`. Use it in the header.
- `<HireButton partner="<slug>" />` renders "Hire {first name}" → `/hire/<slug>`. Use it on the founder cards (with
  `relative z-10` so it sits above the card's stretched link).
- On the profile pages, label it "Hire me".

1. **Hero** (drifting accent glow; staggered rise; accent words in the shimmer gradient):
   - The availability pill.
   - H1: "Let's build your **next product.**" for the studio, or "Hire **{full name}**" for a partner.
   - Sub-copy: for the studio, "Hire {studio} for a full build, a single feature or ongoing support. You'll work
     directly with {names}, from the first call to long after launch."; for a partner, their headline + bio, plus
     location, experience and focus chips.
   - Buttons: "Write your brief ↓" (anchor `#brief`) and "See our work" (studio) or "View {name}'s profile" (partner).
   - Direct contact links: email, WhatsApp and each phone number, where set.
   - Right side: for the studio, both portraits (the second offset down), each linking to that partner's Hire page;
     for a partner, their single portrait.
2. **`#brief` section** (surface band):
   - "Step 1 · Who would you like to hire?": three option cards linking to `/hire`, `/hire/<a>` and `/hire/<b>` with
     `scroll={false}`:
     - "Both of us" (both avatars, "{A} & {B} together, for complete builds from design to launch.")
     - Each partner (avatar, name, headline)
     - The current page's card has an accent border, a ring, a filled check badge and `aria-current="page"`. All
       three cards have the spotlight.
   - Then two columns:
     - Left (sticky): "Step 2 · Tell us/{name} about your project.", "A few sentences is enough…", a numbered
       vertical timeline of `nextSteps` (We reply · Discovery call · Proposal · Kick-off), and a "Prefer to talk
       first?" box with the direct contact links.
     - Right: the contact form with the partner as a **hidden** field (`partnerField="hidden"`) and the message label
       "What would you like us to build?".
3. **Ways to work together**: three spotlight cards from `engagementModels`, each with a number, title, "Best for: …" and a
   check list. The three models are Fixed-scope project, Monthly retainer, and Maintenance & support. Mark TODO for
   the partners to confirm.
4. **Recent work**: four compact project tiles (cover, category, name). Show the partner's projects on a partner page.
5. Testimonials, FAQ, then a closing "Ready when you are." bar with a "Write your brief →" button.

### Contact `/contact`

- Header: eyebrow "Contact"; H1 "Let's talk about your project."; description "Share a few details and we'll
  come back with questions, ideas and next steps. {response_time}"
- Left column: contact rows with round outlined icons, covering Email (mailto), Phone (one tel link per number, if any), WhatsApp ("Chat with
  us", if set) and Location, followed by social links if set.
- Right column: the contact form (section 10), including a "Who would you like to work with?" select
  (Either of us / each partner).

### 404

Eyebrow "404", H1 "This page doesn't exist.", text "It may have moved, or the link might be wrong.", and buttons
"Go home" and "See our work".

## 7. Content (use this copy)

### Stats (true numbers only; partners replace them with stronger ones later)

In this order (it decides the bento tile sizes: large, small, small, wide):

| Value | Label | `visual` |
| --- | --- | --- |
| 4+ | Products live in production | `projects` |
| 2 | Partners on every project | `team` |
| <24h | First reply to new enquiries | `reply` |
| 6 | Services under one roof | `services` |

### Section headings (two-tone: **lead** + muted continuation)

| Where | Eyebrow | Lead (`title`) | Muted (`titleMuted`) |
| --- | --- | --- | --- |
| Home · services | What we do | Services. | From first idea to a product your team uses every day. |
| Home · work | Selected work | Work. | Products we've shipped and still look after. |
| Testimonials | Client words | Kind words. | What our clients say. |
| Why us | Why clients work with us | Why us. | A small team you can actually rely on. |
| Founders (Home) | Meet the founders | The founders. | The two people behind every project. |
| Founders (About) | The founders | Meet us. | Get to know the people you'll work with. |
| Process | How we work | Process. | A clear path from first call to long after launch. |
| Tech stack | Tools | Our stack. | We pick the tools for the project, not the other way round. |
| FAQ | FAQ | Questions. | The ones we hear most often. |
| Work page | And more | More work. | Beyond the case studies. |
| About · journey | Our journey | Two careers. | One studio. |
| About · values | How we think | Values. | What you can expect from us. |
| Hire · engagement | Ways to work together | Engagement. | Pick what suits your project. |
| Hire · work | Recent work / {name}'s work | Our work. / {name}'s work. | What we've built for others. / Projects {name} has worked on. |

### Marquee words

E-commerce stores ✦ SaaS platforms ✦ Factory & business software ✦ AI chatbots ✦ Websites & web apps ✦
Maintenance & support ✦ Built, launched & maintained

### Highlights

| Title | Description |
| --- | --- |
| End to end | Planning, design, build, hosting and launch, handled by one team. |
| Live in production | Every case study here is a real product in use today. |
| Here after launch | We maintain what we build, and take over existing projects. |
| Direct access | You talk to the two people who write the code. |

### Services

1. **E-commerce development** (`ecommerce`, short "E-commerce", icon shopping-bag): "Online stores that sell: catalogue, cart, checkout,
   payments and the admin tools to run orders day to day." Deliverables: Custom storefront, mobile-first ·
   Payment gateway integration · Product, inventory and order management · Admin dashboard for your team · SEO
   and page-speed setup.
2. **SaaS product development** (`saas`, short "SaaS products", layout-dashboard): "Multi-business platforms with accounts, roles and
   dashboards, built so one product can serve many customers." Deliverables: Multi-tenant architecture ·
   Sign-up, login and role-based access · Subscription and billing flows · Dashboards and reporting · Email and
   in-app notifications.
3. **Custom business software** (`business-software`, short "Business software", factory): "Systems made for how your company actually
   works, with inventory, production, dispatch and reporting in one place." Deliverables: Inventory and stock tracking ·
   Production and workflow management · Orders, dispatch and shipment tracking · Reports and data exports · User
   roles and permissions.
4. **AI chatbots & automation** (`chatbots`, short "AI chatbots", bot): "Chatbots that answer customer questions, capture leads and hand
   off to your team when a human is needed." Deliverables: Website and messaging chatbots · Answers grounded in
   your own content · Lead capture and human handoff · Integrations with your existing tools.
5. **Websites & web apps** (`web`, short "Websites", globe): "Fast, responsive business websites, portals and internal tools built
   on modern frameworks." Deliverables: Company and marketing websites · Customer and partner portals · Internal
   tools and admin panels · Third-party API integrations.
6. **Maintenance & support** (`maintenance`, short "Maintenance", life-buoy): "We keep live products healthy after launch: fixes,
   updates, hosting, backups and new features as you grow." Deliverables: Bug fixes and dependency updates ·
   Hosting, deployment and backups · Performance and security patches · New features on a monthly plan · Takeover
   of existing projects.

### Projects

Leave `stack: []` and `year` empty with TODO comments. Do not guess the technologies.

**1. Apparel 60** — slug `apparel-60` · category "E-commerce" · cover `store`, `#f97362 → #f6b35c` · featured
- Tagline: "A complete online store for a clothing brand."
- Summary: "A production e-commerce platform for Apparel 60, covering catalogue, cart, checkout and order management.
  Live at apparel60.co.in."
- Industry: Fashion & apparel retail · Live URL: https://www.apparel60.co.in
- Role: Design, development, launch & ongoing maintenance · Services: ecommerce, maintenance
- Challenge: "Apparel 60 needed its own storefront to sell directly to customers: a catalogue the team can update
  without a developer, and a smooth path from browsing to paying on any device."
- Solution: "We built and launched a custom e-commerce platform: the customer-facing store, a cart and checkout
  flow, and the admin tools the team uses to manage products and orders. We continue to maintain and improve it."
- Features: Product catalogue (categories, product pages, sizes and variants managed from the admin panel) ·
  Cart & checkout (short checkout with online payments, mobile-first) · Order management (orders, statuses and
  customer details in one dashboard) · Ongoing maintenance (updates, fixes and new features after launch).
- Results: "Live in production at apparel60.co.in" · "Maintained by us since launch"

**2. Appointment SaaS** — slug `appointment-saas` (TODO: real product name) · category "SaaS platform" · cover
`calendar`, `#5b7cfa → #8f6cf0` · featured
- Tagline: "One place for any business to manage its schedule and operations."
- Summary: "A multi-business SaaS platform where any business can manage appointments, staff schedules and
  day-to-day operations from a single dashboard."
- Industry: Service businesses (any sector) · Role: Product design & full-stack development · Services: saas, web
- Challenge: "Service businesses juggle bookings across phone calls, messages and paper diaries, which leads to double
  bookings, missed appointments and no clear view of the day."
- Solution: "We built a SaaS platform any business can sign up for and set up for itself: services, staff,
  working hours and bookings, all run from one dashboard."
- Features: Online booking · Staff & schedule management · Multi-business (own workspace, settings and data per
  business) · Business dashboard.
- Results: "Built to serve any business type from one codebase"

**3. Diamond Polymer** — slug `diamond-polymer` · category "Factory management" · cover `dashboard`,
`#18a38a → #3cc6c0` · confidential · featured
- Tagline: "Custom software that runs the factory, from inventory to shipments."
- Summary: "A custom application built for Diamond Polymer to manage factory operations end to end, from
  raw-material inventory through to dispatch and shipments."
- Client: Diamond Polymer · Industry: Manufacturing · Role: Requirements, design & full-stack development ·
  Services: business-software, maintenance
- Challenge: "Stock, production and dispatch were tracked in separate places, so nobody had a reliable, up-to-date
  view of what was in the factory or what had shipped."
- Solution: "We built a single application around the factory's own workflow: inventory is recorded as it
  arrives, moves through production, and leaves as tracked shipments, with reports at every stage."
- Features: Inventory management · Production tracking · Shipment management · Reports.
- Results: "One system replacing scattered records" · "In daily use on the factory floor"

**4. MV Bot** — slug `mv-bot` · category "AI chatbot" · cover `chat`, `#2f3440 → #59617a` · featured
- Tagline: "A conversational assistant that handles routine questions around the clock."
- Summary (TODO: confirm): "MV Bot is a chatbot application that answers questions, guides users and handles
  routine conversations automatically."
- Industry: Customer support · Role: Design & development · Services: chatbots
- Challenge: "Teams lose hours answering the same questions again and again, and customers who message outside
  working hours wait for a reply."
- Solution: "We built MV Bot, a chatbot that answers common questions instantly, guides users to the right
  information and hands the conversation to a person when it needs one."
- Features: Natural conversations · Always available · Human handoff.
- Results: "Instant answers to routine questions"

### Process

1. **Discover**: We learn about your business, users and goals, then agree on scope, timeline and cost in writing.
2. **Design**: Flows and screens you can review and change before development starts.
3. **Build**: Development in short cycles with regular demos, so you see progress as it happens.
4. **Launch**: Testing, deployment, domain and hosting. We handle go-live end to end.
5. **Maintain**: Monitoring, fixes and new features after launch, on a plan that suits you.

### Tech stack (starter list, marked TODO for the partners to replace)

Frontend: React, Next.js, TypeScript, Tailwind CSS · Backend: Node.js, Express, REST APIs, Python ·
Data: PostgreSQL, MySQL, MongoDB, Redis · Cloud & DevOps: AWS, Vercel, Docker, CI/CD ·
AI & integrations: OpenAI / LLM APIs, Payment gateways, WhatsApp & SMS APIs

### Values

- **Ownership**: We treat your product like our own, before and after launch.
- **Plain communication**: Clear estimates, regular updates and no jargon. You always know where things stand.
- **Built to last**: Clean, documented code that is easy to extend, whether by us or by your future team.

### FAQ (marked TODO: these are policy statements for the partners to confirm)

- **How much does a project cost?** It depends on scope. After a short discovery call we send a fixed quote for
  well-defined projects, or a monthly rate for ongoing work. Small websites start lower than full platforms.
- **How long does it take?** A business website usually takes a few weeks; e-commerce stores, SaaS products and
  custom systems take longer. You'll get a timeline with milestones before we start.
- **Do you maintain the product after launch?** Yes. We offer maintenance plans covering hosting, updates, fixes
  and new features, and we already maintain several of the products shown here.
- **Can you take over an existing project?** Yes. We start with a code and infrastructure review, fix what's
  urgent, then continue development and support.
- **Who owns the code?** You do. Once the project is paid for, the source code and accounts are handed over to you.

## 8. Design system

**Tone:** editorial, confident and a little playful. Warm off-white canvas (near-black in dark mode), near-black
ink, one blue accent with violet and coral supporting colours, generous whitespace, thin 1px borders and large
rounded corners. Motion should feel smooth and purposeful: no stock photos, no emoji in the UI, no bouncing for
the sake of it, and gradients only on project covers, accent text and soft background glows.
Reference sites for the motion language are Sidejob (itsasidejob.com), Butter (butter.video), NK Studio
(nk.studio) and gsap.com. Borrow their *techniques* (a pinned word list, parallax depth, two-tone type),
never their 3D/WebGL scenes, loaders or neon palettes. The "How we work" deck is our own: a physical,
click-to-cycle stack of cards (section 6, Home → Process).

**Colour tokens** (CSS variables, exposed to Tailwind via `@theme inline` as `canvas`, `surface`, `surface-2`,
`ink`, `muted`, `line`, `accent`, `accent-ink`, `accent-soft`):

| Token | Light | Dark |
| --- | --- | --- |
| canvas (page background) | `#f6f5f1` | `#0b0c0f` |
| surface (cards, bands) | `#ffffff` | `#131519` |
| surface-2 (hover, tags) | `#eeece6` | `#1b1e23` |
| ink (text, primary button) | `#111318` | `#ecebe6` |
| muted (secondary text) | `#5c616e` | `#9ba0ab` |
| line (borders) | `#e2e0d8` | `#262930` |
| accent | `#2f54eb` | `#8197ff` |
| accent-ink (text on accent) | `#ffffff` | `#0b0c0f` |
| accent-soft (icon backgrounds) | `#e6ebff` | `#1a2147` |
| glow (spotlight colour) | `rgba(47,84,235,0.12)` | `rgba(129,151,255,0.14)` |
| kind-education | `#d98a1c` | `#f6b35c` |
| kind-work | `#2f54eb` | `#8197ff` |
| kind-freelance | `#11957e` | `#3cc6b0` |
| kind-founder | `#7c5cf0` | `#a891ff` |
| kind-milestone | `#e5533d` | `#ff8a78` |
| kind-certification | `#c93d86` | `#f07ab8` |

Selection uses accent / accent-ink. Focus ring: 2px accent outline with a 3px offset. Set `theme-color` meta
for both schemes.

**Typography:** Geist Sans for everything, with Geist Mono for eyebrows, labels and step numbers.
- Eyebrow: mono, 12px, uppercase, tracking 0.18em, accent colour.
- H1: about 60–68px on desktop (42px mobile), semibold, tight tracking, `text-balance`.
- H2: 36px desktop / 30px mobile, semibold, tight tracking.
- Body: 16–20px, muted colour for supporting text, `text-pretty`.

**Layout:** max width 1152px (`max-w-6xl`), side padding of 16/24/32px, section padding of 80–112px vertically.
Alternate plain canvas sections with `surface` bands, separated by 1px `line` borders.

**Buttons** (pill shaped, 14px medium):
- primary: ink background with canvas text, turning accent on hover
- secondary: surface background with a line border, ink border on hover
- inverse (for dark panels): canvas background with ink text, turning accent on hover

**Project cover illustration** (shown when no screenshot is set): a 16:10 rounded box filled with a 135°
gradient (`from → to`), holding a white "browser window" (three grey dots, a URL bar, the project name) inset from the
sides and running off the bottom edge. Inside the window, draw a simple mock UI made from grey and project-colour blocks:
- `store`: a 4×2 product grid of tall tiles with two caption lines each
- `calendar`: a 5-column week with booked slots highlighted
- `dashboard`: three stat cards above five table rows with status pills
- `chat`: five alternating chat bubbles, with the user's bubbles in the project colour

When `cover.image` is set, show it with `next/image` (fill, object-cover) instead.

### Light/dark toggle (playful)

- Three theme states: automatic (device), light and dark. CSS tokens live in `:root` (light), in
  `@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { … } }` and in `:root[data-theme="dark"]`.
  Set `color-scheme` per theme.
- The inline `<head>` boot script applies `localStorage.theme` to `<html data-theme>` before paint, so there's no flash.
- Toggle: a sun icon whose rays rotate out while the core grows into a moon (an SVG mask circle slides in);
  CSS-transition the SVG `r`/`cx`/`cy`. Clicking it sets `--theme-x/--theme-y` and calls
  `document.startViewTransition()`, so the new theme spreads from the button as a growing `clip-path` circle. Fall
  back to an instant switch without support or with reduced motion.
- On hover, the sun's rays rotate 45°. The reveal circle takes 0.75s with the soft ease-out. Use `useId()` for the
  SVG mask id, because there are two toggles (desktop and mobile).
- It sits in the desktop nav and as a labelled row in the mobile menu ("Switch to dark mode" / "Switch to light
  mode", switched by CSS so there's no hydration mismatch).
- The theme circle only runs while `<html data-theme-switching>` is set, so it never clashes with React's page
  transitions.

### Creative details

- **Words that rise out of a mask** on every section heading (on scroll) and page title (on load), staggered
  45–55ms apart.
- **Shimmering gradient text** on hero accent words (accent → violet → white sheen → coral, 7s).
- **Interactive process deck**: "How we work" is a stack of physical cards. Clicking, tapping or swiping the
  front card sends it under the deck to the back as the next one comes forward, cycling endlessly (full spec in
  section 6, Home → Process).
- **Cursor spotlight**: a radial glow follows the mouse across cards with the `.spotlight` class. One passive
  pointermove listener feeds the position as `--mx/--my`.
- **Film grain**: a fixed SVG-noise overlay at 3.5% opacity (6% in dark mode).
- **Why us as a bento grid**: one large tile, two small and one wide. Each stat can have a `visual`:
  - `projects`: fanned project covers that spread out on hover
  - `team`: overlapping founder avatars
  - `reply`: a chat bubble with bouncing typing dots
  - `services`: a row of service icons
- **Oversized footer wordmark**: the studio name, sized from its length to span the page, with a fading gradient,
  rising into view.
- **Page transitions** with React `<ViewTransition>`:
  - `default="page"` around `<main>`, for a fade-and-lift.
  - Shared-element morphs (`share="morph" default="none"`) from a project card's cover to the case-study cover,
    and from a founder card's portrait to the profile portrait.
  - The old page fades out in 180ms, and the new one fades in and lifts 14px over 380ms. Morphs take 520ms with a
    brief blur mid-flight. `::view-transition { pointer-events: none }`.
  - Never put the same morph name on two visible elements on one page. The decorative hero covers and the Hire
    page's portraits are *not* named.
  - Disable all transitions for reduced motion.

### Motion (CSS first, GSAP for scroll-scrubbing)

- Define the keyframes in Tailwind's `@theme`, with easing `--ease-out-soft: cubic-bezier(0.2, 0.7, 0.2, 1)`:
  - `rise` (fade + 20px up, 0.9s)
  - `float` (±10px, 7s)
  - `marquee` (translateX −50%, 45s linear)
  - `drift` (slow translate/scale, 16s alternate)
  - `draw` (SVG stroke-dashoffset)
  - `menu` (mobile dropdown fade-down)
- Also define:
  - `shimmer` (background-position, 7s)
  - `word-up` (translateY 110% → 0)
  - `theme-reveal` (clip-path circle)
  - `vt-fade-out`, `vt-fade-in` and `via-blur` for page transitions
- Prefix every animation with `motion-safe:`. A `delay(ms)` helper returns `{ "--delay": ms, animationDelay: ms }`
  for staggering.
- **Scroll reveal**: `<Reveal>` renders `data-reveal` (`""`/up 32px, `"fade"`, `"scale"` 0.96, `"left"`/`"right"`
  ±40px). CSS hides them only under `[data-motion="on"]` inside `@media (prefers-reduced-motion: no-preference)`.
  - An inline `<head>` script sets `data-motion="on"` on `<html>` when motion is allowed (use
    `suppressHydrationWarning` on `<html>`). If the reveal script hasn't started within 3s, it removes the flag, so
    content is never stuck hidden.
  - A client `<Reveal as? variant? delay? margin?>` component renders `data-reveal` and shares one module-level
    IntersectionObserver per trigger margin (default `rootMargin: "0px 0px -10% 0px"`, threshold 0.1). When it enters the viewport it sets state, rendering `data-revealed`; after the
    transition it drops both attributes, so hover transitions aren't delayed. It updates only after its own
    hydration, so there are never hydration mismatches. Don't mutate the DOM from a global observer.
  - Children with `data-draw` scale in from the left when their parent is revealed. Use this for process lines,
    value lines and career bars.
  - Children with `data-pop` pop in with a little overshoot, 350ms after their parent. Use this for career markers
    and timeline dots.
  - Children with `data-settle` fade in and rise 28px from 94% scale (0.75s, 100ms after their parent, plus an
    optional `--settle-delay` for staggering). Use this for the timeline polaroids. Keep delay + duration under
    the Reveal's 1s clean-up so the attributes aren't removed mid-animation.
  - Don't reveal elements that sit mostly below the page's bottom edge (like the footer wordmark) with a vertical
    offset, because they never become visible enough to trigger. Fade them instead, and give the very last thing
    on the page `margin="0px"`: on phones it never scrolls above the default trigger line (the bottom 10%), so
    with the default it would stay hidden.
- **Count-up**: a client component that renders the final value on the server (correct with no JavaScript or with
  reduced motion), then animates from 0 with an ease-out cubic when 60% visible. Keep an sr-only copy of the value.
- **Hover micro-interactions**:
  - Service icons tilt and grow.
  - Project-cover windows zoom 4%.
  - Founder portraits zoom 3%.
  - Arrows nudge right.
  - The CTA glow drifts.
  - The front process card lifts 6px with a deeper shadow, and its footer arrow keeps nudging.
- **Pointer effects** (`components/motion/pointer-effects.tsx`, mounted once in the layout). Mouse and pen only:
  never on touch, never with reduced motion. Keep them restrained: thin lines, short distances, soft easing,
  no custom cursor.
  - **Click ripple:** on every primary-button `pointerdown`, add a ripple at the pointer into a fixed,
    `pointer-events: none` layer (`.click-layer`, z-index 70) rendered by the component. A ripple is three
    64px circles: a soft radial bloom (to 0.95 scale over 520ms), a 1.5px ring (0.1 → 1 over 700ms) and a 1px
    echo (0.1 → 1.55 over 900ms, 90ms later, starting at 55% opacity). Each grows with
    `cubic-bezier(0.16, 1, 0.3, 1)` but fades with an ease-in (`cubic-bezier(0.5, 0, 0.75, 0)`), so it stays
    visible while it spreads (the bloom fades ease-out). Colour: the full accent on links, buttons and form
    controls; 70% accent elsewhere. Cap at 6 live ripples and remove each after 1.1s. Give the layer
    `view-transition-name: click-layer` (no group animation, old snapshot hidden) so a ripple keeps playing
    through page and theme transitions. Keyboard activation never shows one.
  - **Magnetic buttons:** every button (the `magnetic` class is in `buttonClasses`' base, plus the process-deck
    arrows and the WhatsApp button) leans toward the cursor: 22% of the horizontal and 30% of the vertical
    distance from its centre, capped at 6px and 4px, via `--mag-x/--mag-y` and
    `transform: translate3d(...)` with a 0.5s soft ease. It settles back on leave or scroll, and presses to
    `scale: 0.96` while held. `.magnetic` sets the element's whole transition list (transform, scale, colours,
    shadow), replacing Tailwind's `transition-colors`.
- **Link underline sweep** (`.link-fx`): plain text links (desktop nav, footer, contact details, social links,
  inline links) draw a 1px `currentColor` underline in from the left over 0.45s and slip it out to the right
  (`background-size` on a gradient, `box-decoration-break: clone`). `.link-fx-group` draws when its `.group`
  is hovered. The current page's nav link (`aria-current="page"`) stays underlined. Don't use it on links that
  pair an icon with text.
- **Arrow nudge:** in `@layer base`, so components with their own arrow motion win: arrow-right/chevron-right
  icons inside a hovered link or button shift 3px right, arrow-left/chevron-left 3px left, arrow-up-right 2px up
  and right (lucide's `lucide-<name>` classes; 0.35s soft ease; no motion with reduced motion).
- Use reveals on headings, cards, list rows, timeline items, chart rows, the FAQ and the CTA panel. Never use them
  on above-the-fold content, which uses the `rise` entrance instead.

**Project card:** the cover lifts 4px on hover. Below it: category (mono, uppercase), name (the whole card is clickable
through a stretched link), tagline, and a round arrow-up-right button that fills with ink on hover.

## 9. Components to create

```
src/components/
├── layout/   logo.tsx, site-header.tsx, main-nav.tsx (client), theme-toggle.tsx (client), site-footer.tsx,
│             whatsapp-button.tsx
├── sections/ hero.tsx, services-grid.tsx, featured-work.tsx, why-us.tsx, team.tsx, testimonials.tsx,
│             process.tsx, tech-stack.tsx, faq.tsx, cta.tsx
├── motion/   reveal.tsx (client), count-up.tsx (client), marquee.tsx, spotlight-tracker.tsx (client),
│             pointer-effects.tsx (client: click ripple + magnetic buttons),
│             smooth-scroll.tsx (client, Lenis), hero-parallax.tsx (client, GSAP)
├── sections/ … services-wheel.tsx (client, GSAP), process-stack.tsx (client, GSAP card deck), plus the two-tone
│             SectionHeading in ui/section-heading.tsx
├── career/   career-chart.tsx, career-timeline.tsx
├── hire/     hire-page.tsx
├── projects/ project-card.tsx, project-cover.tsx
├── contact/  contact-form.tsx (client), hire-button.tsx (Link styled as a button → /hire or /hire/<slug>)
└── ui/       container.tsx (Container + Section), button.tsx (ButtonLink + buttonClasses),
              section-heading.tsx (Eyebrow, SectionHeading, PageHeader), icon.tsx (IconName → lucide icon),
              avatar.tsx (Portrait + Avatar: photo or initials. Portrait uses `object-position: 50% 20%`
              so 5:4 and 4:3 crops keep the face; Avatar prefers `avatar`, else `photo` at the same position), dev-note.tsx (development-only reminder),
              split-words.tsx (word masks for rising headings), page-skeleton.tsx (Suspense fallback)
src/lib/utils.ts   cn(), displayUrl(), withHref(), whatsappUrl()
src/lib/motion.ts  delay(), bootScript (applies the saved theme, sets data-motion, 3s safety fallback)
src/lib/gsap.ts    registers ScrollTrigger + useGSAP once; exports gsap, ScrollTrigger, useGSAP, MOTION_OK
src/lib/career.ts  careerKinds, toYears(), formatPeriod(), visibleCareer(), sortNewestFirst(), now()
src/app/hire/page.tsx, src/app/hire/[slug]/page.tsx, src/app/team/[slug]/page.tsx   (plus the pages in section 5)
```

## 10. Contact form

- Client component using React `useActionState` with a Server Action at `src/app/contact/actions.ts`.
- Fields:
  - Your name (required, at least 2 characters)
  - Email (required, valid format)
  - Phone (optional)
  - Company (optional)
  - What do you need? (select: the service titles plus "Something else")
  - Budget (select: from `budget_ranges`)
  - Tell us about your project (required, at least 20 characters; placeholder "What are you building, who is it for,
    and when do you need it?")
- Two-column grid on desktop with the message spanning both columns. Show "Optional" on the right of optional labels.
- **Partner**: a `partner` field holds a partner slug (a select on `/contact`, hidden on the Hire pages). The server
  only accepts known slugs. With a partner, the subject is "Hire request for {first name} from {name}", the body includes
  "Wants to work with: {full name}", the partner's direct `email` (if set) is added to the recipients, and the
  success message reads "Thanks! {first name} has your message and will reply soon."
- Use `useId()` for every field id so the form can safely appear more than once.
- **Honeypot**: a hidden `website` field, positioned off-screen with `aria-hidden` and `tabIndex={-1}`. If it's
  filled, return success without sending.
- Trim every value and cap its length (name 100, email 200, message 5000).
- On validation errors: show per-field messages under the inputs (`aria-invalid`, `aria-describedby`), show "Please
  fix the highlighted fields." in an `aria-live` region, and **keep what the visitor typed** (return the values
  and use them as `defaultValue`).
- Sending: POST to `https://api.resend.com/emails` with `from` = `CONTACT_FROM_EMAIL`, `to` =
  `CONTACT_TO_EMAIL` (comma-separated list allowed; defaults to the site email), `reply_to` = the visitor's email, subject "New enquiry from {name}
  ({company})" and a plain-text body listing every filled field followed by the message.
- If `RESEND_API_KEY` is missing: in development, log the submission and return success with a "(Development mode…)"
  note. In production, return an error asking the visitor to email the studio directly. Never drop a message silently.
- On provider failure: log it and show "Sorry, something went wrong sending your message. Please try again or email
  us at {email}."
- Success state: replace the form with a card showing a check icon, "Message sent" and the success text.
- The submit button reads "Send message →" and changes to "Sending…" (disabled) while pending.
- The footer note under the form reads: "We only use your details to reply to you."

## 11. Floating WhatsApp button

- Rendered in the root layout, so it appears on every page. Render **nothing** if `whatsapp` is empty.
- `whatsappUrl(number, message)` strips everything except digits and returns
  `https://wa.me/<digits>?text=<encodeURIComponent(message)>`. Use the same helper for the WhatsApp link on `/contact`.
- A 56px circle fixed at the bottom-right (16px from the edges on mobile, 24px on desktop), `z-30`, WhatsApp green
  `#25D366`, a white WhatsApp logo (inline SVG, 28px), a soft shadow, a slight scale-up on hover, and hidden when printing.
- Opens in a new tab (`target="_blank" rel="noopener noreferrer"`), `aria-label="Chat with us on WhatsApp"`.
- Desktop only: a "Chat on WhatsApp" pill label (surface background, ring, shadow) slides out to the left of
  the circle on hover or keyboard focus. It's absolutely positioned with `pointer-events-none` so it never blocks clicks, and
  `aria-hidden` because the link already has a label.

## 12. SEO and sharing

- Root `metadata`: `metadataBase` from the site URL, title template "%s · {studio}", default title
  "{studio} — {tagline}", description, Open Graph (website, `en_IN`) and Twitter `summary_large_image`.
- Per-page titles: Services, Work, About, Contact, "Hire us", "Hire {name}", "{name} — {role}" for profiles, and
  "{name} — {category}" for case studies.
- `sitemap.ts`: `/`, `/services`, `/projects`, `/about`, `/hire` and `/contact`, plus every `/projects/<slug>`,
  `/team/<slug>` and `/hire/<slug>`. Don't use `new Date()` (it breaks static prerendering).
- `robots.ts`: allow everything, and point to the sitemap.
- `opengraph-image.tsx` (`next/og`, 1200×630): a dark ink background, the monogram in an accent square, the studio name,
  the hero headline in large type, and the first four service titles as outlined pills.
- `icon.svg`: the monogram on a dark rounded square.
- JSON-LD: `ProfessionalService` with `founder` on the home page, and `Person` on each profile (section 6).

## 13. Accessibility and performance checklist

- Use `<header>`, `<nav aria-label>`, `<main id="main">`, `<footer>`, `<article>` for cards and case studies, and keep
  headings in order.
- Mark decorative icons and illustrations `aria-hidden`. Give images meaningful `alt` text.
- Mobile menu button with `aria-expanded`, `aria-controls` and a dynamic `aria-label`.
- Respect `prefers-reduced-motion` everywhere: no entrances, reveals, word rises, floats, shimmer, marquee
  scrolling, count-ups, theme circle, page transitions, smooth scrolling, parallax, the process deck's
  card moves and wiggle (moves are instant) or services wheel (it falls back to the grid).
- GSAP effects live inside `gsap.matchMedia()` with `(prefers-reduced-motion: no-preference)`. Never use
  ScrollTrigger `pin` with React; pin with CSS `sticky` and only scrub animations.
- Charts carry `role="img"` and an `aria-label`. The career timeline lists every entry as text, so it's the
  accessible version of the chart.
- Sections whose items slide in from the side get `overflow-x-clip` (not `overflow-hidden`, so sticky elements still work).
- The spotlight listener is passive, starts after `load`, and only runs on devices with a fine pointer.
- Content must be fully visible with JavaScript disabled.
- Use `next/image` with correct `sizes`. `priority` is deprecated in Next 16: for above-the-fold images use
  `loading="eager"` and `fetchPriority="high"`.
- Every route should build as static (○) apart from the dynamic-param fallback.

## 14. Project files to produce

```
portfolio/
├── README.md               setup, structure, editing content, Hire pages, light/dark mode, career timelines,
│                           the animations table, contact form setup, deployment
├── docs/website-build-prompt.md   this prompt, kept in sync with the site
├── CLAUDE.md               `@AGENTS.md`, then short notes for AI assistants: the owners' working rules (ask before
│                           major changes, never invent facts, brand spelling, photo privacy, keep docs in sync),
│                           commands, where content lives, the stack's traps (Cache Components, Tailwind layers,
│                           Reveal timing, GSAP/Lenis rules, view transitions, pointer effects) and a done-checklist
├── docs/claude-kickoff-prompt.md  how to hand the finished project to Claude Code, plus a prompt that has it
│                           verify the build, summarise what's missing from the checklist and work through it
├── CONTENT_CHECKLIST.md    everything the partners still need to supply, prioritised 🔴/🟡/⚪
├── .env.example            NEXT_PUBLIC_SITE_URL, RESEND_API_KEY, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL
├── .gitignore              ignore .env* but keep !.env.example
├── public/images/projects/ README.txt: screenshots should be 1600×1000, named after the slug
├── public/images/team/     README.txt: 4:5 portraits (face in the upper third), square avatar crops, timeline photos
└── src/ …                  as described above
```

`CONTENT_CHECKLIST.md` must cover:
- Brand and domain: name, logo, colour.
- Contact details: email, WhatsApp, phone, socials, budget currency.
- For each partner: role, headline, bio, story, 4:5 portrait, technologies, links, languages. The **career
  history** in section 0 is real and filled in; the checklist only asks for optional extras (university and branch
  for the B.Tech, certifications, freelance work). Both partners co-founded the studio in 2025.
- For each project: client permission, real tech stack, feature check, screenshots, year/role, measurable results, a client quote.
- Project-specific questions:
  - Appointment SaaS: product name and live link.
  - Diamond Polymer: permission to name the client, and the full module list.
  - MV Bot: purpose, platform, AI model, demo.
- The "other work" list, the real tech stack, the "Why us" numbers, the Hire-page terms (engagement models and
  next steps) and the FAQ policies.
- Accounts: GitHub, Vercel, Resend, DNS, Search Console, analytics.
- Legal: a privacy policy (India DPDP Act) and optional terms.

## 15. Acceptance criteria

- [ ] `npm run build`, `npm run lint` and `npm run typecheck` (`next typegen && tsc --noEmit`, so it works on a fresh
      checkout) pass with no errors; all pages prerender.
- [ ] Every route in section 5 returns content; an unknown `/projects/xyz` shows the 404 page.
- [ ] Changing a value in `src/data/*` updates every place it appears (cards, pages, footer, sitemap, metadata).
- [ ] Empty optional fields never render empty labels or broken links.
- [ ] At 390px wide there is no horizontal scroll, the mobile menu works, and the WhatsApp button doesn't block the menu.
- [ ] Dark mode looks deliberate, not inverted: all text is readable and the CTA button is visible.
- [ ] The contact form shows field errors, keeps typed values, logs in development without keys, and sends through
      Resend with keys.
- [ ] The WhatsApp button is hidden when `whatsapp` is empty. When it's set, it opens `wa.me` with the pre-filled message.
- [ ] No invented statistics, testimonials or technologies anywhere on the site. Sample career entries never
      render in a production build.
- [ ] The theme toggle animates (sun ↔ moon, circular reveal), persists across reloads with no flash, and works
      from the mobile menu. Both themes look deliberate.
- [ ] Clicking a project card morphs its cover into the case study, and clicking a founder card morphs the
      portrait into the profile. The dev console stays free of errors and hydration warnings.
- [ ] The footer wordmark spans the page without overflowing, and the spotlight follows the cursor on cards. There
      is no scroll-progress bar (the owners asked for it to be removed).
- [ ] On desktop, scrolling the services wheel advances one service at a time, and clicking a name jumps to it.
      Phones, reduced motion and no-JS show the card grid instead.
- [ ] Clicking or tapping the front process card sends it to the back of the deck and brings the next one
      forward, cycling 1 → 5 → 1. The arrows, dots, step list and a swipe do the same, and a short drag snaps
      back. Reduced motion is instant. The hero covers follow the mouse.
- [ ] Wheel scrolling is smooth (Lenis), and anchors (`#team`, `#brief`, `/services#…`) land 80px from the top
      with and without Lenis.
- [ ] The career chart and timeline render for each partner, and the About page shows both on one axis.
- [ ] Scrolling the home page reveals every section, and no element stays invisible. Reveals also work after
      client-side navigation.
- [ ] With reduced motion on, or JavaScript off, every element is visible immediately and the numbers show their final values.
- [ ] `/hire`, `/hire/<a>` and `/hire/<b>` build statically. Every Hire / Start a project button lands on the right
      one, the picker switches pages without jumping the scroll position, and the enquiry email names the chosen
      partner. A tampered partner value is ignored.
- [ ] Both `/team/<slug>` profiles build statically, link to each other and to their projects, and every case
      study shows "Built by" with links to the profiles.
