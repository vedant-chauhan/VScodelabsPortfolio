# Kickoff prompt: hand the portfolio to Claude

Use this to have Claude continue developing the site from the code as it is now.
(To rebuild it from scratch instead, give Claude `docs/website-build-prompt.md`.)

## How to use it

Claude needs to run the code, so use **Claude Code**, not a plain chat:

- **On your computer:** install Node.js 20.9 or newer and Claude Code. Unzip `portfolio-website.zip`, open a
  terminal in the `portfolio` folder, run `claude`, and paste the prompt below.
- **In the browser (claude.ai/code):** first put the `portfolio` folder in a private GitHub repository, start a
  session with that repository, and paste the prompt below.

Claude Code reads `CLAUDE.md` in the project automatically. It holds the project's rules and technical notes, so
keep it in the folder.

---

## The prompt (copy everything below this line)

You're taking over development of the VSCodesLabs portfolio website, the site for our two-partner software studio
(Shantanu Kyada and Vedant Chauhan). The code in this folder is a complete, working Next.js 16 site: services,
four case studies, partner profiles with career timelines, Hire pages, a contact form, light/dark mode and
animations. What's left is mostly our real content and the launch setup.

Before anything else, read `CLAUDE.md` (our rules and the technical traps), then `README.md` and
`CONTENT_CHECKLIST.md`.

**Step 1: get it running and verified.**
1. If this folder isn't a git repository yet, run `git init` and commit everything as it is ("Initial import"),
   so every later change can be reviewed and undone. Don't push anywhere until we ask.
2. `npm install`, copy `.env.example` to `.env.local`, then run `npm run lint`, `npm run typecheck` and
   `npm run build`.
3. Start `npm run dev` and tell us the address.
4. If anything fails, show us the exact output and suggest a fix. Never "fix" something by deleting a feature.

**Step 2: show us where things stand.** In a few lines, summarise what the site has. Then list what's still
missing from `CONTENT_CHECKLIST.md`, grouped by priority (🔴 first). We know about these already:
- The profile headlines and bios still call us both "full-stack engineers", which doesn't match our real roles
  (Shantanu: Associate Product Manager → Product Manager at GNWebSoft Pvt. Ltd.; Vedant: Data Analyst at Inkey
  IT Solutions Pvt. Ltd. since Jan 2025, and co-founder of VSCodesLabs since 2025).
- The WhatsApp number and domain aren't set (our email and phone numbers are in), the
  "Technologies" lists are empty, and there are no testimonials yet.

Then ask us for the missing content **one group at a time**, not all at once.

**Step 3: work through it**, in this order unless we say otherwise:
1. **Content:** partner details, project details and permissions, our real tech stack, contact details.
2. **Launch:** GitHub repository, Vercel deployment, our domain and `NEXT_PUBLIC_SITE_URL`, Resend for the
   contact form, the sitemap in Google Search Console, and analytics. Walk us through any steps we have to do
   in those accounts ourselves.
3. **A privacy policy page** (`/privacy`), linked from the footer and the contact form. The form collects
   names, emails and phone numbers, so it should cover India's DPDP Act.
4. **Optional extras** (book-a-call embed, blog, pricing, screenshot galleries, Hindi/Gujarati) only when we
   ask.

**How we want you to work** (also in `CLAUDE.md`):
- Ask before any major change: new sections, redesigns, new animations or effects, new libraries. Small fixes are
  fine.
- Never invent facts: no made-up numbers, clients, testimonials, dates, career details or technologies. If
  something is missing, ask us or leave a clear TODO.
- Keep it elegant and professional. The brand is "VSCodesLabs" everywhere.
- Photos: remove location data (EXIF/GPS) before adding them, and never print dates on them.
- After each change: lint, type-check and build, then check the page in a browser at desktop and phone sizes,
  in light and dark mode. Tell us what you checked.
- Keep `README.md`, `CONTENT_CHECKLIST.md` and `docs/website-build-prompt.md` up to date with what you change.
- Commit each finished piece of work with a clear message. Never push, deploy or touch our accounts or DNS
  without asking first.
- Explain things in plain language and keep your updates short.
